import React from 'react'
import MapComponent from '../components/MapComponent'

const MapPage: React.FC = () => {
  return (
    <div className="h-[calc(100vh-64px)] flex">
      {/* Sidebar */}
      <aside className="w-80 bg-surface border-r border-grid flex flex-col hidden lg:flex">
        <div className="p-4 border-b border-grid">
          <h2 className="font-semibold text-text">避难所筛选</h2>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          {/* Filter options will be added here */}
          <p className="text-text-muted text-sm">地图筛选功能开发中...</p>
        </div>
      </aside>
      
      {/* Map */}
      <div className="flex-1 relative">
        <MapComponent />
      </div>
    </div>
  )
}

export default MapPage