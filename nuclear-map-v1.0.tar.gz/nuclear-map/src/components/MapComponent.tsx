import React from 'react'
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import { Icon } from 'leaflet'
import 'leaflet/dist/leaflet.css'

// 自定义标记图标
const shelterIcon = new Icon({
  iconUrl: '/nuclear-map/assets/marker-shelter.svg',
  iconSize: [32, 32],
  iconAnchor: [16, 32],
  popupAnchor: [0, -32],
})

const MapComponent: React.FC = () => {
  // 中国中心位置
  const center: [number, number] = [35.8617, 104.1954]
  
  // 示例避难所数据
  const shelters = [
    { id: 1, name: '示例避难所1', lat: 39.9042, lng: 116.4074, city: '北京' },
    { id: 2, name: '示例避难所2', lat: 31.2304, lng: 121.4737, city: '上海' },
    { id: 3, name: '示例避难所3', lat: 23.1291, lng: 113.2644, city: '广州' },
  ]

  return (
    <MapContainer
      center={center}
      zoom={5}
      className="h-full w-full"
      scrollWheelZoom={true}
    >
      <TileLayer
        attribution='&copy; <a href="https://carto.com/">CARTO</a>'
        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
      />
      
      {shelters.map((shelter) => (
        <Marker
          key={shelter.id}
          position={[shelter.lat, shelter.lng]}
          icon={shelterIcon}
        >
          <Popup>
            <div className="text-gray-900">
              <h3 className="font-bold">{shelter.name}</h3>
              <p className="text-sm">{shelter.city}</p>
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  )
}

export default MapComponent