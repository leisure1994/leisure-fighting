-- RegionGen.lua
-- 天道引擎 · 程序化区域生成系统（PCG）
-- 职责：噪声地形、生物群系、WFC 地块折叠、CA 平滑、Poisson Disk 采样、Tiled 导出

RegionGen = RegionGen or {}

-- ============================================================================
-- 常量定义
-- ============================================================================
local PERLIN_PERM = {}
local PERLIN_INITED = false
local PERLIN_PSIZE = 256

local BIOME_NONE = 0
local BIOME_FOREST = 1
local BIOME_DESERT = 2
local BIOME_SNOW = 3
local BIOME_SWAMP = 4
local BIOME_PLAIN = 5

local TILE_EMPTY = 0
local TILE_WALL = 1
local TILE_DOOR = 2
local TILE_ROAD = 3
local TILE_GRASS = 4
local TILE_WATER = 5
local TILE_TREE = 6
local TILE_ORE = 7

-- ============================================================================
-- 内部工具函数
-- ============================================================================

--- 初始化 Perlin 置换表（基于种子）
-- @param seed number 随机种子
local function InitPermutation(seed)
    seed = seed or 0
    math.randomseed(seed)
    PERM = {}
    for i = 0, PERLIN_PSIZE - 1 do
        PERM[i] = i
    end
    -- Fisher-Yates 洗牌
    for i = PERLIN_PSIZE - 1, 1, -1 do
        local j = math.random(0, i)
        PERM[i], PERM[j] = PERM[j], PERM[i]
    end
    -- 双倍缓冲避免越界
    for i = 0, PERLIN_PSIZE - 1 do
        PERM[i + PERLIN_PSIZE] = PERM[i]
    end
    PERLIN_PERM = PERM
    PERLIN_INITED = true
end

--- 缓动曲线 faded(t) = 6t^5 - 15t^4 + 10t^3
-- @param t number 0~1
-- @return number 缓动值
local function Fade(t)
    return t * t * t * (t * (t * 6 - 15) + 10)
end

--- 线性插值
-- @param a number 起点
-- @param b number 终点
-- @param t number 插值系数
-- @return number 插值结果
local function Lerp(a, b, t)
    return a + (b - a) * t
end

--- 梯度点乘（2D 经典 Perlin）
-- @param hash number 哈希值
-- @param x number X 偏移
-- @param y number Y 偏移
-- @return number 梯度值
local function Grad2D(hash, x, y)
    local h = hash % 4
    local u = h < 2 and x or -x
    local v = h % 2 == 0 and y or -y
    -- 修正符号分布
    if h == 0 then return x + y end
    if h == 1 then return -x + y end
    if h == 2 then return x - y end
    return -x - y
end

--- 梯度点乘（3D）
-- @param hash number 哈希值
-- @param x number X 偏移
-- @param y number Y 偏移
-- @param z number Z 偏移
-- @return number 梯度值
local function Grad3D(hash, x, y, z)
    local h = hash % 16
    local u = h < 8 and x or y
    local v = h < 4 and y or (h == 12 or h == 14) and x or z
    return ((h % 2 == 0) and u or -u) + ((h % 4 < 2) and v or -v)
end

-- ============================================================================
-- 噪声函数（纯 Lua 经典 Perlin 数值近似）
-- ============================================================================

--- 获取/刷新 Perlin 置换表
-- @param seed number 种子
local function EnsurePerm(seed)
    if not PERLIN_INITED then
        InitPermutation(seed)
    end
end

--- 2D Perlin 噪声，返回值范围约为 [-1, 1]
-- @param x number X 坐标
-- @param y number Y 坐标
-- @param seed number 随机种子
-- @return number 噪声值
function RegionGen.Perlin2D(x, y, seed)
    EnsurePerm(seed or 0)
    local X = math.floor(x) % PERLIN_PSIZE
    local Y = math.floor(y) % PERLIN_PSIZE
    local xf = x - math.floor(x)
    local yf = y - math.floor(y)
    local u = Fade(xf)
    local v = Fade(yf)

    local p = PERLIN_PERM
    local A = p[X] + Y
    local B = p[X + 1] + Y

    return Lerp(
        Lerp(Grad2D(p[A], xf, yf), Grad2D(p[B], xf - 1, yf), u),
        Lerp(Grad2D(p[A + 1], xf, yf - 1), Grad2D(p[B + 1], xf - 1, yf - 1), u),
        v
    )
end

--- 3D Perlin 噪声，返回值范围约为 [-1, 1]
-- @param x number X 坐标
-- @param y number Y 坐标
-- @param z number Z 坐标
-- @param seed number 随机种子
-- @return number 噪声值
function RegionGen.Perlin3D(x, y, z, seed)
    EnsurePerm(seed or 0)
    local X = math.floor(x) % PERLIN_PSIZE
    local Y = math.floor(y) % PERLIN_PSIZE
    local Z = math.floor(z) % PERLIN_PSIZE
    local xf = x - math.floor(x)
    local yf = y - math.floor(y)
    local zf = z - math.floor(z)
    local u = Fade(xf)
    local v = Fade(yf)
    local w = Fade(zf)

    local p = PERLIN_PERM
    local A = p[X] + Y
    local AA = p[A] + Z
    local AB = p[A + 1] + Z
    local B = p[X + 1] + Y
    local BA = p[B] + Z
    local BB = p[B + 1] + Z

    return Lerp(
        Lerp(
            Lerp(Grad3D(p[AA], xf, yf, zf), Grad3D(p[BA], xf - 1, yf, zf), u),
            Lerp(Grad3D(p[AB], xf, yf - 1, zf), Grad3D(p[BB], xf - 1, yf - 1, zf), u),
            v
        ),
        Lerp(
            Lerp(Grad3D(p[AA + 1], xf, yf, zf - 1), Grad3D(p[BA + 1], xf - 1, yf, zf - 1), u),
            Lerp(Grad3D(p[AB + 1], xf, yf - 1, zf - 1), Grad3D(p[BB + 1], xf - 1, yf - 1, zf - 1), u),
            v
        ),
        w
    )
end

--- 多倍频分形噪声（FBM），支持自定义 persistence 与 lacunarity
-- @param x number X 坐标
-- @param y number Y 坐标
-- @param seed number 随机种子
-- @param octaves number 倍频数量（默认 4）
-- @param persistence number 振幅衰减（默认 0.5）
-- @param lacunarity number 频率倍增（默认 2.0）
-- @return number 归一化到 [0, 1] 的噪声值
function RegionGen.FBM2D(x, y, seed, octaves, persistence, lacunarity)
    octaves = octaves or 4
    persistence = persistence or 0.5
    lacunarity = lacunarity or 2.0
    local total = 0
    local frequency = 1
    local amplitude = 1
    local maxValue = 0

    for i = 1, octaves do
        total = total + RegionGen.Perlin2D(x * frequency, y * frequency, seed + i * 137) * amplitude
        maxValue = maxValue + amplitude
        amplitude = amplitude * persistence
        frequency = frequency * lacunarity
    end

    -- 从 [-1,1] 映射到 [0,1]
    local n = total / maxValue
    return (n + 1) * 0.5
end

--- 3D 分形噪声
-- @param x number X 坐标
-- @param y number Y 坐标
-- @param z number Z 坐标
-- @param seed number 随机种子
-- @param octaves number 倍频数量（默认 4）
-- @param persistence number 振幅衰减（默认 0.5）
-- @param lacunarity number 频率倍增（默认 2.0）
-- @return number 归一化到 [0, 1] 的噪声值
function RegionGen.FBM3D(x, y, z, seed, octaves, persistence, lacunarity)
    octaves = octaves or 4
    persistence = persistence or 0.5
    lacunarity = lacunarity or 2.0
    local total = 0
    local frequency = 1
    local amplitude = 1
    local maxValue = 0

    for i = 1, octaves do
        total = total + RegionGen.Perlin3D(x * frequency, y * frequency, z * frequency, seed + i * 137) * amplitude
        maxValue = maxValue + amplitude
        amplitude = amplitude * persistence
        frequency = frequency * lacunarity
    end

    local n = total / maxValue
    return (n + 1) * 0.5
end

-- ============================================================================
-- 高度图与地形生成
-- ============================================================================

--- 生成高度图（使用真实 Perlin FBM）
-- @param seed number 随机种子
-- @param width number 宽度（默认 64）
-- @param height number 高度（默认 64）
-- @return table 二维高度数组，值域 0~255
function RegionGen.GenerateHeightmap(seed, width, height)
    width = width or 64
    height = height or 64
    local map = {}
    for y = 1, height do
        map[y] = {}
        for x = 1, width do
            local n = RegionGen.FBM2D(x / 32.0, y / 32.0, seed, 5, 0.5, 2.0)
            -- 中心隆起效果，模拟岛屿
            local dx = (x - width / 2) / (width / 2)
            local dy = (y - height / 2) / (height / 2)
            local dist = math.sqrt(dx * dx + dy * dy)
            n = n * (1.0 - dist * 0.4)
            n = math.max(0, math.min(1, n))
            map[y][x] = math.floor(n * 255)
        end
    end
    return map
end

--- 生成温度图（基于纬度/高度混合噪声）
-- @param seed number 随机种子
-- @param width number 宽度
-- @param height number 高度
-- @return table 二维温度数组，值域 0~255
function RegionGen.GenerateTemperatureMap(seed, width, height)
    width = width or 64
    height = height or 64
    local map = {}
    for y = 1, height do
        map[y] = {}
        for x = 1, width do
            local lat = math.abs(y - height / 2) / (height / 2)
            local noise = RegionGen.FBM2D(x / 40.0, y / 40.0, seed + 7, 4, 0.5, 2.0)
            local temp = noise * (1.0 - lat * 0.6) * 255
            map[y][x] = math.floor(math.max(0, math.min(255, temp)))
        end
    end
    return map
end

--- 生成湿度图
-- @param seed number 随机种子
-- @param width number 宽度
-- @param height number 高度
-- @return table 二维湿度数组，值域 0~255
function RegionGen.GenerateMoistureMap(seed, width, height)
    width = width or 64
    height = height or 64
    local map = {}
    for y = 1, height do
        map[y] = {}
        for x = 1, width do
            local noise = RegionGen.FBM2D(x / 35.0, y / 35.0, seed + 13, 4, 0.5, 2.0)
            map[y][x] = math.floor(noise * 255)
        end
    end
    return map
end

--- 基于噪声生成生物群系图
-- 组合温度、湿度、海拔，输出 BIOME_* 常量
-- @param seed number 随机种子
-- @param width number 宽度
-- @param height number 高度
-- @return table 二维生物群系数组
function RegionGen.GenerateBiomeMap(seed, width, height)
    width = width or 64
    height = height or 64
    local heightmap = RegionGen.GenerateHeightmap(seed, width, height)
    local tempmap = RegionGen.GenerateTemperatureMap(seed, width, height)
    local moistmap = RegionGen.GenerateMoistureMap(seed, width, height)
    local biomemap = {}

    for y = 1, height do
        biomemap[y] = {}
        for x = 1, width do
            local h = heightmap[y][x]
            local t = tempmap[y][x]
            local m = moistmap[y][x]
            local biome = BIOME_PLAIN

            if h > 200 then
                biome = BIOME_SNOW
            elseif t > 200 and m < 80 then
                biome = BIOME_DESERT
            elseif t < 60 and m > 150 then
                biome = BIOME_SNOW
            elseif m > 180 and h < 120 then
                biome = BIOME_SWAMP
            elseif m > 120 and t > 80 and t < 180 then
                biome = BIOME_FOREST
            else
                biome = BIOME_PLAIN
            end

            biomemap[y][x] = biome
        end
    end
    return biomemap, heightmap, tempmap, moistmap
end

-- ============================================================================
-- 细胞自动机（CA）平滑
-- ============================================================================

--- 统计位置 (x,y) 周围 8 邻域中 wallVal 的数量
-- @param map table 二维地图
-- @param x number X 坐标
-- @param y number Y 坐标
-- @param wallVal number 被视为墙的数值（默认 1）
-- @return number 邻居墙计数
local function CountWallNeighbors(map, x, y, wallVal)
    wallVal = wallVal or 1
    local count = 0
    local h = #map
    local w = #map[1]
    for dy = -1, 1 do
        for dx = -1, 1 do
            if dx == 0 and dy == 0 then goto continue end
            local nx, ny = x + dx, y + dy
            if nx < 1 or nx > w or ny < 1 or ny > h then
                count = count + 1
            elseif map[ny][nx] == wallVal then
                count = count + 1
            end
            ::continue::
        end
    end
    return count
end

--- 对地图执行细胞自动机平滑，常用于洞穴/墙壁后处理
-- @param map table 二维地图（会原地修改）
-- @param iterations number 迭代次数（默认 4）
-- @param birthLimit number 空白变墙的邻居阈值（默认 5）
-- @param survivalLimit number 墙保留的邻居阈值（默认 4）
-- @param wallVal number 墙的数值（默认 1）
-- @return table 平滑后的地图
function RegionGen.CellularAutomata(map, iterations, birthLimit, survivalLimit, wallVal)
    iterations = iterations or 4
    birthLimit = birthLimit or 5
    survivalLimit = survivalLimit or 4
    wallVal = wallVal or 1
    local h = #map
    local w = #map[1]

    for iter = 1, iterations do
        local newMap = {}
        for y = 1, h do
            newMap[y] = {}
            for x = 1, w do
                local neighbors = CountWallNeighbors(map, x, y, wallVal)
                if map[y][x] == wallVal then
                    newMap[y][x] = (neighbors >= survivalLimit) and wallVal or 0
                else
                    newMap[y][x] = (neighbors >= birthLimit) and wallVal or 0
                end
            end
        end
        map = newMap
    end
    return map
end

-- ============================================================================
-- Poisson Disk 采样（均匀分布兴趣点）
-- ============================================================================

--- 计算 (x1,y1) 与 (x2,y2) 距离的平方
-- @param x1 number
-- @param y1 number
-- @param x2 number
-- @param y2 number
-- @return number 距离平方
local function DistSq(x1, y1, x2, y2)
    local dx = x1 - x2
    local dy = y1 - y2
    return dx * dx + dy * dy
end

--- 在矩形区域内执行 Poisson Disk 采样，返回均匀分布的点列表
-- @param width number 区域宽度
-- @param height number 区域高度
-- @param minDist number 点之间最小距离
-- @param maxAttempts number 每个活跃点尝试次数（默认 30）
-- @return table 点列表，每个元素为 {x, y}
function RegionGen.PoissonDisk(width, height, minDist, maxAttempts)
    minDist = minDist or 10
    maxAttempts = maxAttempts or 30
    local cellSize = minDist / math.sqrt(2)
    local gridW = math.ceil(width / cellSize)
    local gridH = math.ceil(height / cellSize)
    local grid = {}
    for gy = 1, gridH do
        grid[gy] = {}
        for gx = 1, gridW do
            grid[gy][gx] = nil
        end
    end

    local points = {}
    local active = {}

    -- 初始点
    local firstX = math.random() * width
    local firstY = math.random() * height
    table.insert(points, {x = firstX, y = firstY})
    table.insert(active, 1)

    local gx = math.min(gridW, math.max(1, math.floor(firstX / cellSize) + 1))
    local gy = math.min(gridH, math.max(1, math.floor(firstY / cellSize) + 1))
    grid[gy][gx] = 1

    while #active > 0 do
        local idx = math.random(1, #active)
        local pointIdx = active[idx]
        local px = points[pointIdx].x
        local py = points[pointIdx].y
        local found = false

        for i = 1, maxAttempts do
            local angle = math.random() * math.pi * 2
            local dist = minDist + math.random() * minDist
            local nx = px + math.cos(angle) * dist
            local ny = py + math.sin(angle) * dist

            if nx >= 0 and nx <= width and ny >= 0 and ny <= height then
                local ngx = math.min(gridW, math.max(1, math.floor(nx / cellSize) + 1))
                local ngy = math.min(gridH, math.max(1, math.floor(ny / cellSize) + 1))
                local ok = true

                for dy = -1, 1 do
                    for dx = -1, 1 do
                        local cgx = ngx + dx
                        local cgy = ngy + dy
                        if cgx >= 1 and cgx <= gridW and cgy >= 1 and cgy <= gridH then
                            local neighborIdx = grid[cgy][cgx]
                            if neighborIdx then
                                local px2 = points[neighborIdx].x
                                local py2 = points[neighborIdx].y
                                if DistSq(nx, ny, px2, py2) < minDist * minDist then
                                    ok = false
                                    break
                                end
                            end
                        end
                    end
                    if not ok then break end
                end

                if ok then
                    table.insert(points, {x = nx, y = ny})
                    local newIdx = #points
                    grid[ngy][ngx] = newIdx
                    table.insert(active, newIdx)
                    found = true
                    break
                end
            end
        end

        if not found then
            table.remove(active, idx)
        end
    end

    return points
end

-- ============================================================================
-- 简化版 Wave Function Collapse（WFC）
-- ============================================================================

--- 创建候选集副本
-- @param set table 原始集合（数组）
-- @return table 新集合
local function CloneSet(set)
    local copy = {}
    for i = 1, #set do
        copy[i] = set[i]
    end
    return copy
end

--- 检查两个 tile 是否允许邻接
-- @param tiles table tile 定义表，每个 tile 需包含 {name, allow={上,下,左,右}}
-- @param a string tile A 名称
-- @param b string tile B 名称
-- @param dir number 方向: 1=上, 2=下, 3=左, 4=右（a 相对于 b 的方向）
-- @return boolean 是否允许邻接
local function CanAdjoin(tiles, a, b, dir)
    local ta, tb
    for i = 1, #tiles do
        if tiles[i].name == a then ta = tiles[i] end
        if tiles[i].name == b then tb = tiles[i] end
    end
    if not ta or not tb then return false end
    -- a 在 b 的上方 => 检查 ta.allow[1] 是否包含 b，且 tb.allow[2] 是否包含 a
    local opposite = {2, 1, 4, 3}
    local allowed = false
    for _, v in ipairs(ta.allow[dir] or {}) do
        if v == b then allowed = true; break end
    end
    local backAllowed = false
    for _, v in ipairs(tb.allow[opposite[dir]] or {}) do
        if v == a then backAllowed = true; break end
    end
    return allowed and backAllowed
end

--- 基于约束传播的 WFC 地块折叠
-- @param tiles table tile 定义列表，每项 {name="grass", allow={{...},{...},{...},{...}}}
-- @param width number 地图宽度
-- @param height number 地图高度
-- @return table 二维名称数组（失败返回 nil）
function RegionGen.WFC(tiles, width, height)
    width = width or 16
    height = height or 16
    local allNames = {}
    for i = 1, #tiles do
        allNames[i] = tiles[i].name
    end

    -- wave[y][x] = {候选名列表}
    local wave = {}
    for y = 1, height do
        wave[y] = {}
        for x = 1, width do
            wave[y][x] = CloneSet(allNames)
        end
    end

    -- 约束传播：当某格被折叠后，向其邻居传播
    local stack = {}
    local function Propagate(sx, sy)
        table.insert(stack, {x = sx, y = sy})
        while #stack > 0 do
            local cell = table.remove(stack)
            local cx, cy = cell.x, cell.y
            local options = wave[cy][cx]
            if #options == 0 then return false end

            local dirs = {{dx=0, dy=-1, d=1}, {dx=0, dy=1, d=2}, {dx=-1, dy=0, d=3}, {dx=1, dy=0, d=4}}
            for _, dirInfo in ipairs(dirs) do
                local nx, ny = cx + dirInfo.dx, cy + dirInfo.dy
                if nx >= 1 and nx <= width and ny >= 1 and ny <= height then
                    local neighborOptions = wave[ny][nx]
                    local changed = false
                    for i = #neighborOptions, 1, -1 do
                        local candidate = neighborOptions[i]
                        local possible = false
                        for j = 1, #options do
                            if CanAdjoin(tiles, options[j], candidate, dirInfo.d) then
                                possible = true
                                break
                            end
                        end
                        if not possible then
                            table.remove(neighborOptions, i)
                            changed = true
                        end
                    end
                    if changed then
                        if #neighborOptions == 0 then return false end
                        table.insert(stack, {x = nx, y = ny})
                    end
                end
            end
        end
        return true
    end

    -- 选择熵最小的格子进行折叠
    local function Observe()
        local minEntropy = math.huge
        local candidates = {}
        for y = 1, height do
            for x = 1, width do
                local opts = wave[y][x]
                if #opts > 1 then
                    local entropy = #opts + math.random()
                    if entropy < minEntropy then
                        minEntropy = entropy
                        candidates = {{x = x, y = y}}
                    elseif entropy == minEntropy then
                        table.insert(candidates, {x = x, y = y})
                    end
                end
            end
        end
        if #candidates == 0 then return true end -- 全部折叠完成
        local pick = candidates[math.random(1, #candidates)]
        local opts = wave[pick.y][pick.x]
        local chosen = opts[math.random(1, #opts)]
        wave[pick.y][pick.x] = {chosen}
        return Propagate(pick.x, pick.y)
    end

    local maxIter = width * height * 10
    for i = 1, maxIter do
        local done = Observe()
        if done then break end
    end

    -- 检查是否完全折叠
    local result = {}
    for y = 1, height do
        result[y] = {}
        for x = 1, width do
            if #wave[y][x] == 0 then
                return nil -- 失败
            end
            result[y][x] = wave[y][x][1]
        end
    end
    return result
end

-- ============================================================================
-- 资源点布置
-- ============================================================================

--- 根据生物群系和高度自动布置树木、矿石、水源等资源
-- @param heightmap table 二维高度图
-- @param biomemap table 二维生物群系图
-- @param layout table 可写入的地块数组（可选，若提供则原地修改）
-- @return table 资源标记图，每个元素为 {tile=数值, resource=字符串}
function RegionGen.PlaceResources(heightmap, biomemap, layout)
    local h = #biomemap
    local w = #biomemap[1]
    local result = layout or {}
    if not layout then
        for y = 1, h do
            result[y] = {}
            for x = 1, w do
                result[y][x] = {tile = TILE_GRASS, resource = nil}
            end
        end
    end

    for y = 1, h do
        for x = 1, w do
            local biome = biomemap[y][x]
            local alt = heightmap[y][x]
            local tile = TILE_GRASS
            local res = nil

            if alt < 30 then
                tile = TILE_WATER
            elseif biome == BIOME_DESERT then
                tile = TILE_EMPTY
                if math.random() < 0.05 then res = "cactus" end
            elseif biome == BIOME_SNOW then
                tile = TILE_EMPTY
                if math.random() < 0.08 then res = "snow_rock" end
            elseif biome == BIOME_SWAMP then
                tile = TILE_GRASS
                if math.random() < 0.1 then res = "swamp_reed" end
            elseif biome == BIOME_FOREST then
                tile = TILE_GRASS
                if math.random() < 0.25 then res = "tree" end
            else -- PLAIN
                tile = TILE_GRASS
                if math.random() < 0.1 then res = "bush" end
            end

            if alt > 180 and math.random() < 0.15 then
                res = "ore"
            end

            result[y][x] = {tile = tile, resource = res}
        end
    end
    return result
end

-- ============================================================================
-- 区域导出 / 导入（类 Tiled JSON 格式）
-- ============================================================================

--- 将区域数据导出为类 Tiled JSON 字符串
-- @param regionData table 区域数据，需包含 width, height, layout 等字段
-- @return string JSON 字符串
function RegionGen.ExportTiled(regionData)
    regionData = regionData or {}
    local w = regionData.width or (regionData.layout and #regionData.layout[1]) or 32
    local h = regionData.height or (regionData.layout and #regionData.layout) or 32
    local layout = regionData.layout or {}

    local data = {}
    for y = 1, h do
        for x = 1, w do
            local val = layout[y] and layout[y][x]
            if type(val) == "table" then
                table.insert(data, val.tile or 0)
            else
                table.insert(data, val or 0)
            end
        end
    end

    local tiled = {
        width = w,
        height = h,
        tilewidth = 32,
        tileheight = 32,
        layers = {
            {
                name = "ground",
                width = w,
                height = h,
                data = data
            }
        },
        properties = {
            seed = regionData.seed or 0,
            generatedAt = regionData.generatedAt or 0
        }
    }

    if SimpleEncode then
        return SimpleEncode(tiled)
    else
        -- 极简 JSON 回退
        local json = '{"width":' .. w .. ',"height":' .. h .. ',"tilewidth":32,"tileheight":32,"layers":[{"name":"ground","width":' .. w .. ',"height":' .. h .. ',"data":['
        for i = 1, #data do
            json = json .. data[i] .. (i < #data and "," or "")
        end
        json = json ']}],"properties":{"seed":' .. (regionData.seed or 0) .. '}}'
        return json
    end
end

--- 从类 Tiled JSON 字符串导入区域数据
-- @param jsonStr string JSON 字符串
-- @return table 区域数据表
function RegionGen.ImportTiled(jsonStr)
    local data
    if SimpleDecode then
        data = SimpleDecode(jsonStr)
    else
        -- 极简 JSON 解析不支持，返回空结构
        data = {}
    end
    if not data then return nil end

    local layer = data.layers and data.layers[1]
    local w = data.width or 32
    local h = data.height or 32
    local flat = layer and layer.data or {}
    local layout = {}

    for y = 1, h do
        layout[y] = {}
        for x = 1, w do
            local idx = (y - 1) * w + x
            layout[y][x] = flat[idx] or 0
        end
    end

    return {
        width = w,
        height = h,
        layout = layout,
        seed = (data.properties and data.properties.seed) or 0,
        generatedAt = (data.properties and data.properties.generatedAt) or 0
    }
end

-- ============================================================================
-- 调试可视化辅助
-- ============================================================================

--- 将布局转为可打印 ASCII 字符串
-- @param layout table 二维布局数组，元素可为数字或 {tile=数值} 表
-- @return string ASCII 地图字符串
function RegionGen.ToASCII(layout)
    local symbols = {
        [0]=".", [1]="#", [2]="+", [3]="=",
        [4]="\"", [5]="~", [6]="T", [7]="o"
    }
    local lines = {}
    for y = 1, #layout do
        local line = {}
        for x = 1, #layout[y] do
            local val = layout[y][x]
            if type(val) == "table" then
                val = val.tile or 0
            end
            table.insert(line, symbols[val] or "?")
        end
        table.insert(lines, table.concat(line))
    end
    return table.concat(lines, "\n")
end

--- 控制台打印 ASCII 地图（调试用）
-- @param layout table 二维布局数组
function RegionGen.PrintLayout(layout)
    print(RegionGen.ToASCII(layout))
end

-- ============================================================================
-- 经典房间布局生成（保留原有 BSP 房间生成逻辑）
-- ============================================================================

--- 生成区域布局（BSP 房间 + 道路）
-- @param seed number 随机种子
-- @param width number 宽度
-- @param height number 高度
-- @return table, table 二维布局数组 与 房间列表
function RegionGen.GenerateLayout(seed, width, height)
    width = width or 32
    height = height or 32
    math.randomseed(seed)

    local map = {}
    for y = 1, height do
        map[y] = {}
        for x = 1, width do
            map[y][x] = TILE_WALL
        end
    end

    local rooms = {}
    local roomCount = math.random(3, 6)
    for i = 1, roomCount do
        local rw = math.random(4, 8)
        local rh = math.random(4, 8)
        local rx = math.random(2, width - rw - 1)
        local ry = math.random(2, height - rh - 1)

        local overlap = false
        for _, r in ipairs(rooms) do
            if rx < r.x + r.w + 1 and rx + rw + 1 > r.x and
               ry < r.y + r.h + 1 and ry + rh + 1 > r.y then
                overlap = true
                break
            end
        end

        if not overlap then
            table.insert(rooms, {
                x = rx, y = ry, w = rw, h = rh,
                cx = math.floor(rx + rw / 2),
                cy = math.floor(ry + rh / 2)
            })
            for y = ry, ry + rh - 1 do
                for x = rx, rx + rw - 1 do
                    map[y][x] = TILE_EMPTY
                end
            end
        end
    end

    -- 房间之间通路
    for i = 1, #rooms - 1 do
        local r1 = rooms[i]
        local r2 = rooms[i + 1]
        local x, y = r1.cx, r1.cy
        while x ~= r2.cx do
            map[y][x] = TILE_EMPTY
            x = x + (x < r2.cx and 1 or -1)
        end
        while y ~= r2.cy do
            map[y][x] = TILE_EMPTY
            y = y + (y < r2.cy and 1 or -1)
        end
    end

    -- 边缘强制墙
    for y = 1, height do
        map[y][1] = TILE_WALL
        map[y][width] = TILE_WALL
    end
    for x = 1, width do
        map[1][x] = TILE_WALL
        map[height][x] = TILE_WALL
    end

    -- 随机门
    for _, r in ipairs(rooms) do
        local doorSide = math.random(1, 4)
        local dx, dy = r.cx, r.cy
        if doorSide == 1 then dy = r.y - 1
        elseif doorSide == 2 then dy = r.y + r.h
        elseif doorSide == 3 then dx = r.x - 1
        else dx = r.x + r.w
        end
        if dy >= 2 and dy <= height - 1 and dx >= 2 and dx <= width - 1 then
            map[dy][dx] = TILE_DOOR
        end
    end

    return map, rooms
end

--- 在平地寻找可放置建筑的位置
-- @param heightmap table 高度图
-- @param layout table 布局图
-- @param buildingSize number 建筑边长（默认 6）
-- @return table|nil 候选位置 {x, y, h}
function RegionGen.PlaceBuilding(heightmap, layout, buildingSize)
    buildingSize = buildingSize or 6
    local width = #layout[1]
    local height = #layout
    local candidates = {}

    for y = 2, height - buildingSize - 1 do
        for x = 2, width - buildingSize - 1 do
            local flat = true
            local avgHeight = 0
            for by = 0, buildingSize - 1 do
                for bx = 0, buildingSize - 1 do
                    if layout[y + by][x + bx] ~= TILE_EMPTY then
                        flat = false
                        break
                    end
                    avgHeight = avgHeight + heightmap[y + by][x + bx]
                end
                if not flat then break end
            end
            if flat then
                avgHeight = avgHeight / (buildingSize * buildingSize)
                table.insert(candidates, {x = x, y = y, h = avgHeight})
            end
        end
    end

    if #candidates == 0 then return nil end
    table.sort(candidates, function(a, b)
        return math.abs(a.h - 128) < math.abs(b.h - 128)
    end)
    return candidates[1]
end

-- ============================================================================
-- 缓存与持久化
-- ============================================================================

RegionGen.savedRegions = RegionGen.savedRegions or {}

--- 保存区域到内存与 SQLite
-- @param regionId string 区域唯一标识
-- @param regionData table 区域数据表
function RegionGen.SaveRegion(regionId, regionData)
    regionData.savedAt = (GetWorldTime and GetWorldTime()) or os.time()
    RegionGen.savedRegions[regionId] = regionData

    if sqlite3 then
        local db = sqlite3.open("tao_world.db")
        if db then
            db:exec([[
                CREATE TABLE IF NOT EXISTS regions (
                    region_id TEXT PRIMARY KEY,
                    data TEXT,
                    saved_at INTEGER
                );
            ]])
            local stmt = db:prepare("INSERT OR REPLACE INTO regions (region_id, data, saved_at) VALUES (?, ?, ?)")
            if stmt and SimpleEncode then
                stmt:bind_values(regionId, SimpleEncode(regionData), regionData.savedAt)
                stmt:step()
                stmt:finalize()
            end
            db:close()
        end
    end
end

--- 从内存或 SQLite 加载区域
-- @param regionId string 区域唯一标识
-- @return table|nil 区域数据表
function RegionGen.LoadRegion(regionId)
    if RegionGen.savedRegions[regionId] then
        return RegionGen.savedRegions[regionId]
    end

    if sqlite3 then
        local db = sqlite3.open("tao_world.db")
        if db then
            local sql = "SELECT * FROM regions WHERE region_id = '" .. tostring(regionId) .. "'"
            for row in db:nrows(sql) do
                local decoded = (SimpleDecode and SimpleDecode(row.data)) or nil
                if decoded then
                    RegionGen.savedRegions[regionId] = decoded
                    db:close()
                    return decoded
                end
            end
            db:close()
        end
    end
    return nil
end

--- 入口：生成并保存一个完整区域
-- @param regionId string 区域标识
-- @param seed number 随机种子
-- @param layoutW number 布局宽度
-- @param layoutH number 布局高度
-- @param heightW number 高度图宽度
-- @param heightH number 高度图高度
-- @param buildingSize number 建筑尺寸
-- @return table 区域数据表
function RegionGen.GenerateAndSave(regionId, seed, layoutW, layoutH, heightW, heightH, buildingSize)
    seed = seed or math.random(1, 100000)
    local layout, rooms = RegionGen.GenerateLayout(seed, layoutW, layoutH)
    local height = RegionGen.GenerateHeightmap(seed + 1, heightW, heightH)
    local buildingPos = RegionGen.PlaceBuilding(height, layout, buildingSize)

    local regionData = {
        id = regionId,
        seed = seed,
        layout = layout,
        height = height,
        rooms = rooms,
        buildingPos = buildingPos,
        generatedAt = (GetWorldTime and GetWorldTime()) or os.time()
    }

    RegionGen.SaveRegion(regionId, regionData)
    return regionData
end
