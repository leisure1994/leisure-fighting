-- Tracery.lua
-- 天道引擎 · Tracery 文法生成器（增强 Lua 移植版）
-- 协议：MIT / 原始项目 by GalaxyKate

Tracery = Tracery or {}

-- ============================================================================
-- 内部工具函数
-- ============================================================================

--- 按分隔符拆分字符串
-- @param str string 待拆分字符串
-- @param delimiter string 分隔符
-- @return table 结果数组
local function split(str, delimiter)
    local result = {}
    local pattern = "([^" .. delimiter .. "]+)"
    for match in str:gmatch(pattern) do
        table.insert(result, match)
    end
    return result
end

--- 去除首尾空白
-- @param s string
-- @return string
local function trim(s)
    return s:match("^%s*(.-)%s*$")
end

--- 首字母大写
-- @param s string
-- @return string
local function capitalizeWord(s)
    return s:sub(1, 1):upper() .. s:sub(2):lower()
end

--- 英文简单复数化
-- @param text string
-- @return string
local function pluralize(text)
    local last = text:sub(-1)
    local last2 = text:sub(-2)
    if last == "s" or last == "x" or last == "z" or last2 == "ch" or last2 == "sh" then
        return text .. "es"
    elseif last == "y" and not text:sub(-2, -2):match("[aeiou]") then
        return text:sub(1, -2) .. "ies"
    else
        return text .. "s"
    end
end

--- 英文简单过去式化
-- @param text string
-- @return string
local function pastTense(text)
    local last = text:sub(-1)
    if last == "e" then
        return text .. "d"
    else
        return text .. "ed"
    end
end

--- 反转字符串
-- @param text string
-- @return string
local function reverseString(text)
    local chars = {}
    for i = #text, 1, -1 do
        table.insert(chars, text:sub(i, i))
    end
    return table.concat(chars)
end

-- ============================================================================
-- 修饰符系统
-- ============================================================================

--- 对文本应用 Tracery 修饰符
-- @param text string 原始文本
-- @param modifier string 修饰符名称
-- @return string 修饰后的文本
function Tracery.ApplyModifier(text, modifier)
    modifier = trim(modifier or "")
    if modifier == "a" then
        local first = text:sub(1, 1):lower()
        if first == "a" or first == "e" or first == "i" or first == "o" or first == "u" then
            return "an " .. text
        else
            return "a " .. text
        end
    elseif modifier == "A" then
        local first = text:sub(1, 1):lower()
        if first == "a" or first == "e" or first == "i" or first == "o" or first == "u" then
            return "An " .. text
        else
            return "A " .. text
        end
    elseif modifier == "s" then
        return pluralize(text)
    elseif modifier == "ed" then
        return pastTense(text)
    elseif modifier == "capitalize" then
        return capitalizeWord(text)
    elseif modifier == "upper" then
        return text:upper()
    elseif modifier == "lower" then
        return text:lower()
    elseif modifier == "reverse" then
        return reverseString(text)
    end
    return text
end

-- ============================================================================
-- 符号展开核心
-- ============================================================================

--- 展开单个文法符号，如 #prefix#
-- @param symbol string 完整符号字符串，包含两侧 #
-- @param grammar table 文法表
-- @param expansions table 本次展开循环保护表
-- @return string 展开结果
function Tracery.ExpandSymbol(symbol, grammar, expansions)
    expansions = expansions or {}
    local key = trim(symbol:sub(2, -2))
    if not key or key == "" then return symbol end

    local baseKey = key
    local modifier = nil
    local dotPos = key:find("%.")
    if dotPos then
        baseKey = key:sub(1, dotPos - 1)
        modifier = key:sub(dotPos + 1)
    end

    local choices = grammar[baseKey]
    if not choices then return "[" .. baseKey .. "]" end
    if type(choices) == "string" then choices = { choices } end
    if #choices == 0 then return "[" .. baseKey .. "]" end

    local attempt = 0
    local selected
    repeat
        local idx = math.random(1, #choices)
        selected = choices[idx]
        attempt = attempt + 1
    until (not expansions[selected]) or attempt > 10

    expansions[selected] = true
    local result = Tracery.ExpandString(selected, grammar, expansions)
    expansions[selected] = nil

    if modifier then
        result = Tracery.ApplyModifier(result, modifier)
    end
    return result
end

--- 展开字符串中所有的 #symbol#
-- @param str string 待展开字符串
-- @param grammar table 文法表
-- @param expansions table 循环保护表
-- @return string 展开结果
function Tracery.ExpandString(str, grammar, expansions)
    local result = str
    local safety = 0
    while result:find("#") and safety < 50 do
        safety = safety + 1
        result = result:gsub("#([%w_%.]+)#", function(sym)
            return Tracery.ExpandSymbol("#" .. sym .. "#", grammar, expansions)
        end)
    end
    return result
end

--- 入口：从指定规则开始展开
-- @param startRule string 起始规则名（默认 "origin"）
-- @param grammar table 文法表
-- @return string 最终文本
function Tracery.Flatten(startRule, grammar)
    if not grammar then return "" end
    startRule = startRule or "origin"
    local origin = grammar[startRule]
    if not origin then return "" end
    if type(origin) == "string" then
        return Tracery.ExpandString(origin, grammar, {})
    elseif type(origin) == "table" then
        local idx = math.random(1, #origin)
        return Tracery.ExpandString(origin[idx], grammar, {})
    end
    return ""
end

-- ============================================================================
-- 动态语法扩展
-- ============================================================================

--- 向文法动态添加一条规则（入栈式）
-- @param grammar table 文法表
-- @param key string 规则名
-- @param choices table|string 新选项或选项列表
function Tracery.PushRule(grammar, key, choices)
    if not grammar then return end
    if type(choices) == "string" then choices = {choices} end
    if not grammar[key] then
        grammar[key] = {}
    end
    if type(grammar[key]) == "string" then
        grammar[key] = {grammar[key]}
    end
    for i = 1, #choices do
        table.insert(grammar[key], choices[i])
    end
end

--- 从文法动态移除最后添加的规则选项（出栈式）
-- @param grammar table 文法表
-- @param key string 规则名
-- @return string|nil 被弹出的值
function Tracery.PopRule(grammar, key)
    if not grammar or not grammar[key] then return nil end
    if type(grammar[key]) == "string" then
        local val = grammar[key]
        grammar[key] = nil
        return val
    end
    return table.remove(grammar[key])
end

-- ============================================================================
-- 批量生成
-- ============================================================================

--- 批量生成去重结果
-- @param startRule string 起始规则名
-- @param grammar table 文法表
-- @param count number 生成数量
-- @return table 去重后的结果数组
function Tracery.BatchFlatten(startRule, grammar, count)
    count = count or 10
    local results = {}
    local seen = {}
    for i = 1, count * 3 do -- 允许一定冗余以获取足够去重结果
        if #results >= count then break end
        local txt = Tracery.Flatten(startRule, grammar)
        if not seen[txt] then
            seen[txt] = true
            table.insert(results, txt)
        end
    end
    return results
end

-- ============================================================================
-- 动作标签解析（简化 inline action）
-- ============================================================================

--- 解析 Tracery 生成字符串中的动作标签
-- 支持格式：[+tag:value]（添加规则）、[key:value]（普通动作）
-- @param text string 生成后的文本
-- @return table 动作列表，每个元素为 {type="addRule"|"action", key=..., value=...}
-- @return string 去除动作标签后的纯文本
function Tracery.ParseActions(text)
    local actions = {}
    local cleanText = text:gsub("%[([+%-]?)([%w_]+):([^%]]+)%]", function(prefix, key, value)
        if prefix == "+" then
            table.insert(actions, {type = "addRule", key = key, value = trim(value)})
        else
            table.insert(actions, {type = "action", key = key, value = trim(value)})
        end
        return ""
    end)
    return actions, trim(cleanText)
end

--- 展开并同时提取动作
-- @param startRule string 起始规则
-- @param grammar table 文法表
-- @return string 纯文本
-- @return table 动作列表
function Tracery.FlattenWithActions(startRule, grammar)
    local raw = Tracery.Flatten(startRule, grammar)
    local actions, clean = Tracery.ParseActions(raw)
    return clean, actions
end

-- ============================================================================
-- 保存 / 加载增强
-- ============================================================================

--- 保存文法到文件（优先 JSONFile，否则纯文本回退）
-- @param grammar table 文法表
-- @param filepath string 文件路径
-- @return boolean 是否成功
function Tracery.SaveGrammar(grammar, filepath)
    local encoded = (SimpleEncode and SimpleEncode(grammar)) or nil
    if not encoded then
        -- 极简序列化（仅支持一层字符串/数组）
        local parts = {}
        for k, v in pairs(grammar) do
            local val
            if type(v) == "table" then
                local items = {}
                for i = 1, #v do items[i] = '"' .. tostring(v[i]):gsub('"', '\\"') .. '"' end
                val = "[" .. table.concat(items, ",") .. "]"
            else
                val = '"' .. tostring(v):gsub('"', '\\"') .. '"'
            end
            table.insert(parts, '"' .. k .. '":' .. val)
        end
        encoded = "{" .. table.concat(parts, ",") .. "}"
    end

    if File then
        local file = File()
        if file:Open(filepath, FILE_WRITE) then
            file:WriteString(encoded)
            file:Close()
            return true
        end
    end

    -- 纯 Lua 文件回退
    local fh = io.open(filepath, "w")
    if fh then
        fh:write(encoded)
        fh:close()
        return true
    end
    return false
end

--- 从文法文件加载
-- @param filepath string 文件路径
-- @return table|nil 文法表
function Tracery.LoadGrammar(filepath)
    local str = nil
    if File then
        local file = File()
        if file:Open(filepath, FILE_READ) then
            str = file:ReadString()
            file:Close()
        end
    end
    if not str then
        local fh = io.open(filepath, "r")
        if fh then
            str = fh:read("*a")
            fh:close()
        end
    end
    if not str then return nil end
    if SimpleDecode then
        return SimpleDecode(str)
    end
    -- 极简解析不支持则返回 nil
    return nil
end

-- ============================================================================
-- 预设文法库（50+ 词条池）
-- ============================================================================

Tracery.PRESETS = {}

Tracery.PRESETS.item_name = {
    origin = {"#prefix# #material# #weapon#", "#prefix# #weapon#", "#material# #weapon# of #suffix#"},
    prefix = {
        "发光的", "诅咒的", "传奇的", "锈蚀的", "精致的", "破碎的", "神圣的", "黑暗的", "炽热的", "冰冷的",
        "风化的", "古老的", "崭新的", "沉重的", "轻盈的", "带血的", "刻印的", "附魔的", "封印的", "觉醒的",
        "闪耀的", "幽暗的", "狂暴的", "宁静的", "迅捷的", "迟缓的", "巨人的", "矮人的", "精灵的", "龙族的",
        "星辰的", "深渊的", "癫狂的", "守护的", "救赎的", "毁灭的", "再生的", "枯萎的", "不朽的", "易碎的"
    },
    material = {
        "玄钢", "水晶", "碳纤维", "古木", "秘银", "黑曜石", "泰坦合金", "星云丝绸", "龙骨", "灵石",
        "陨铁", "血铜", "霜银", "影金", "翡翠", "红玛瑙", "青金石", "琥珀", "珍珠母", "黑檀木",
        "白象牙", "雷纹钢", "流沙", "冰川碎片", "火山玻璃", "苔藓覆盖的石", "时光砂", "虚空布", "圣光结晶", "恶魔皮革"
    },
    weapon = {
        "长剑", "法杖", "能量炮", "匕首", "巨斧", "战锤", "长弓", "短弩", "拳套", "链鞭",
        "镰刀", "长枪", "双刃剑", "手杖", "魔导书", "飞刀", "盾斧", "太刀", "软剑", "刺剑",
        "斩马刀", "钩爪", "指虎", "铁扇", "笛子", "琵琶", "三叉戟", "流星锤", "钢爪", "魂灯"
    },
    suffix = {
        "毁灭", "救赎", "风暴", "烈焰", "寒冰", "雷霆", "暗影", "光明", "虚空", "时间",
        "命运", "轮回", "死亡", "重生", "疯狂", "宁静", "贪婪", "傲慢", "暴食", "嫉妒",
        "裁决", "审判", "宽恕", "遗忘", "铭记", "追寻", "迷失", "觉醒", "沉睡", "永恒"
    }
}

Tracery.PRESETS.location_name = {
    origin = {"#adj# #place#", "#place# of #noun#", "#prefix##place#"},
    adj = {
        "幽暗的", "荒芜的", "神秘的", "古老的", "废弃的", "繁华的", "寂静的", "风暴肆虐的", "永恒的", "被遗忘的",
        "潮湿的", "干燥的", "寒冷的", "炎热的", "多雾的", "清澈的", "扭曲的", "宁静的", "混乱的", "神圣的",
        "腐朽的", "新生的", "封闭的", "开放的", "高耸的", "深邃的", "狭窄的", "广阔的", "崎岖的", "平坦的",
        "金色的", "银色的", "漆黑的", "雪白的", "猩红的", "碧蓝的", "翠绿的", "紫晶的", "橙黄的", "灰白的"
    },
    place = {
        "森林", "沙漠", "沼泽", "山脉", "峡谷", "废墟", "城市", "村庄", "要塞", "祭坛",
        "洞穴", "平原", "湖泊", "河流", "岛屿", "半岛", "高原", "盆地", "丘陵", "冰川",
        "塔楼", "地牢", "迷宫", "花园", "墓地", "神庙", "宫殿", "酒馆", "集市", "港口",
        "灯塔", "磨坊", "桥梁", "隧道", "矿井", "农场", "牧场", "军营", "修道院", "学院"
    },
    noun = {
        "晨曦", "暮光", "群星", "深渊", "风暴", "烈火", "寒霜", "雷霆", "幻影", "幽灵",
        "巨龙", "骑士", "王者", "贤者", "先知", "恶魔", "天使", "亡灵", "生灵", "元素",
        "梦境", "记忆", "时光", "命运", "轮回", "真理", "谎言", "希望", "绝望", "荣耀"
    },
    prefix = {
        "新", "旧", "东", "西", "南", "北", "上", "下", "前", "后",
        "外", "内", "主", "副", "大", "小", "高", "低", "远", "近"
    }
}

Tracery.PRESETS.npc_catchphrase = {
    origin = {"#greet# #statement#", "#statement#", "#greet# #question#", "#exclaim#"},
    greet = {
        "喂！", "嘿。", "你好啊。", "哼。", "哟。", "嗨。", "哟呵。", "哎。", "哟，新人？", "久等了。",
        "欢迎。", "别来无恙。", "又见面了。", "初次见面。", "别挡路。", "借过。", "停下。", "早安。", "晚安。", "日安。"
    },
    statement = {
        "这鬼天气没一天让人省心。",
        "我闻到金币的味道了。",
        "别惹我，我今天心情不好。",
        "有事快说，我这很忙。",
        "你来得正好，我需要人手。",
        "最近不太平，小心点。",
        "这世道，变了。",
        "听说过北方的传说吗？",
        "别相信那些商人。",
        "酒是这世上最好的东西。",
        "我已经三天没睡觉了。",
        "阴影里有什么在窥视。",
        "每个人都带着秘密。",
        " money 买不来一切，但大部分可以。",
        "握紧你的武器。",
        "没有什么比自由更可贵。",
        "命运喜欢捉弄人。",
        "我曾是个冒险者，直到……",
        "这里曾经很繁荣。",
        "风声中有低语。"
    },
    question = {
        "你找我有什么事？",
        "你看起来不是本地人？",
        "要带点什么吗？",
        "听说过那个传闻吗？",
        "你也觉得这里不对劲吧？",
        "愿意帮我一个忙吗？",
        "你知道出口在哪吗？",
        "我们是不是在哪见过？",
        "你的日子过得怎么样？",
        "相信命运吗？"
    },
    exclaim = {
        "天哪！",
        "不可能！",
        "真是太好了！",
        "简直无法相信！",
        "该死！",
        "小心！",
        "快跑！",
        "万岁！",
        "糟了！",
        "太好了！"
    }
}

Tracery.PRESETS.quest_title = {
    origin = {"#verb# #target#", "#adj# #target# 的 #noun#", "#target# 的 #verb#"},
    verb = {
        "追捕", "寻找", "护送", "消灭", "调查", "收集", "摧毁", "守护", "探索", "夺回",
        "解救", "追踪", "伏击", "刺探", "审问", "净化", "封印", "唤醒", "埋葬", "点燃",
        "修复", "偷窃", "替换", "测试", "证明", "见证", "终结", "开始", "阻止", "协助"
    },
    target = {
        "巨龙", "叛徒", "商人", "幽灵", "巫师", "兽人", "盗贼", "王子", "公主", "将军",
        "恶魔", "天使", "元素", "亡灵", "巨魔", "精灵", "矮人", "哥布林", "史莱姆", "树人",
        "古代遗物", "失踪的货物", "被诅咒的圣杯", "禁忌之书", "失落的卷轴", "神秘的符文", "王冠", "钥匙", "门", "镜子"
    },
    adj = {
        "被遗忘的", "危险的", "高贵的", "堕落的", "神圣的", "邪恶的", "古老的", "年轻的", "孤独的", "疯狂的",
        "勇敢的", "懦弱的", "狡猾的", "忠诚的", "背叛的", "盲目的", "睿智的", "愚蠢的", "仁慈的", "残暴的"
    },
    noun = {
        "秘密", "命运", "荣耀", "耻辱", "遗产", "诅咒", "祝福", "罪孽", "救赎", "审判",
        "真相", "谎言", "梦境", "噩梦", "希望", "绝望", "友谊", "仇恨", "爱情", "遗憾"
    }
}

Tracery.PRESETS.faction_name = {
    origin = {"#prefix# #noun#", "#adj# #noun#", "#noun# of #suffix#", "#prefix##noun#"},
    prefix = {
        "铁", "血", "金", "银", "黑", "白", "红", "蓝", "绿", "紫",
        "影", "光", "风", "雷", "火", "冰", "沙", "海", "星", "月",
        "龙", "鹰", "狼", "狮", "蛇", "熊", "鸦", "狐", "虎", "鲸"
    },
    noun = {
        "之手", "兄弟会", "联盟", "帝国", "王国", "军团", "教团", "氏族", "家族", "公会",
        "议会", "法庭", "卫队", "先锋", "游侠", "刺客", "骑士", "僧侣", "先知", "贤者",
        "守望者", "流浪者", "掠夺者", "守护者", "征服者", "复仇者", "审判者", "见证者", "追寻者", "迷失者"
    },
    adj = {
        "永恒的", "不朽的", "隐秘的", "狂热的", "冷酷的", "高贵的", "卑微的", "贪婪的", "骄傲的", "谦逊的",
        "残暴的", "仁慈的", "狡猾的", "忠诚的", "绝望的", "希望的", "疯狂的", "宁静的", "堕落的", "觉醒的"
    },
    suffix = {
        "黎明", "黄昏", "午夜", "正午", "春", "夏", "秋", "冬", "风暴", "烈焰",
        "寒冰", "雷霆", "深渊", "天堂", "地狱", "虚空", "群星", "太阳", "月亮", "大地"
    }
}

-- ============================================================================
-- 便捷函数
-- ============================================================================

--- 生成装备名
-- @param prefixPool table 前缀池（可选）
-- @param materialPool table 材料池（可选）
-- @param weaponPool table 武器池（可选）
-- @return string 装备名
function Tracery.GenerateItemName(prefixPool, materialPool, weaponPool)
    local grammar = {
        origin = {"#prefix# #material# #weapon#", "#prefix# #weapon#"},
        prefix = prefixPool or Tracery.PRESETS.item_name.prefix,
        material = materialPool or Tracery.PRESETS.item_name.material,
        weapon = weaponPool or Tracery.PRESETS.item_name.weapon
    }
    return Tracery.Flatten("origin", grammar)
end

--- 生成 NPC 口头禅
-- @param personality string 性格标签（保留参数，当前未影响结果）
-- @return string 口头禅
function Tracery.GenerateCatchphrase(personality)
    return Tracery.Flatten("origin", Tracery.PRESETS.npc_catchphrase)
end

--- 生成地点名
-- @return string 地点名
function Tracery.GenerateLocationName()
    return Tracery.Flatten("origin", Tracery.PRESETS.location_name)
end

--- 生成任务标题
-- @return string 任务标题
function Tracery.GenerateQuestTitle()
    return Tracery.Flatten("origin", Tracery.PRESETS.quest_title)
end

--- 生成派系名
-- @return string 派系名
function Tracery.GenerateFactionName()
    return Tracery.Flatten("origin", Tracery.PRESETS.faction_name)
end
