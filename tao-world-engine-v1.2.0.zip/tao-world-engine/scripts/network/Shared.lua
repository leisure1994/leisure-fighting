-- Shared.lua
-- 天道引擎 · 网络共享层 + 远程事件注册表 + JSON 工具箱
-- 职责：注册所有 Client <-> Server 远程事件、提供序列化/反序列化、类型辅助

-- ═══════════════════════════════════════════════════════════════════════════
-- 网络事件分类常量
-- ═══════════════════════════════════════════════════════════════════════════

TAO_EVENT_CATEGORY = {
    SYSTEM          = 0x01, -- 系统级事件（Key 代理、连接状态、调试）
    DERIVATION      = 0x02, -- 世界推衍相关
    NPC             = 0x03, -- NPC Agent 相关
    REGION          = 0x04, -- 区域发现与管理
    TRADE           = 0x05, -- 交易与经济
    PARTY           = 0x06, -- 组队与社交
    STATE_SYNC      = 0x07, -- 世界状态同步
    DEBUG           = 0x08, -- 调试与监控
    KEY_PROXY       = 0x09, -- 玩家 API Key 代理
    MEMPALACE       = 0x0A, -- 记忆宫殿
}

-- 具体的远程事件名称常量，避免拼写错误
TAO_REMOTE_EVENTS = {
    -- Client -> Server
    C2S_SET_PLAYER_API_KEY      = "SetPlayerAPIKey",
    C2S_SET_PROVIDER_API_KEY    = "SetProviderAPIKey",
    C2S_REQUEST_NPC_DIALOG      = "RequestNpcDialog",
    C2S_PLAYER_WORLD_INTERACTION = "PlayerWorldInteraction",
    C2S_REQUEST_REGION_INFO     = "RequestRegionInfo",
    C2S_TRADE_REQUEST           = "TradeRequest",
    C2S_TRADE_ACCEPT            = "TradeAccept",
    C2S_TRADE_CANCEL            = "TradeCancel",
    C2S_PARTY_INVITE            = "PartyInvite",
    C2S_PARTY_ACCEPT            = "PartyAccept",
    C2S_PARTY_LEAVE             = "PartyLeave",
    C2S_STREAM_POLL             = "StreamPoll",
    C2S_DEBUG_QUERY             = "DebugQuery",

    -- Server -> Client
    S2C_TAO_NARRATIVE           = "TaoNarrative",
    S2C_NPC_ACTION_BUBBLE       = "NpcActionBubble",
    S2C_API_KEY_ACCEPTED        = "ApiKeyAccepted",
    S2C_API_KEY_REJECTED        = "ApiKeyRejected",
    S2C_PROVIDER_KEY_ACCEPTED   = "ProviderKeyAccepted",
    S2C_PROVIDER_KEY_REJECTED   = "ProviderKeyRejected",
    S2C_REGION_DISCOVERY        = "RegionDiscovery",
    S2C_REGION_UPDATE           = "RegionUpdate",
    S2C_WORLD_STATE_UPDATE      = "WorldStateUpdate",
    S2C_WORLD_STATE_DELTA       = "WorldStateDelta",
    S2C_NPC_STRATEGY_RESULT     = "NpcStrategyResult",
    S2C_NPC_EMOTION_UPDATE      = "NpcEmotionUpdate",
    S2C_TRADE_OFFER             = "TradeOffer",
    S2C_TRADE_RESULT            = "TradeResult",
    S2C_PARTY_UPDATE            = "PartyUpdate",
    S2C_STREAM_CHUNK            = "StreamChunk",
    S2C_STREAM_DONE             = "StreamDone",
    S2C_DEBUG_RESPONSE          = "DebugResponse",
    S2C_SYSTEM_MESSAGE          = "SystemMessage",
}

-- ═══════════════════════════════════════════════════════════════════════════
-- 远程事件注册
-- ═══════════════════════════════════════════════════════════════════════════

--- 注册所有天道引擎相关的远程事件
function RegisterTaoRemoteEvents()
    -- 系统与 Key 代理 (Client -> Server)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.C2S_SET_PLAYER_API_KEY)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.C2S_SET_PROVIDER_API_KEY)

    -- 推衍与交互 (Client -> Server)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.C2S_REQUEST_NPC_DIALOG)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.C2S_PLAYER_WORLD_INTERACTION)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.C2S_REQUEST_REGION_INFO)

    -- 交易 (Client -> Server)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.C2S_TRADE_REQUEST)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.C2S_TRADE_ACCEPT)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.C2S_TRADE_CANCEL)

    -- 组队 (Client -> Server)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.C2S_PARTY_INVITE)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.C2S_PARTY_ACCEPT)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.C2S_PARTY_LEAVE)

    -- 流式与调试 (Client -> Server)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.C2S_STREAM_POLL)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.C2S_DEBUG_QUERY)

    -- 服务端 -> 客户端：叙事与推衍
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_TAO_NARRATIVE)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_WORLD_STATE_UPDATE)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_WORLD_STATE_DELTA)

    -- 服务端 -> 客户端：NPC
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_NPC_ACTION_BUBBLE)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_NPC_STRATEGY_RESULT)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_NPC_EMOTION_UPDATE)

    -- 服务端 -> 客户端：系统反馈
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_API_KEY_ACCEPTED)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_API_KEY_REJECTED)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_PROVIDER_KEY_ACCEPTED)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_PROVIDER_KEY_REJECTED)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_SYSTEM_MESSAGE)

    -- 服务端 -> 客户端：区域
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_REGION_DISCOVERY)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_REGION_UPDATE)

    -- 服务端 -> 客户端：交易与组队
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_TRADE_OFFER)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_TRADE_RESULT)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_PARTY_UPDATE)

    -- 服务端 -> 客户端：流式与调试
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_STREAM_CHUNK)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_STREAM_DONE)
    network:RegisterRemoteEvent(TAO_REMOTE_EVENTS.S2C_DEBUG_RESPONSE)
end

-- ═══════════════════════════════════════════════════════════════════════════
-- 类型辅助函数
-- ═══════════════════════════════════════════════════════════════════════════

--- 判断一个表是否是数组（正整数连续索引）
-- @param t table 待检测的表
-- @return boolean 是否为数组
function IsArray(t)
    if type(t) ~= "table" then return false end
    local maxIndex = 0
    local count = 0
    for k, _ in pairs(t) do
        if type(k) ~= "number" or k <= 0 or math.floor(k) ~= k then
            return false
        end
        if k > maxIndex then maxIndex = k end
        count = count + 1
    end
    return maxIndex == count
end

--- 深拷贝一个 Lua 值（支持嵌套表，循环引用安全）
-- @param value any 待拷贝的值
-- @param seen table|nil 内部使用的循环引用检测表
-- @return any 深拷贝后的值
function DeepCopy(value, seen)
    seen = seen or {}
    local t = type(value)
    if t ~= "table" then return value end
    if seen[value] then return seen[value] end
    local copy = {}
    seen[value] = copy
    for k, v in pairs(value) do
        copy[DeepCopy(k, seen)] = DeepCopy(v, seen)
    end
    return copy
end

--- 将两个表合并，后传入的表会覆盖前表的同名键（深拷贝合并）
-- @param base table 基础表
-- @param override table 覆盖表
-- @return table 合并后的新表
function MergeTables(base, override)
    local result = DeepCopy(base or {})
    if type(override) == "table" then
        for k, v in pairs(override) do
            if type(result[k]) == "table" and type(v) == "table" and not IsArray(v) then
                result[k] = MergeTables(result[k], v)
            else
                result[k] = DeepCopy(v)
            end
        end
    end
    return result
end

--- 安全地获取字符串长度，支持 Unicode（按字符计数）
-- @param str string 输入字符串
-- @return number 字符数
function Utf8Length(str)
    if type(str) ~= "string" then return 0 end
    local len = 0
    for _ in str:gmatch("[%z\1-\127\194-\244][\128-\191]*") do
        len = len + 1
    end
    return len
end

--- 将字符串截断到指定长度（Unicode 安全）
-- @param str string 输入字符串
-- @param maxLen number 最大长度
-- @return string 截断后的字符串
function Utf8Truncate(str, maxLen)
    if type(str) ~= "string" then return "" end
    if Utf8Length(str) <= maxLen then return str end
    local result = {}
    local count = 0
    for char in str:gmatch("[%z\1-\127\194-\244][\128-\191]*") do
        if count >= maxLen then break end
        table.insert(result, char)
        count = count + 1
    end
    return table.concat(result)
end

-- ═══════════════════════════════════════════════════════════════════════════
-- JSON 序列化（增强版）
-- ═══════════════════════════════════════════════════════════════════════════

local ENCODE_SEEN = nil

--- 将 Lua 值编码为 JSON 字符串。
-- 增强功能：正确处理嵌套表、循环引用检测、空表、数字键。
-- @param value any 待编码的值
-- @param seen table|nil 内部循环引用检测表
-- @return string JSON 字符串
function SimpleEncode(value, seen)
    seen = seen or {}
    local t = type(value)

    if t == "number" then
        if value ~= value then
            return "null" -- NaN
        end
        local inf = 1 / 0
        if value == inf or value == -inf then
            return "null"
        end
        return tostring(value)
    elseif t == "boolean" then
        return value and "true" or "false"
    elseif t == "string" then
        return "\"" .. value:gsub("\\", "\\\\")
                           :gsub("\"", "\\\"")
                           :gsub("\b", "\\b")
                           :gsub("\f", "\\f")
                           :gsub("\n", "\\n")
                           :gsub("\r", "\\r")
                           :gsub("\t", "\\t")
                           :gsub("[%z\1-\31]", function(c)
                               return string.format("\\u%04x", string.byte(c))
                           end) .. "\""
    elseif t == "table" then
        if seen[value] then
            return "null" -- 循环引用输出 null
        end
        seen[value] = true

        -- 处理空表
        local nextPair = next(value)
        if nextPair == nil then
            return "{}"
        end

        local isArr = IsArray(value)
        if isArr then
            local items = {}
            for _, v in ipairs(value) do
                table.insert(items, SimpleEncode(v, seen))
            end
            return "[" .. table.concat(items, ",") .. "]"
        else
            local items = {}
            for k, v in pairs(value) do
                local keyStr
                if type(k) == "string" then
                    keyStr = "\"" .. k:gsub("\\", "\\\\"):gsub("\"", "\\\"") .. "\""
                elseif type(k) == "number" then
                    keyStr = "\"" .. tostring(k) .. "\""
                else
                    keyStr = "\"" .. tostring(k) .. "\""
                end
                table.insert(items, keyStr .. ":" .. SimpleEncode(v, seen))
            end
            return "{" .. table.concat(items, ",") .. "}"
        end
    elseif t == "nil" then
        return "null"
    else
        return "null"
    end
end

-- ═══════════════════════════════════════════════════════════════════════════
-- JSON 解析（增强版）
-- ═══════════════════════════════════════════════════════════════════════════

--- 尝试使用 Urho3D 的 JSONValue 解析字符串，失败后使用纯 Lua 回退解析器。
-- @param str string JSON 字符串
-- @return any|nil 解析后的 Lua 值
-- @return string|nil 错误信息
function SimpleDecode(str)
    if type(str) ~= "string" or str == "" then
        return nil, "输入为空或非字符串"
    end

    -- 优先尝试引擎内置 JSONValue
    if _G.JSONValue then
        local ok, json = pcall(function()
            local jv = JSONValue()
            if jv:FromString(str) then
                return JsonValueToLua(jv)
            end
            return nil
        end)
        if ok and json ~= nil then
            return json
        end
    end

    -- 回退到纯 Lua 解析器
    local result, pos = ParseJsonValue(str, 1)
    if result == nil then
        return nil, pos or "JSON 解析失败"
    end

    -- 跳过末尾空白
    pos = SkipWhitespace(str, pos)
    if pos <= #str then
        return nil, "JSON 末尾存在多余字符"
    end

    return result
end

--- 将 Urho3D JSONValue 转换为 Lua 表/值
-- @param jv JSONValue Urho3D JSON 值对象
-- @return any 转换后的 Lua 值
function JsonValueToLua(jv)
    if not jv then return nil end
    if jv:IsObject() then
        local t = {}
        local keys = jv:GetMemberNames()
        for _, k in ipairs(keys) do
            t[k] = JsonValueToLua(jv:Get(k))
        end
        return t
    elseif jv:IsArray() then
        local t = {}
        for i = 0, jv:GetSize() - 1 do
            table.insert(t, JsonValueToLua(jv:Get(i)))
        end
        return t
    elseif jv:IsString() then
        return jv:GetString()
    elseif jv:IsBool() then
        return jv:GetBool()
    elseif jv:IsInt() then
        return jv:GetInt()
    elseif jv:IsUInt() then
        return jv:GetUInt()
    elseif jv:IsDouble() then
        return jv:GetDouble()
    elseif jv:IsNull() then
        return nil
    else
        return nil
    end
end

-- ═══════════════════════════════════════════════════════════════════════════
-- 纯 Lua JSON 回退解析器（支持 object/array/string/number/boolean/null）
-- ═══════════════════════════════════════════════════════════════════════════

local function SkipWhitespace(str, pos)
    while pos <= #str do
        local c = str:sub(pos, pos)
        if c == " " or c == "\t" or c == "\n" or c == "\r" then
            pos = pos + 1
        else
            break
        end
    end
    return pos
end

local function ParseString(str, pos)
    if str:sub(pos, pos) ~= "\"" then
        return nil, pos, "字符串必须以双引号开始"
    end
    pos = pos + 1
    local result = {}
    while pos <= #str do
        local c = str:sub(pos, pos)
        if c == "\"" then
            pos = pos + 1
            return table.concat(result), pos
        elseif c == "\\" then
            pos = pos + 1
            if pos > #str then return nil, pos, "字符串转义不完整" end
            local ec = str:sub(pos, pos)
            if ec == "\"" then table.insert(result, "\"")
            elseif ec == "\\" then table.insert(result, "\\")
            elseif ec == "/" then table.insert(result, "/")
            elseif ec == "b" then table.insert(result, "\b")
            elseif ec == "f" then table.insert(result, "\f")
            elseif ec == "n" then table.insert(result, "\n")
            elseif ec == "r" then table.insert(result, "\r")
            elseif ec == "t" then table.insert(result, "\t")
            elseif ec == "u" then
                if pos + 4 > #str then return nil, pos, "Unicode 转义不完整" end
                local hex = str:sub(pos + 1, pos + 4)
                local code = tonumber(hex, 16)
                if not code then return nil, pos, "非法 Unicode 转义" end
                if code < 128 then
                    table.insert(result, string.char(code))
                elseif code < 2048 then
                    table.insert(result, string.char(192 + math.floor(code / 64), 128 + (code % 64)))
                elseif code < 55296 or code > 57343 then
                    table.insert(result, string.char(224 + math.floor(code / 4096),
                                                      128 + math.floor((code % 4096) / 64),
                                                      128 + (code % 64)))
                else
                    table.insert(result, "?") -- 代理对简化为 ?
                end
                pos = pos + 4
            else
                table.insert(result, ec)
            end
            pos = pos + 1
        else
            if c:byte() < 32 then
                return nil, pos, "字符串中包含非法控制字符"
            end
            table.insert(result, c)
            pos = pos + 1
        end
    end
    return nil, pos, "字符串未闭合"
end

local function ParseNumber(str, pos)
    local startPos = pos
    local c = str:sub(pos, pos)
    if c == "-" then pos = pos + 1 end
    if pos > #str then return nil, startPos, "数字格式错误" end

    -- 整数部分
    if str:sub(pos, pos) == "0" then
        pos = pos + 1
    elseif str:sub(pos, pos):match("[1-9]") then
        while pos <= #str and str:sub(pos, pos):match("%d") do
            pos = pos + 1
        end
    else
        return nil, startPos, "数字格式错误"
    end

    -- 小数部分
    if pos <= #str and str:sub(pos, pos) == "." then
        pos = pos + 1
        if pos > #str or not str:sub(pos, pos):match("%d") then
            return nil, startPos, "数字小数部分格式错误"
        end
        while pos <= #str and str:sub(pos, pos):match("%d") do
            pos = pos + 1
        end
    end

    -- 指数部分
    if pos <= #str and (str:sub(pos, pos) == "e" or str:sub(pos, pos) == "E") then
        pos = pos + 1
        if pos <= #str and (str:sub(pos, pos) == "+" or str:sub(pos, pos) == "-") then
            pos = pos + 1
        end
        if pos > #str or not str:sub(pos, pos):match("%d") then
            return nil, startPos, "数字指数部分格式错误"
        end
        while pos <= #str and str:sub(pos, pos):match("%d") do
            pos = pos + 1
        end
    end

    local numStr = str:sub(startPos, pos - 1)
    local num = tonumber(numStr)
    if num == nil then
        return nil, startPos, "无法解析数字"
    end
    return num, pos
end

local ParseJsonValue

local function ParseObject(str, pos)
    if str:sub(pos, pos) ~= "{" then
        return nil, pos, "对象必须以 { 开始"
    end
    pos = pos + 1
    local obj = {}
    pos = SkipWhitespace(str, pos)
    if str:sub(pos, pos) == "}" then
        return obj, pos + 1
    end
    while true do
        pos = SkipWhitespace(str, pos)
        if str:sub(pos, pos) ~= "\"" then
            return nil, pos, "对象键必须是字符串"
        end
        local key
        key, pos = ParseString(str, pos)
        if key == nil then return nil, pos, "对象键解析失败" end
        pos = SkipWhitespace(str, pos)
        if str:sub(pos, pos) ~= ":" then
            return nil, pos, "对象键值对缺少冒号"
        end
        pos = pos + 1
        local val
        val, pos = ParseJsonValue(str, pos)
        if val == nil then return nil, pos, "对象值解析失败" end
        obj[key] = val
        pos = SkipWhitespace(str, pos)
        local c = str:sub(pos, pos)
        if c == "," then
            pos = pos + 1
        elseif c == "}" then
            pos = pos + 1
            return obj, pos
        else
            return nil, pos, "对象解析遇到非法字符"
        end
    end
end

local function ParseArray(str, pos)
    if str:sub(pos, pos) ~= "[" then
        return nil, pos, "数组必须以 [ 开始"
    end
    pos = pos + 1
    local arr = {}
    pos = SkipWhitespace(str, pos)
    if str:sub(pos, pos) == "]" then
        return arr, pos + 1
    end
    while true do
        local val
        val, pos = ParseJsonValue(str, pos)
        if val == nil then return nil, pos, "数组元素解析失败" end
        table.insert(arr, val)
        pos = SkipWhitespace(str, pos)
        local c = str:sub(pos, pos)
        if c == "," then
            pos = pos + 1
        elseif c == "]" then
            pos = pos + 1
            return arr, pos
        else
            return nil, pos, "数组解析遇到非法字符"
        end
    end
end

ParseJsonValue = function(str, pos)
    pos = SkipWhitespace(str, pos)
    if pos > #str then
        return nil, pos, "JSON 输入在值预期位置结束"
    end
    local c = str:sub(pos, pos)
    if c == "{" then
        return ParseObject(str, pos)
    elseif c == "[" then
        return ParseArray(str, pos)
    elseif c == "\"" then
        return ParseString(str, pos)
    elseif str:sub(pos, pos + 3) == "true" then
        return true, pos + 4
    elseif str:sub(pos, pos + 4) == "false" then
        return false, pos + 5
    elseif str:sub(pos, pos + 3) == "null" then
        return nil, pos + 4
    elseif c == "-" or c:match("%d") then
        return ParseNumber(str, pos)
    else
        return nil, pos, "JSON 值起始字符非法: " .. c
    end
end

-- 全局暴露给 SimpleDecode 使用
_G.ParseJsonValue = ParseJsonValue
_G.SkipWhitespace = SkipWhitespace
