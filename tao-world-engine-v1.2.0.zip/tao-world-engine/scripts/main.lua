-- main.lua
-- 天道引擎 · 入口脚本
-- 职责：按正确顺序加载各模块，启动服务端或客户端天道系统

-- ═══════════════════════════════════════════════════════════
-- 一、全局配置（应在版本控制外注入）
-- ═══════════════════════════════════════════════════════════

TAO_VERSION = "v1.2.0"

API_KEYS = API_KEYS or {
    deepseek = "sk-your-deepseek-key",
    doubao   = "Bearer your-doubao-key",
    kimi     = "sk-your-kimi-key"
}

TAO_CONFIG = TAO_CONFIG or {
    deepseek_reasoner = {
        url   = "https://api.deepseek.com/chat/completions",
        model = "deepseek-reasoner",
        timeout = 60,
        maxRetries = 2,
        rpmLimit = 20
    },
    deepseek_chat = {
        url   = "https://api.deepseek.com/chat/completions",
        model = "deepseek-chat",
        timeout = 30,
        maxRetries = 2,
        rpmLimit = 50
    },
    doubao = {
        url   = "https://ark.cn-beijing.volces.com/api/v3/chat/completions",
        model = "doubao-pro-32k",
        timeout = 30,
        maxRetries = 2,
        rpmLimit = 100
    },
    kimi = {
        url   = "https://api.moonshot.cn/v1/chat/completions",
        model = "moonshot-v1-8k",
        timeout = 30,
        maxRetries = 2,
        rpmLimit = 60
    }
}

-- RSA 密钥占位（若启用玩家 API 代理）
SERVER_PRIVATE_KEY = SERVER_PRIVATE_KEY or ""
SERVER_PUBLIC_KEY  = SERVER_PUBLIC_KEY or ""

-- 调试开关
TAO_DEBUG = TAO_DEBUG or false

-- 世界生成参数
TAO_WORLD_CONFIG = TAO_WORLD_CONFIG or {
    worldSeed = 42,
    regionSize = { w = 64, h = 64 },
    autoSaveInterval = 300,  -- 5 分钟
    mempalaceArchiveDays = 30,
    maxConcurrentDerivations = 3,
    npcBatchSize = 20,
    enableVectorSearch = false
}

-- ═══════════════════════════════════════════════════════════
-- 二、模块加载系统
-- ═══════════════════════════════════════════════════════════

-- 模块依赖图
TAO_MODULE_GRAPH = {
    { name = "Shared",        path = "scripts/network/Shared.lua",        deps = {} },
    { name = "Router",        path = "scripts/network/tao/Router.lua",        deps = {"Shared"} },
    { name = "Validator",     path = "scripts/network/tao/Validator.lua",     deps = {"Shared"} },
    { name = "EventLog",      path = "scripts/network/tao/EventLog.lua",      deps = {"Shared"} },
    { name = "Mempalace",     path = "scripts/network/tao/Mempalace.lua",     deps = {"Shared","EventLog"} },
    { name = "AgentCore",     path = "scripts/network/tao/AgentCore.lua",     deps = {"Shared","Mempalace","EventLog","Validator"} },
    { name = "RegionGen",     path = "scripts/network/tao/RegionGen.lua",     deps = {"Shared"} },
    { name = "Tracery",       path = "scripts/network/tao/Tracery.lua",       deps = {"Shared"} },
    { name = "InkRuntime",    path = "scripts/network/tao/InkRuntime.lua",    deps = {"Shared"} },
    { name = "Server",        path = "scripts/network/Server.lua",            deps = {"Shared","Router","Validator","EventLog","Mempalace","AgentCore","RegionGen","Tracery"} },
    { name = "Client",        path = "scripts/network/Client.lua",            deps = {"Shared"} }
}

-- 加载状态跟踪
TAO_LOADED_MODULES = TAO_LOADED_MODULES or {}
TAO_LOAD_ERRORS = TAO_LOAD_ERRORS or {}

-- 安全加载模块
local function LoadModule(entry)
    if TAO_LOADED_MODULES[entry.name] then
        return true
    end

    -- 先加载依赖
    for _, depName in ipairs(entry.deps) do
        local depEntry = nil
        for _, m in ipairs(TAO_MODULE_GRAPH) do
            if m.name == depName then
                depEntry = m
                break
            end
        end
        if depEntry then
            local ok, err = pcall(LoadModule, depEntry)
            if not ok then
                TAO_LOAD_ERRORS[entry.name] = "依赖加载失败: " .. depName .. " -> " .. tostring(err)
                print("[TaoWorld] 错误: " .. TAO_LOAD_ERRORS[entry.name])
                return false
            end
        end
    end

    print("[TaoWorld] 加载模块: " .. entry.path)
    local ok, err = pcall(dofile, entry.path)
    if not ok then
        TAO_LOAD_ERRORS[entry.name] = tostring(err)
        print("[TaoWorld] 模块加载失败: " .. entry.name .. " -> " .. tostring(err))
        return false
    end

    TAO_LOADED_MODULES[entry.name] = true
    return true
end

-- 加载全部模块
function LoadAllTaoModules()
    local successCount = 0
    for _, entry in ipairs(TAO_MODULE_GRAPH) do
        if LoadModule(entry) then
            successCount = successCount + 1
        end
    end
    print(string.format("[TaoWorld] 模块加载完成: %d/%d", successCount, #TAO_MODULE_GRAPH))
    return successCount == #TAO_MODULE_GRAPH
end

-- ═══════════════════════════════════════════════════════════
-- 三、性能监控（轻量级）
-- ═══════════════════════════════════════════════════════════

TAO_PERF = TAO_PERF or {}

function TaoPerfBegin(name)
    TAO_PERF[name] = TAO_PERF[name] or { calls = 0, totalMs = 0, maxMs = 0 }
    TAO_PERF[name]._start = os.clock()
end

function TaoPerfEnd(name)
    local rec = TAO_PERF[name]
    if not rec or not rec._start then return end
    local elapsed = (os.clock() - rec._start) * 1000
    rec.calls = rec.calls + 1
    rec.totalMs = rec.totalMs + elapsed
    if elapsed > rec.maxMs then rec.maxMs = elapsed end
    rec._start = nil
end

function TaoPerfReport()
    local lines = {"[TaoPerf 报告]"}
    for name, rec in pairs(TAO_PERF) do
        local avg = rec.totalMs / math.max(1, rec.calls)
        table.insert(lines, string.format("  %s: 调用=%d 平均=%.2fms 最大=%.2fms 总计=%.2fms",
            name, rec.calls, avg, rec.maxMs, rec.totalMs))
    end
    return table.concat(lines, "\n")
end

-- ═══════════════════════════════════════════════════════════
-- 四、启动入口
-- ═══════════════════════════════════════════════════════════

function StartTaoWorld()
    print("========================================")
    print("  天道引擎 · Tao World Engine")
    print("  " .. TAO_VERSION)
    print("========================================")

    local allOk = LoadAllTaoModules()
    if not allOk then
        print("[TaoWorld] 致命错误：部分模块加载失败，天道引擎无法启动")
        for name, err in pairs(TAO_LOAD_ERRORS) do
            print("  - " .. name .. ": " .. err)
        end
        return false
    end

    if network:IsServer() then
        print("[TaoWorld] 以服务端模式启动")
        ServerTao.Init()
        ServerTao.LoadWorld()
        ServerTao.LoadMempalaceAll()
        ServerTao.StartAutoSave()

        -- 预生成起始区域
        local startRegion = RegionGen.GenerateLayout(TAO_WORLD_CONFIG.worldSeed,
            TAO_WORLD_CONFIG.regionSize.w, TAO_WORLD_CONFIG.regionSize.h)
        RegionGen.SaveRegion("start_region", startRegion)
        print("[TaoWorld] 起始区域已生成并保存")

        -- 注册测试 NPC（实际项目应从配置表加载）
        if _G.SPAWN_TEST_NPCS then
            SpawnTestNpcs()
        end

        print("[TaoWorld] 服务端天道系统启动完成")
    else
        print("[TaoWorld] 以客户端模式启动")
        ClientTao.Init()
        SubscribeToEvent("Update", function(eventType, eventData)
            local dt = eventData["TimeStep"]:GetFloat()
            ClientTao.Update(dt)
        end)
        print("[TaoWorld] 客户端天道系统启动完成")
    end

    return true
end

-- 注册测试 NPC
function SpawnTestNpcs()
    AgentCore.Init("npc_jack", {
        role = "商人",
        personality = "cunning",
        thinkInterval = 15,
        homeLoc = "集市东门",
        faction = "商会"
    })
    AgentCore.Init("npc_elara", {
        role = "法师",
        personality = "mysterious",
        thinkInterval = 20,
        homeLoc = "法师塔",
        faction = "法师会"
    })
    AgentCore.Init("npc_guard_tom", {
        role = "卫兵",
        personality = "stern",
        thinkInterval = 10,
        homeLoc = "城门",
        faction = "城卫队"
    })
    print("[TaoWorld] 测试 NPC 已注册")
end

-- ═══════════════════════════════════════════════════════════
-- 五、便捷全局 API（供项目脚本直接调用）
-- ═══════════════════════════════════════════════════════════

-- 发起世界推衍
function QueueWorldDerivation(eventType, data)
    if network:IsServer() and ServerTao and ServerTao.worldDerivationQueue then
        table.insert(ServerTao.worldDerivationQueue, {
            eventType = eventType,
            data = data,
            queuedAt = GetWorldTime()
        })
    else
        network:SendRemoteEvent(TAO_REMOTE_EVENTS.C2S_PLAYER_WORLD_INTERACTION, true,
            eventType, SimpleEncode(data or {}))
    end
end

-- 请求 NPC 策略
function RequestNpcStrategy(npcId, connection)
    if network:IsServer() then
        if AgentCore.agents and AgentCore.agents[npcId] then
            AgentCore.RequestStrategy(npcId, connection)
        end
    else
        network:SendRemoteEvent(TAO_REMOTE_EVENTS.C2S_REQUEST_NPC_DIALOG, true, npcId)
    end
end

-- 生成区域快捷接口
function GenerateRegion_Layout(seed, w, h)
    TaoPerfBegin("GenerateRegion_Layout")
    local result = RegionGen.GenerateLayout(seed, w, h)
    TaoPerfEnd("GenerateRegion_Layout")
    return result
end

function GenerateRegion_Heightmap(seed, w, h)
    TaoPerfBegin("GenerateRegion_Heightmap")
    local result = RegionGen.GenerateHeightmap(seed, w, h)
    TaoPerfEnd("GenerateRegion_Heightmap")
    return result
end

function PlaceBuildingInRegion(heightmap, layout, size)
    return RegionGen.PlaceBuilding(heightmap, layout, size)
end

function SaveRegion(regionId, regionData)
    return RegionGen.SaveRegion(regionId, regionData)
end

function LoadRegion(regionId)
    return RegionGen.LoadRegion(regionId)
end

-- Tracery 快捷接口
function TraceryFlatten(rule, grammar)
    return Tracery.Flatten(rule, grammar)
end

function GenerateItemName(prefixPool, materialPool, weaponPool)
    return Tracery.GenerateItemName(prefixPool, materialPool, weaponPool)
end

-- Ink 快捷接口
function LoadInkStory(scriptOrName)
    return InkRuntime.LoadStory(scriptOrName)
end

function ContinueInkStory(story)
    return InkRuntime.Continue(story)
end

function ChooseInkChoice(story, index)
    return InkRuntime.ChooseChoiceIndex(story, index)
end

-- 设置硬锁
function SetHardLock(category, id, value)
    Validator.SetHardLock(category, id, value)
end

-- 手动保存世界
function SaveTaoWorld()
    if network:IsServer() and ServerTao then
        TaoPerfBegin("SaveTaoWorld")
        ServerTao.SaveWorld()
        TaoPerfEnd("SaveTaoWorld")
    end
end

-- 手动加载世界
function LoadTaoWorld()
    if network:IsServer() and ServerTao then
        TaoPerfBegin("LoadTaoWorld")
        ServerTao.LoadWorld()
        ServerTao.LoadMempalaceAll()
        TaoPerfEnd("LoadTaoWorld")
    end
end

-- 查询记忆宫殿
function QueryMempalace(entityId, roomName, n)
    if Mempalace then
        return Mempalace.QueryRoom(entityId, roomName, n or 5)
    end
    return nil
end

-- 添加记忆
function AddMemory(entityId, roomName, entry)
    if Mempalace then
        Mempalace.Add(entityId, roomName, entry)
    end
end

-- 获取关系图
function GetRelationshipMap(entityId)
    if Mempalace then
        return Mempalace.GetRelationshipMap(entityId)
    end
    return nil
end

-- 热重载（开发期用）
function ReloadTaoModule(moduleName)
    if not TAO_DEBUG then
        print("[TaoWorld] 热重载仅在 TAO_DEBUG=true 时可用")
        return false
    end
    for _, entry in ipairs(TAO_MODULE_GRAPH) do
        if entry.name == moduleName then
            print("[TaoWorld] 热重载模块: " .. moduleName)
            local ok, err = pcall(dofile, entry.path)
            if ok then
                print("[TaoWorld] 热重载成功: " .. moduleName)
                return true
            else
                print("[TaoWorld] 热重载失败: " .. tostring(err))
                return false
            end
        end
    end
    print("[TaoWorld] 未知模块: " .. moduleName)
    return false
end

-- ═══════════════════════════════════════════════════════════
-- 六、自动启动
-- ═══════════════════════════════════════════════════════════

StartTaoWorld()
