# Dining Assistant Protocol Specification

## Agent Discovery & Handshake

### 1. Discovery Phase

```json
{
  "message_type": "DISCOVERY",
  "sender": {
    "agent_id": "customer_123",
    "agent_type": "customer",
    "capabilities": ["preferences", "ordering", "payment"]
  },
  "timestamp": "2026-04-17T09:30:00Z"
}
```

### 2. Handshake Request

```json
{
  "message_type": "HANDSHAKE_REQUEST",
  "sender": {
    "agent_id": "customer_123",
    "agent_type": "customer"
  },
  "payload": {
    "user_profile": {
      "dietary_restrictions": ["vegetarian", "no_nuts"],
      "preferences": {
        "cuisine": ["chinese", "japanese"],
        "spice_level": "medium",
        "meal_time_preferences": {
          "breakfast": "08:00-09:00",
          "lunch": "12:00-13:00",
          "dinner": "18:00-20:00"
        }
      },
      "party_size": 4,
      "occasion": "business_lunch"
    }
  },
  "timestamp": "2026-04-17T09:30:05Z"
}
```

### 3. Handshake Response (Restaurant)

```json
{
  "message_type": "HANDSHAKE_RESPONSE",
  "sender": {
    "agent_id": "restaurant_456",
    "agent_type": "restaurant"
  },
  "payload": {
    "restaurant_info": {
      "name": "Golden Dragon",
      "cuisine": "Sichuan",
      "rating": 4.5,
      "price_range": "$$"
    },
    "current_status": {
      "queue_length": 12,
      "current_number": 45,
      "estimated_wait_minutes": 30,
      "available_tables": {
        "2_person": 0,
        "4_person": 2,
        "6_person": 1
      }
    },
    "menu_summary": {
      "categories": ["appetizers", "main_courses", "desserts"],
      "chef_recommendations": ["mapo_tofu", "kung_pao_chicken"],
      "daily_specials": ["lunch_combo_a", "lunch_combo_b"]
    }
  },
  "timestamp": "2026-04-17T09:30:06Z"
}
```

## Message Types

### Customer → Restaurant

| Message Type | Purpose |
|--------------|---------|
| `DISCOVERY` | Announce presence and capabilities |
| `HANDSHAKE_REQUEST` | Initiate connection with user profile |
| `MENU_REQUEST` | Request full menu |
| `RECOMMENDATION_REQUEST` | Request personalized recommendations |
| `QUEUE_JOIN` | Join waiting queue |
| `ORDER_SUBMIT` | Submit order |
| `ORDER_MODIFY` | Modify existing order |
| `TABLE_REQUEST` | Request specific table |

### Restaurant → Customer

| Message Type | Purpose |
|--------------|---------|
| `HANDSHAKE_RESPONSE` | Accept connection, send status |
| `MENU_RESPONSE` | Full menu data |
| `RECOMMENDATION_RESPONSE` | Personalized recommendations |
| `QUEUE_CONFIRMATION` | Queue position confirmation |
| `QUEUE_UPDATE` | Position update |
| `ORDER_CONFIRMATION` | Order accepted |
| `ORDER_STATUS` | Order preparation status |
| `TABLE_READY` | Table is ready |

## Order Flow

### Submit Order

```json
{
  "message_type": "ORDER_SUBMIT",
  "payload": {
    "order_id": "ord_20260417_001",
    "items": [
      {
        "dish_id": "dish_001",
        "name": "Mapo Tofu",
        "quantity": 1,
        "special_instructions": "extra spicy",
        "price": 28.00
      }
    ],
    "party_size": 4,
    "estimated_arrival": "2026-04-17T12:30:00Z",
    "preferences_match": 0.92
  }
}
```

### Order Confirmation

```json
{
  "message_type": "ORDER_CONFIRMATION",
  "payload": {
    "order_id": "ord_20260417_001",
    "status": "confirmed",
    "estimated_ready_time": "2026-04-17T12:25:00Z",
    "queue_number": 46,
    "table_assignment": "A12",
    "total_amount": 128.00
  }
}
```

## Queue Management

### Join Queue

```json
{
  "message_type": "QUEUE_JOIN",
  "payload": {
    "party_size": 4,
    "pre_order": true,
    "estimated_arrival": "2026-04-17T12:30:00Z"
  }
}
```

### Queue Update

```json
{
  "message_type": "QUEUE_UPDATE",
  "payload": {
    "queue_number": 46,
    "position": 3,
    "estimated_wait_minutes": 15,
    "status": "waiting"
  }
}
```

## Security Considerations

1. All messages must be signed with agent private key
2. QR codes contain temporary tokens with expiration
3. Sensitive user data (payment info) not transmitted during handshake
4. Rate limiting on discovery broadcasts

## Error Handling

### Error Response Format

```json
{
  "message_type": "ERROR",
  "payload": {
    "code": "RESTAURANT_FULL",
    "message": "Restaurant is at full capacity",
    "retry_after": 1800
  }
}
```

### Common Error Codes

- `RESTAURANT_CLOSED` - Restaurant not accepting orders
- `QUEUE_FULL` - Queue at maximum capacity
- `INVALID_MENU_ITEM` - Ordered item not available
- `TABLE_UNAVAILABLE` - Requested table type not available
- `PAYMENT_REQUIRED` - Pre-payment needed for order
