# Dining Assistant API Reference

## Core Classes

### RestaurantAgent

Main class for restaurant mode operations.

#### Constructor

```python
RestaurantAgent(
    restaurant_id: str,
    name: str,
    location: dict,
    config: dict = None
)
```

#### Methods

##### start_server(host, port)
Start the Agent server to listen for customer connections.

```python
restaurant.start_server(host="0.0.0.0", port=8080)
```

##### set_menu(menu_data)
Set or update the restaurant menu.

```python
menu_data = {
    "categories": [...],
    "dishes": [...],
    "combos": [...]
}
restaurant.set_menu(menu_data)
```

##### update_queue_status(current_number, wait_minutes)
Update current queue status.

```python
restaurant.update_queue_status(
    current_number=45,
    wait_minutes=30
)
```

##### update_table_status(table_id, status)
Update table availability.

```python
restaurant.update_table_status("tbl_A01", "occupied")
```

##### get_recommendations(customer_preferences)
Get AI-powered dish recommendations for a customer.

```python
recommendations = restaurant.get_recommendations({
    "preferences": ["spicy", "sichuan"],
    "avoid": ["cilantro"],
    "party_size": 4
})
```

##### confirm_order(order_id)
Confirm an incoming order.

```python
restaurant.confirm_order("ord_20260417_001")
```

##### update_order_status(order_id, status)
Update order preparation status.

```python
restaurant.update_order_status("ord_20260417_001", "preparing")
```

### CustomerAgent

Main class for customer mode operations.

#### Constructor

```python
CustomerAgent(
    user_id: str,
    preferences: dict,
    config: dict = None
)
```

#### Methods

##### connect_to_restaurant(qr_code_or_url)
Connect to a restaurant via QR code scan.

```python
customer.connect_to_restaurant("https://dining.example.com/r/rst001")
```

##### set_preferences(preferences)
Update user dining preferences.

```python
customer.set_preferences({
    "allergies": ["peanuts"],
    "favorites": ["spicy", "japanese"],
    "meal_times": {
        "lunch": "12:00-13:00",
        "dinner": "18:00-20:00"
    }
})
```

##### get_recommendations()
Get personalized recommendations from connected restaurant.

```python
recommendations = customer.get_recommendations()
```

##### submit_order(items, party_size)
Submit an order to the connected restaurant.

```python
order = customer.submit_order(
    items=[
        {"dish_id": "dish_001", "quantity": 2},
        {"dish_id": "dish_005", "quantity": 1}
    ],
    party_size=4,
    estimated_arrival="2026-04-17T12:30:00Z"
)
```

##### join_queue(party_size)
Join the restaurant queue.

```python
queue_info = customer.join_queue(party_size=4)
```

##### get_queue_status()
Get current queue position.

```python
status = customer.get_queue_status()
# Returns: {"position": 3, "estimated_wait": 15}
```

##### save_restaurant(restaurant_id, notes)
Save a restaurant to favorites.

```python
customer.save_restaurant("rst_001", notes="Great for business lunches")
```

##### quick_order_from_saved(restaurant_id)
Place a quick order using saved preferences.

```python
order = customer.quick_order_from_saved("rst_001")
```

## Events

### RestaurantAgent Events

| Event | Description | Payload |
|-------|-------------|---------|
| `customer_connected` | New customer connected | `customer_agent_id`, `user_profile` |
| `order_received` | New order submitted | `order_id`, `items`, `total` |
| `order_confirmed` | Order confirmed by customer | `order_id` |
| `queue_joined` | Customer joined queue | `queue_number`, `party_size` |

### CustomerAgent Events

| Event | Description | Payload |
|-------|-------------|---------|
| `connected` | Connected to restaurant | `restaurant_info` |
| `recommendations_received` | Recommendations ready | `recommendations` |
| `order_confirmed` | Order confirmed | `order_id`, `queue_number` |
| `queue_update` | Queue position updated | `position`, `estimated_wait` |
| `table_ready` | Table is ready | `table_id` |
| `order_ready` | Food is ready | `order_id`, `pickup_time` |

## Configuration Options

### Restaurant Config

```json
{
  "server": {
    "host": "0.0.0.0",
    "port": 8080,
    "ssl": false
  },
  "queue": {
    "max_size": 50,
    "auto_assign_tables": true,
    "estimated_service_time": 45
  },
  "ordering": {
    "require_prepayment": false,
    "allow_preorder": true,
    "max_preorder_minutes": 60
  },
  "notifications": {
    "queue_updates": true,
    "order_updates": true,
    "table_ready": true
  }
}
```

### Customer Config

```json
{
  "user": {
    "auto_save_restaurants": true,
    "default_party_size": 2
  },
  "preferences": {
    "spice_tolerance": "medium",
    "dietary_restrictions": [],
    "avoid_ingredients": []
  },
  "ordering": {
    "confirm_before_order": true,
    "auto_join_queue": true,
    "preferred_arrival_buffer": 10
  },
  "notifications": {
    "queue_updates": true,
    "order_updates": true,
    "promotions": false
  }
}
```

## Error Codes

| Code | Description | Resolution |
|------|-------------|------------|
| `RESTAURANT_NOT_FOUND` | Restaurant ID invalid | Check QR code or URL |
| `CONNECTION_FAILED` | Handshake failed | Retry connection |
| `QUEUE_FULL` | Queue at capacity | Try again later |
| `RESTAURANT_CLOSED` | Not accepting orders | Check business hours |
| `INVALID_ORDER` | Order validation failed | Check menu items |
| `MENU_UNAVAILABLE` | Menu not loaded | Wait and retry |
| `PAYMENT_REQUIRED` | Prepayment needed | Complete payment first |

## Utility Functions

### generate_qr_code(restaurant_id, table_id=None)
Generate QR code for restaurant/table.

```python
from dining_assistant import generate_qr_code

# Restaurant-level QR
qr = generate_qr_code("rst_001")

# Table-specific QR
qr = generate_qr_code("rst_001", table_id="tbl_A01")
```

### parse_qr_code(qr_data)
Parse QR code data.

```python
from dining_assistant import parse_qr_code

info = parse_qr_code("https://dining.example.com/r/rst001/t/A01")
# Returns: {"restaurant_id": "rst_001", "table_id": "tbl_A01"}
```

### calculate_recommendation_score(dish, preferences)
Calculate match score between dish and preferences.

```python
from dining_assistant import calculate_recommendation_score

score = calculate_recommendation_score(dish_data, user_preferences)
# Returns: 0.0 to 1.0
```
