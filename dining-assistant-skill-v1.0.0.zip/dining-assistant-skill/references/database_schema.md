# Database Schema

## Restaurant Data Model

### Restaurant Profile

```json
{
  "restaurant_id": "rst_001",
  "name": "Golden Dragon Restaurant",
  "type": "sichuan_cuisine",
  "location": {
    "address": "123 Main St, Beijing",
    "coordinates": {
      "lat": 39.9042,
      "lng": 116.4074
    }
  },
  "contact": {
    "phone": "+86-10-12345678",
    "email": "contact@goldendragon.com"
  },
  "business_hours": {
    "monday": {"open": "10:00", "close": "22:00"},
    "tuesday": {"open": "10:00", "close": "22:00"},
    "wednesday": {"open": "10:00", "close": "22:00"},
    "thursday": {"open": "10:00", "close": "22:00"},
    "friday": {"open": "10:00", "close": "23:00"},
    "saturday": {"open": "09:00", "close": "23:00"},
    "sunday": {"open": "09:00", "close": "22:00"}
  },
  "settings": {
    "max_queue_size": 50,
    "avg_service_time_minutes": 45,
    "supports_preorder": true,
    "supports_reservation": true
  },
  "created_at": "2026-01-15T08:00:00Z",
  "updated_at": "2026-04-17T09:00:00Z"
}
```

### Menu

```json
{
  "menu_id": "menu_rst001_v1",
  "restaurant_id": "rst_001",
  "version": "2026.04.17",
  "categories": [
    {
      "category_id": "cat_001",
      "name": "Appetizers",
      "order": 1,
      "items": ["dish_001", "dish_002"]
    }
  ],
  "dishes": [
    {
      "dish_id": "dish_001",
      "name": "Mapo Tofu",
      "name_cn": "麻婆豆腐",
      "category_id": "cat_003",
      "description": "Spicy tofu with minced pork",
      "price": 28.00,
      "currency": "CNY",
      "allergens": ["soy"],
      "dietary_tags": ["spicy", "contains_meat"],
      "ingredients": ["tofu", "pork", "chili", "sichuan_pepper"],
      "nutrition": {
        "calories": 320,
        "protein": 18,
        "carbs": 12,
        "fat": 22
      },
      "prep_time_minutes": 15,
      "popularity_score": 0.95,
      "is_available": true,
      "is_recommended": true,
      "image_url": "https://cdn.example.com/dishes/dish_001.jpg"
    }
  ],
  "combos": [
    {
      "combo_id": "combo_001",
      "name": "Lunch Special A",
      "items": ["dish_001", "dish_005", "dish_010"],
      "original_price": 88.00,
      "discounted_price": 68.00,
      "available_time": {"start": "11:00", "end": "14:00"},
      "is_available": true
    }
  ]
}
```

### Tables

```json
{
  "table_id": "tbl_A01",
  "restaurant_id": "rst_001",
  "name": "A1",
  "capacity": 4,
  "type": "standard",
  "location": "main_floor",
  "status": "occupied",
  "current_order": "ord_20260417_045",
  "qr_code": "https://dining.example.com/t/rst001/A01"
}
```

### Queue

```json
{
  "queue_id": "queue_rst001_20260417",
  "restaurant_id": "rst_001",
  "date": "2026-04-17",
  "current_number": 45,
  "entries": [
    {
      "queue_number": 46,
      "customer_agent_id": "cust_123",
      "party_size": 4,
      "status": "waiting",
      "joined_at": "2026-04-17T09:30:00Z",
      "estimated_seating": "2026-04-17T10:00:00Z",
      "pre_order": {
        "order_id": "ord_20260417_046",
        "items": ["dish_001", "dish_005"],
        "estimated_prep_minutes": 25
      }
    }
  ]
}
```

### Orders

```json
{
  "order_id": "ord_20260417_046",
  "restaurant_id": "rst_001",
  "customer_agent_id": "cust_123",
  "queue_number": 46,
  "table_id": "tbl_A12",
  "status": "preparing",
  "items": [
    {
      "item_id": "item_001",
      "dish_id": "dish_001",
      "name": "Mapo Tofu",
      "quantity": 1,
      "price": 28.00,
      "special_instructions": "extra spicy",
      "status": "preparing"
    }
  ],
  "party_size": 4,
  "total_amount": 128.00,
  "currency": "CNY",
  "created_at": "2026-04-17T09:30:00Z",
  "estimated_ready": "2026-04-17T10:00:00Z",
  "completed_at": null
}
```

## Customer Data Model

### User Profile

```json
{
  "user_id": "user_123",
  "agent_id": "cust_123",
  "profile": {
    "name": "John Doe",
    "dietary_restrictions": {
      "allergies": ["peanuts", "shellfish"],
      "intolerances": ["lactose"],
      "diet_type": "omnivore"
    },
    "preferences": {
      "cuisines": ["chinese", "japanese", "italian"],
      "flavors": ["spicy", "savory", "umami"],
      "avoid_ingredients": ["cilantro", "durian"],
      "spice_tolerance": "high"
    },
    "meal_time_preferences": {
      "breakfast": {
        "preferred_time": "08:00",
        "window": "07:30-09:00",
        "typical_items": ["congee", "steamed_buns", "soy_milk"]
      },
      "lunch": {
        "preferred_time": "12:30",
        "window": "12:00-13:30",
        "typical_items": ["rice_bowls", "noodles", "hotpot"]
      },
      "dinner": {
        "preferred_time": "19:00",
        "window": "18:00-20:30",
        "typical_items": ["family_style", "hotpot", "bbq"]
      }
    },
    "party_composition": {
      "default_size": 2,
      "has_children": false,
      "has_elderly": false
    }
  },
  "order_history": [
    {
      "restaurant_id": "rst_001",
      "restaurant_name": "Golden Dragon",
      "visit_count": 12,
      "favorite_dishes": ["dish_001", "dish_015"],
      "average_spend": 156.00,
      "last_visit": "2026-04-10T19:30:00Z"
    }
  ],
  "created_at": "2026-01-01T00:00:00Z",
  "updated_at": "2026-04-17T09:00:00Z"
}
```

### Saved Restaurants

```json
{
  "saved_id": "svd_001",
  "user_id": "user_123",
  "restaurant_id": "rst_001",
  "restaurant_name": "Golden Dragon",
  "notes": "Great for business dinners",
  "favorite_dishes": ["dish_001", "dish_015"],
  "preferred_table": "tbl_VIP01",
  "auto_order_template": {
    "items": ["dish_001", "dish_005", "dish_010"],
    "party_size": 4
  },
  "added_at": "2026-02-15T10:00:00Z",
  "last_visited": "2026-04-10T19:30:00Z"
}
```

## Agent Session Data

### Active Handshakes

```json
{
  "session_id": "sess_20260417_001",
  "restaurant_agent_id": "rst_001",
  "customer_agent_id": "cust_123",
  "status": "connected",
  "started_at": "2026-04-17T09:30:00Z",
  "last_activity": "2026-04-17T09:35:00Z",
  "context": {
    "queue_number": 46,
    "order_id": "ord_20260417_046",
    "table_id": "tbl_A12"
  }
}
```
