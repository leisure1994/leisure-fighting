# Dining Assistant - Long-term Memory System
# 用餐助手长效记忆系统

基于 mempalace 架构的双端记忆系统，支持餐厅和顾客 Agent 的持久记忆积累。

## 记忆架构

### 餐厅端记忆 (Restaurant Memory)

```
memory/
├── restaurant-profile.md          # 餐厅基础画像
├── customer-profiles/               # 顾客档案库
│   ├── cust_[id].md                # 单个顾客完整档案
│   └── customer-index.json         # 顾客索引
├── operational-memory.md            # 经营记忆
├── menu-evolution.md               # 菜品演变记录
└── service-history.md                # 服务历史
```

### 顾客端记忆 (Customer Memory)

```
memory/
├── customer-profile.md              # 顾客基础画像
├── dining-history/                  # 用餐历史
│   ├── visits.json                  # 到访记录
│   ├── orders/                      # 订单历史
│   └── experiences.md                # 用餐体验
├── taste-evolution.md               # 口味演变
├── saved-restaurants.json             # 收藏餐厅
├── social-dining.md                 # 社交用餐记忆
└── exploration-log.md                # 新尝试记录
```

## 记忆类型

### 1. 事实记忆 (Factual Memory)
- 顾客基本信息（忌口、过敏）
- 餐厅基本信息（地址、营业时间）
- 订单历史（菜品、金额、时间）

### 2. 程序记忆 (Procedural Memory)
- 点餐流程偏好
- 用餐时间规律
- 结账习惯

### 3. 情景记忆 (Episodic Memory)
- 特殊场合用餐（生日、约会）
- 具体用餐体验
- 与谁一起用餐

### 4. 语义记忆 (Semantic Memory)
- 口味偏好演变
- 菜系认知积累
- 价格敏感度

## 记忆生命周期

```
感知 → 编码 → 存储 → 巩固 → 检索 → 遗忘/归档
  ↑_____________________________________↓
```

### 记忆强度等级

| 等级 | 触发次数 | 保留策略 |
|------|----------|----------|
| L1-瞬时 | 1次 | 短期缓存，24小时无强化则遗忘 |
| L2-工作 | 2-3次 | 工作记忆，7天无强化降级 |
| L3-长期 | 4-7次 | 长期存储，写入持久化文件 |
| L4-核心 | 8次+ | 核心记忆，几乎不遗忘 |

## 餐厅端记忆详解

### Customer Profile (顾客档案)

```yaml
customer_id: cust_zhang_001
first_visit: 2026-01-15
total_visits: 12
lifetime_value: ¥3,240

# 基础画像
basics:
  name: "张先生"
  phone: "138****8888"
  vip_level: gold  # 基于消费累计

# 用餐偏好 (动态更新)
preferences:
  spice_tolerance: high  # [observed: 8次点辣菜]
  preferred_table: "A02"  # [observed: 5次要求此桌]
  avg_party_size: 4
  typical_occasion: "朋友聚餐"  # [observed: 生日聚会2次, 商务1次, 朋友9次]

# 菜品偏好 (基于订单分析)
dish_preferences:
  favorites:  # L4 核心记忆
    - dish_id: d_003
      name: "水煮鱼"
      order_count: 8
      last_ordered: 2026-04-10
      sentiment: "love"  # 每次必点
    - dish_id: d_001
      name: "麻婆豆腐"
      order_count: 7
      sentiment: "like"
  
  dislikes:  # L3 长期记忆
    - ingredient: "香菜"
      source: "explicit_feedback"  # 主动告知
      date: 2026-01-15
    
  exploration_pattern: "保守+偶尔新尝试"  # [derived]

# 行为模式
behavior_patterns:
  booking_habit: "临时到店"  # 12次中有10次未预订
  ordering_speed: "快速"  # 平均决策时间3分钟
  payment_method: "微信支付"
  tip_pattern: "固定10%"
  
# 互动历史
interaction_history:
  - date: 2026-04-10
    type: "complaint"
    content: "上菜慢"
    resolution: "赠送凉菜"
    sentiment_change: +0.2  # 解决后满意度回升
  
  - date: 2026-03-20
    type: "compliment"
    content: "新菜好吃"
    dish_mentioned: d_015

# 记忆强度评估
memory_strength:
  profile_completeness: 0.85  # 档案完整度
  confidence_level: high  # 数据可信度
  last_updated: 2026-04-10
```

### Operational Memory (经营记忆)

```yaml
# 时段特征
time_patterns:
  lunch_peak: "12:00-13:00"  # 基于历史数据
  dinner_peak: "19:00-20:30"
  quiet_days: ["Tuesday"]
  
# 客群特征
customer_segments:
  regulars: 45%  # 回头客比例
  new_customers: 30%
  tourists: 25%
  
# 菜品表现
dish_performance:
  d_003:  # 水煮鱼
    order_rate: 0.65  # 点单率
    satisfaction: 0.92
    trend: "stable"
    seasonality: "winter_high"
    
# 预测模型
predictions:
  next_week_busy_days: ["Friday", "Saturday"]
  recommended_prep:  # 建议备料
    - dish: d_003
      quantity: 30
      confidence: 0.78
```

## 顾客端记忆详解

### Dining History (用餐历史)

```yaml
# 到访记录
visits:
  - visit_id: v_20260410_001
    restaurant: 
      id: rst_sichuan_001
      name: "蜀香阁川菜馆"
    date: 2026-04-10
    time: "19:00"
    party_size: 4
    occasion: "朋友聚餐"
    
    order:
      items: [...]
      total: ¥196
      satisfaction: 0.9
    
    experience:
      wait_time: 15  # 分钟
      service_rating: 5
      food_rating: 5
      atmosphere: "热闹"
      
    memories:
      - "朋友小王生日"
      - "尝试了新品口水鸡"
      - "服务员记得我不吃香菜"

# 统计洞察
insights:
  total_restaurants_visited: 23
  total_spent_ytd: ¥8,500
  favorite_cuisine: "川菜"  # 访问频次最高
  price_comfort_zone: "¥50-100/人"
  adventure_ratio: 0.3  # 30%尝试新餐厅
```

### Taste Evolution (口味演变)

```yaml
# 口味时间线
taste_timeline:
  2026-01:  # 早期
    spice_tolerance: medium
    preferred_cuisines: ["粤菜", "江浙菜"]
    
  2026-03:  # 转变期 [observed: 连续尝试川湘菜]
    spice_tolerance: high
    new_discoveries: ["麻辣火锅", "泡椒系列"]
    
  2026-04:  # 当前
    spice_tolerance: very_high
    preferred_cuisines: ["川菜", "湘菜", "重庆火锅"]
    signature_dish: "水煮鱼"
    
# 口味地图
taste_map:
  flavor_profile:
    spicy: 0.9
    savory: 0.8
    sour: 0.6
    sweet: 0.3
    bitter: 0.2
    
  texture_preference:
    crispy: 0.7
    tender: 0.8
    chewy: 0.5
    smooth: 0.6
```

## 记忆巩固机制

### 餐厅端 POST 流程

```
每次顾客用餐后:
  POST-1: 更新顾客档案
    → 追加订单记录
    → 更新偏好统计
    → 计算记忆强度
    
  POST-2: 更新经营数据
    → 时段销售统计
    → 菜品表现分析
    → 客群画像更新
    
  POST-3: 生成洞察
    → 预测下周客流
    → 推荐备货计划
    → 识别风险顾客（流失预警）
```

### 顾客端 POST 流程

```
每次用餐后:
  POST-1: 记录体验
    → 餐厅评价
    → 菜品打分
    → 场景标签
    
  POST-2: 更新偏好
    → 口味微调
    → 新发现记录
    → 下次想尝试清单
    
  POST-3: 社交同步
    → 分享给常约饭的朋友
    → 更新"想吃清单"
```

## 记忆唤醒与检索

### 餐厅端检索场景

1. **顾客到店识别**
   ```
   顾客扫码 → 人脸识别/手机号 → 检索档案
   → 展示: "张先生，欢迎回来！还是A2桌吗？"
   → 推荐: "您常点的水煮鱼今天有优惠"
   ```

2. **智能备货提醒**
   ```
   周五18:00 → 检索历史 → 预测今晚客流
   → 提醒: "预计今晚8桌回头客，建议备料: 水煮鱼x10"
   ```

3. **流失预警**
   ```
   顾客 Zhang 上次访问: 30天前
   历史平均间隔: 7天
   触发: 流失预警
   → 推送: "张先生，好久不见！新品上线，回来尝尝？"
   ```

### 顾客端检索场景

1. **"我想吃辣的"**
   ```
   检索 taste_map.spicy → 0.9
   → 推荐收藏的高辣餐厅
   → 或推荐附近高评分川菜
   ```

2. **"上次那家不错的店"**
   ```
   检索 experiences.satisfaction > 0.8
   → 按时间倒排 → 蜀香阁 (2026-04-10, 0.9分)
   ```

3. **"约朋友吃饭"**
   ```
   检索 social_dining.frequent_companions
   → 小王: 常去川菜, 中辣
   → 小李: 偏好清淡, 不辣
   → 推荐: 融合菜系, 可点鸳鸯锅
   ```

## 记忆遗忘策略

并非所有记忆永久保留，按强度分级遗忘:

| 记忆类型 | 遗忘策略 | 归档方式 |
|----------|----------|----------|
| 单次点餐细节 | 30天后遗忘 | 保留统计摘要 |
| 临时偏好 | 未强化则降级 | 移至冷存储 |
| 低频顾客档案 | 90天无访问→休眠 | 压缩归档 |
| 过期推荐 | 实时清理 | 删除 |

## 技术实现

### 记忆存储

```python
class DiningMemory:
    """用餐记忆管理器"""
    
    def __init__(self, agent_type: str):
        self.agent_type = agent_type  # "restaurant" | "customer"
        self.memory_dir = f"memory/{agent_type}"
        self.cache = {}  # L1/L2 工作记忆
        self.persistence = MemoryPersistence(self.memory_dir)  # L3/L4
    
    def encode(self, event: DiningEvent) -> MemoryEngram:
        """编码用餐事件为记忆印迹"""
        engram = MemoryEngram(
            timestamp=event.time,
            content=event.serialize(),
            emotional_tag=event.satisfaction,
            associations=self._find_associations(event)
        )
        return engram
    
    def consolidate(self, engram: MemoryEngram):
        """记忆巩固"""
        # 强化已有记忆或创建新记忆
        existing = self._retrieve_similar(engram)
        if existing:
            existing.reinforce()
        else:
            self.persistence.store(engram)
    
    def retrieve(self, query: MemoryQuery) -> List[Memory]:
        """记忆检索"""
        # 多级检索: 缓存 → 索引 → 全文
        results = []
        results.extend(self._search_cache(query))
        results.extend(self.persistence.search(query))
        return self._rank_by_relevance(results, query)
```

### 记忆同步

```python
class MemorySync:
    """跨设备/跨Agent记忆同步"""
    
    def sync_customer_to_cloud(self, customer_id: str):
        """顾客记忆云端同步"""
        local_memory = load_local_memory(customer_id)
        cloud_memory = fetch_cloud_memory(customer_id)
        
        # 合并策略: 时间戳优先
        merged = self._merge_memories(local_memory, cloud_memory)
        
        # 双向同步
        save_to_cloud(merged)
        save_local(merged)
    
    def sync_restaurant_customers(self, restaurant_id: str):
        """餐厅顾客档案批量同步"""
        # 加密同步顾客档案到云端
        # 支持多分店共享顾客记忆
        pass
```

## 隐私与安全

1. **数据加密**: 顾客档案加密存储
2. **访问控制**: 餐厅只能访问到店顾客数据
3. **遗忘权**: 顾客可要求删除档案
4. **匿名统计**: 经营分析使用脱敏数据

## 未来扩展

- [ ] 跨餐厅记忆共享（顾客授权）
- [ ] 口味DNA图谱
- [ ] 预测性推荐（想吃的时候主动推送）
- [ ] 社交网络分析（饭友圈）
