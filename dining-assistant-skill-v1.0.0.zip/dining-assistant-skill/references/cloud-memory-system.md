# Dining Assistant - Cloud Memory & Reputation System
# 用餐助手云端共享记忆与信用系统

## 核心概念

### 双向云端调取

```
┌─────────────────────────────────────────────────────────────┐
│                        云端记忆中枢                           │
│                  (Cloud Memory Hub)                          │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │  餐厅档案库   │  │  顾客信用池   │  │  评价数据库   │       │
│  │ Restaurants │  │  Customers  │  │  Reviews     │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
└─────────────────────────────────────────────────────────────┘
           ↑↓                              ↑↓
    ┌──────────────┐                ┌──────────────┐
    │  餐厅Agent    │                │  顾客Agent    │
    │ 调取顾客信用   │                │ 调取餐厅评价   │
    │ (授权后)      │                │ (匿名公开)    │
    └──────────────┘                └──────────────┘
```

## 云端记忆架构

### 1. 餐厅档案 (Restaurant Profile)

```yaml
restaurant_id: rst_sichuan_001
name: 蜀香阁川菜馆

# 公开信息 (顾客可调取)
public:
  menu: [...]
  location: {...}
  rating_aggregate: 4.6
  total_reviews: 1280
  
# 受控访问 (需顾客授权)
controlled:
  peak_hours: [...]
  customer_segments: {...}
  
# 私密信息 (仅餐厅可见)
private:
  financial_data: {...}
  staff_info: {...}
```

### 2. 顾客信用档案 (Customer Credit Profile)

```yaml
customer_id: cust_zhang_001

# 信用评分 (餐厅可调取, 需授权)
credit:
  overall_score: 850  # 0-1000
  
  # 历史行为
  history:
    total_visits: 45
    completed_orders: 44
    disputed_orders: 1
    
  # 逃单记录 (严重负面)
  blackmarks:
    - type: "dine_and_dash"
      restaurant_id: "rst_xxx"
      date: "2026-02-15"
      amount: ¥168
      resolved: false
      evidence: ["cctv_footage", "witness_statement"]
      
  # 支付习惯
  payment_patterns:
    method: "wechat_pay"
    on_time_rate: 0.98
    tip_rate: 0.15

# 隐私控制
privacy_settings:
  allow_credit_check: true  # 允许餐厅查询信用
  allow_review_access: true  # 允许其他顾客看我的评价
  anonymize_public_reviews: false  # 公开评价是否匿名
```

### 3. 评价系统 (Review System)

```yaml
review_id: rev_20260417_001

# 评价元数据
meta:
  restaurant_id: rst_sichuan_001
  customer_id: cust_zhang_001  # 可匿名
  visit_id: v_20260410_001
  date: 2026-04-10
  verified: true  # 已验证真实消费
  
# 评价内容 (Agent自动询问后生成)
content:
  overall_rating: 4.5  # 1-5
  
  # 多维度评分
  breakdown:
    food_quality: 5.0
    service: 4.0
    atmosphere: 4.5
    value_for_money: 4.0
    wait_time: 4.0
  
  # 详细评价 (Agent询问后自动生成摘要)
  text: "水煮鱼一如既往好吃，但等位时间比预期长。服务员态度很好。"
  
  # 标签 (自动提取)
  tags: ["口味正宗", "上菜稍慢", "服务热情"]
  
  # 推荐菜品
  recommended_dishes: ["d_003", "d_001"]
  not_recommended: []
  
  # 照片/视频 (可选)
  media: []

# 互动
interactions:
  helpful_count: 12
  restaurant_response: "感谢您的反馈，我们会优化等位管理"
  
# 可见性
visibility:
  public: true  # 公开可见
  anonymous: false  # 实名评价
  searchable: true  # 可被搜索
```

## 记忆调取流程

### 顾客调取餐厅评价

```
顾客: "这家餐厅怎么样？"
  ↓
Agent检索云端:
  1. 调取餐厅基础档案 (公开)
  2. 调取聚合评分 (公开)
  3. 调取近期评价 (公开, 前20条)
  4. 筛选高可信度评价 ( verified + 详细 )
  ↓
Agent生成回复:
  "蜀香阁川菜馆评分4.6/5，最近1280条评价。
   
   好评关键词: 口味正宗(89%)、分量大(76%)、服务热情(72%)
   差评关键词: 等位久(23%)、环境嘈杂(15%)
   
   和你口味相似的用户(高辣偏好)说:
   '水煮鱼必点！辣度刚好，鱼肉新鲜。'
   
   建议你关注:
   - 周末等位约30分钟，建议提前预约
   - 人均消费¥80-120，符合你的预算范围"
```

### 餐厅调取顾客信用

```
新顾客扫码
  ↓
Agent检索云端 (需顾客授权):
  1. 查询信用评分
  2. 查询逃单记录
  3. 查询支付习惯
  ↓
风险评级:
  - 信用分>800 + 无黑记录 → 绿色 (正常接待)
  - 信用分600-800 → 黄色 (建议先付款)
  - 信用分<600 或 有逃单记录 → 红色 (需押金/拒绝)
  ↓
餐厅Agent提醒:
  "顾客张先生，信用分850/1000，优质顾客。"
  或
  "⚠️ 该顾客有未解决的逃单记录，建议要求预付款。"
```

## 自动评价收集流程

```
用餐结束 → Agent自动发起对话

Agent: "用餐体验如何？给今天的菜打几分？"
  ↓
顾客: "水煮鱼5分，其他一般4分吧"
  ↓
Agent追问:
  "服务方面满意吗？等位时间能接受吗？"
  ↓
顾客: "服务员态度好，等位有点久"
  ↓
Agent生成评价草稿:
  "根据你的反馈，我生成了以下评价:
   
   评分: 4.5/5
   - 菜品: 5.0 (水煮鱼特别满意)
   - 服务: 4.5 (态度热情)
   - 等位: 3.5 (比预期久)
   
   评价摘要: '水煮鱼口味正宗必点，服务热情，
             但周末等位时间较长建议错峰。'
   
   标签: #口味正宗 #等位久 #服务热情
   
   要发布吗？可以选匿名。"
  ↓
顾客: "发布，实名"
  ↓
Agent上传云端:
  - 写入评价数据库
  - 更新餐厅评分
  - 同步到顾客记忆
```

## 信用评分算法

```python
def calculate_credit_score(customer_history):
    base_score = 500
    
    # 正向因素
    factors = {
        "completed_orders": len(history.completed) * 2,
        "on_time_payment": history.on_time_rate * 100,
        "review_contribution": len(history.reviews) * 5,
        "loyalty": min(history.total_visits * 1, 100)  # 上限100
    }
    
    # 负向因素 (严重)
    penalties = {
        "dine_and_dash": -200,  # 逃单
        "false_dispute": -100,  # 恶意投诉
        "no_show": -50,         # 预订未到
        "late_payment": -20     # 延迟支付
    }
    
    score = base_score + sum(factors.values()) + sum(penalties.values())
    return max(0, min(1000, score))  # 限制0-1000
```

## 隐私与授权

### 顾客授权界面

```yaml
隐私控制中心:
  
  信用信息分享:
    - [x] 允许餐厅查询我的信用评分 (帮助快速结账)
    - [ ] 公开我的用餐次数统计
    - [ ] 允许餐厅看我的历史订单详情
    
  评价设置:
    - [x] 自动询问用餐体验
    - [ ] 自动发布评价 (需我每次确认草稿)
    - [x] 默认匿名评价
    
  数据删除:
    - [申请删除所有云端记忆]  # GDPR style
```

### 餐厅授权界面

```yaml
数据获取权限:
  
  顾客信用:
    - [x] 查询信用评分 (需顾客授权)
    - [ ] 查看详细消费历史
    - [ ] 查看顾客在其他餐厅的评价
    
  评价管理:
    - [x] 回复顾客评价
    - [x] 举报虚假评价
    - [ ] 请求删除恶意评价 (需审核)
```

## 云端API设计

### 顾客端API

```python
# 查询餐厅评价
GET /api/v1/restaurants/{id}/reviews
Query:
  - filter: "verified_only=true"
  - sort: "helpful_desc"
  - similarity_match: "customer_profile_hash"  # 口味相似用户

Response:
  {
    "aggregate": {
      "overall": 4.6,
      "breakdown": {...},
      "trend": "stable"  # rising/falling/stable
    },
    "reviews": [
      {
        "id": "rev_xxx",
        "rating": 5,
        "summary": "AI生成的评价摘要",
        "similarity_to_you": 0.85,  # 口味相似度
        "verified": true
      }
    ]
  }

# 提交评价
POST /api/v1/reviews
Body:
  {
    "restaurant_id": "rst_xxx",
    "visit_id": "v_xxx",
    "ratings": {...},
    "text": "...",
    "anonymous": false
  }
```

### 餐厅端API

```python
# 查询顾客信用 (需顾客授权token)
GET /api/v1/customers/{id}/credit
Headers:
  Authorization: "Bearer {customer_consent_token}"

Response:
  {
    "credit_score": 850,
    "risk_level": "low",  # low/medium/high
    "warnings": [],  # 如有逃单记录
    "recommendation": "正常接待"
  }

# 查询常客档案 (仅限本店顾客)
GET /api/v1/restaurants/{id}/customers/{cid}/profile
Response:
  {
    "visit_count": 12,
    "favorite_dishes": ["d_003"],
    "avg_spend": 120,
    "last_visit": "2026-04-10",
    "satisfaction_trend": "rising"
  }
```

## 安全机制

### 防刷评价

```python
def verify_review_authenticity(review):
    checks = {
        # 1. 消费验证
        "has_verified_visit": review.visit_id in verified_visits,
        
        # 2. 时间合理性
        "reasonable_time": review.submitted_at - review.visit_date < timedelta(days=7),
        
        # 3. 内容质量
        "not_spam": review.text_entropy > 0.5,  # 不是乱码/重复
        
        # 4. 行为模式
        "not_review_bombing": customer.reviews_last_24h < 3,
        
        # 5. 交叉验证
        "ip_not_flagged": review.ip not in spam_ip_list
    }
    
    return all(checks.values())
```

### 逃单记录验证

```python
class BlackmarkVerification:
    """逃单记录必须经过严格验证才能录入"""
    
    required_evidence = [
        "order_confirmation",      # 订单确认
        "payment_attempt_logs",    # 支付尝试记录
        "staff_testimony",         # 员工证词
        "cctv_footage",           # 监控录像 (可选)
        "contact_attempts"         # 联系顾客记录
    ]
    
    @staticmethod
    def verify(blackmark_report):
        # 至少3种证据
        evidence_count = sum(1 for e in required_evidence if e in report)
        return evidence_count >= 3
```

## 使用场景示例

### 场景1: 顾客决策支持

```
顾客正在犹豫是否去某新店
  ↓
Agent自动调取:
  1. 朋友评价: "小王去过，说还不错"
  2. 口味匹配: "和你口味相似的用户评分4.2"
  3. 风险提示: "最近3条评价提到上菜慢"
  4. 优惠提醒: "本周新客8折"
  ↓
建议: "值得一试，但建议错开晚餐高峰"
```

### 场景2: 餐厅风控

```
大额订单(¥2000+)来自新顾客
  ↓
Agent查询信用:
  → 信用分920，无不良记录
  → 建议: "优质顾客，可放心接单"
  ↓
或:
  → 信用分350，有1次逃单记录
  → 建议: "⚠️ 风险顾客，要求预付款50%"
```

### 场景3: 口碑管理

```
餐厅收到负面评价
  ↓
Agent分析:
  → 评价关键词: "上菜慢"
  → 历史同类评价: 15%用户提及
  → 建议: "优化厨房出餐流程"
  ↓
自动回复模板:
  "感谢您的反馈！我们正在优化出餐流程，
   下次光临时出示此回复可获赠凉菜一份。"
```

## 技术实现

### 云端同步代码

见 `scripts/memory_manager.py` 中的 `CloudMemorySync` 类:
- `sync_review_to_cloud()` - 评价上传
- `fetch_restaurant_reviews()` - 评价拉取
- `query_customer_credit()` - 信用查询 (授权验证)
- `report_blackmark()` - 逃单举报 (严格验证)
