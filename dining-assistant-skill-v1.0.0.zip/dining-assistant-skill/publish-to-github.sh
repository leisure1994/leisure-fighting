#!/bin/bash
# Dining Assistant Skill - GitHub Publish Helper
# 用餐助手Skill - GitHub发布助手

echo "=========================================="
echo "  Dining Assistant Skill - 发布到GitHub"
echo "=========================================="
echo ""

# 检查gh CLI
if ! command -v gh &> /dev/null; then
    echo "❌ GitHub CLI (gh) 未安装"
    echo ""
    echo "请安装GitHub CLI:"
    echo "  Ubuntu/Debian: sudo apt install gh"
    echo "  macOS: brew install gh"
    echo "  其他: https://cli.github.com/"
    exit 1
fi

# 检查认证状态
if ! gh auth status &> /dev/null; then
    echo "🔐 需要登录GitHub"
    gh auth login
fi

echo "✅ GitHub CLI 已认证"
echo ""

# 创建仓库
echo "📦 创建GitHub仓库..."
REPO_NAME="dining-assistant-skill"
REPO_DESC="OpenClaw Dining Assistant Skill - 用餐助手Skill，支持餐厅/顾客双端Agent握手"

gh repo create "$REPO_NAME" \
    --public \
    --description "$REPO_DESC" \
    --source=. \
    --remote=origin \
    --push

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ 成功发布到GitHub!"
    echo ""
    echo "📍 仓库地址:"
    gh repo view "$REPO_NAME" --web 2>/dev/null || echo "   https://github.com/$(gh api user -q '.login')/$REPO_NAME"
else
    echo ""
    echo "❌ 发布失败，尝试手动方式..."
    echo ""
    echo "手动发布步骤:"
    echo "1. 访问 https://github.com/new"
    echo "2. 输入仓库名: $REPO_NAME"
    echo "3. 描述: $REPO_DESC"
    echo "4. 选择 Public"
    echo "5. 不要勾选初始化选项"
    echo "6. 创建后执行:"
    echo "   git remote add origin https://github.com/YOUR_USERNAME/$REPO_NAME.git"
    echo "   git branch -M main"
    echo "   git push -u origin main"
fi
