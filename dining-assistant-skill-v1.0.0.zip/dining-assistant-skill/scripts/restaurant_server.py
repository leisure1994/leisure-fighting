#!/usr/bin/env python3
"""
Dining Assistant - Restaurant Mode Server
餐厅模式服务器

Handles:
- Agent discovery and handshake
- Menu management
- Queue management
- Order processing
- Table management
"""

import asyncio
import json
import logging
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from dataclasses import dataclass, field
import websockets

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class Dish:
    dish_id: str
    name: str
    name_cn: str
    price: float
    category: str
    description: str = ""
    allergens: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    is_available: bool = True
    prep_time: int = 15
    popularity: float = 0.5


@dataclass
class Table:
    table_id: str
    name: str
    capacity: int
    status: str = "available"  # available, occupied, reserved, cleaning
    current_order: Optional[str] = None
    qr_code: str = ""


@dataclass
class QueueEntry:
    queue_number: int
    customer_agent_id: str
    party_size: int
    status: str = "waiting"
    joined_at: datetime = field(default_factory=datetime.now)
    estimated_seating: Optional[datetime] = None
    pre_order: Optional[Dict] = None


@dataclass
class Order:
    order_id: str
    customer_agent_id: str
    items: List[Dict]
    party_size: int
    status: str = "pending"  # pending, confirmed, preparing, ready, completed, cancelled
    table_id: Optional[str] = None
    queue_number: Optional[int] = None
    created_at: datetime = field(default_factory=datetime.now)
    estimated_ready: Optional[datetime] = None
    total_amount: float = 0.0


class RestaurantAgent:
    """餐厅模式Agent - 处理顾客连接、队列、订单"""
    
    def __init__(self, restaurant_id: str, name: str, location: dict, config: dict = None):
        self.restaurant_id = restaurant_id
        self.name = name
        self.location = location
        self.config = config or {}
        
        # Data storage
        self.menu: Dict[str, Dish] = {}
        self.categories: List[Dict] = []
        self.tables: Dict[str, Table] = {}
        self.queue: List[QueueEntry] = []
        self.orders: Dict[str, Order] = {}
        self.current_queue_number = 0
        
        # Connected customers
        self.connected_customers: Dict[str, websockets.WebSocketServerProtocol] = {}
        self.customer_contexts: Dict[str, Dict] = {}
        
        # Server state
        self.server = None
        self.is_running = False
        
        logger.info(f"RestaurantAgent initialized: {name} ({restaurant_id})")
    
    def set_menu(self, menu_data: dict):
        """设置菜单"""
        self.categories = menu_data.get("categories", [])
        
        for dish_data in menu_data.get("dishes", []):
            dish = Dish(
                dish_id=dish_data["dish_id"],
                name=dish_data["name"],
                name_cn=dish_data.get("name_cn", ""),
                price=dish_data["price"],
                category=dish_data["category_id"],
                description=dish_data.get("description", ""),
                allergens=dish_data.get("allergens", []),
                tags=dish_data.get("dietary_tags", []),
                is_available=dish_data.get("is_available", True),
                prep_time=dish_data.get("prep_time_minutes", 15),
                popularity=dish_data.get("popularity_score", 0.5)
            )
            self.menu[dish.dish_id] = dish
        
        logger.info(f"Menu loaded: {len(self.menu)} dishes")
    
    def add_table(self, table_id: str, name: str, capacity: int):
        """添加桌位"""
        qr = f"https://dining.openclaw.ai/r/{self.restaurant_id}/t/{table_id}"
        self.tables[table_id] = Table(
            table_id=table_id,
            name=name,
            capacity=capacity,
            qr_code=qr
        )
        logger.info(f"Table added: {name} (capacity: {capacity})")
    
    def update_queue_status(self, current_number: int = None, wait_minutes: int = None):
        """更新队列状态"""
        if current_number is not None:
            self.current_queue_number = current_number
        
        # Broadcast to all waiting customers
        for entry in self.queue:
            if entry.status == "waiting":
                position = self._get_queue_position(entry.queue_number)
                estimated_wait = wait_minutes or (position * 10)
                
                asyncio.create_task(
                    self._send_queue_update(entry.customer_agent_id, position, estimated_wait)
                )
    
    def update_table_status(self, table_id: str, status: str, order_id: str = None):
        """更新桌位状态"""
        if table_id in self.tables:
            self.tables[table_id].status = status
            self.tables[table_id].current_order = order_id
            logger.info(f"Table {table_id} status: {status}")
    
    def get_available_tables(self, party_size: int) -> List[Table]:
        """获取可用桌位"""
        return [
            t for t in self.tables.values()
            if t.status == "available" and t.capacity >= party_size
        ]
    
    def get_recommendations(self, customer_preferences: dict) -> List[Dict]:
        """基于顾客偏好生成推荐"""
        recommendations = []
        
        prefs = customer_preferences.get("preferences", [])
        avoid = customer_preferences.get("avoid", [])
        allergies = customer_preferences.get("allergies", [])
        party_size = customer_preferences.get("party_size", 2)
        
        for dish in self.menu.values():
            if not dish.is_available:
                continue
            
            # Check allergens
            if any(a in dish.allergens for a in allergies):
                continue
            
            # Check avoided ingredients
            if any(a in dish.tags for a in avoid):
                continue
            
            # Calculate match score
            score = self._calculate_match_score(dish, prefs, party_size)
            
            recommendations.append({
                "dish_id": dish.dish_id,
                "name": dish.name,
                "name_cn": dish.name_cn,
                "price": dish.price,
                "description": dish.description,
                "match_score": score,
                "reason": self._get_recommendation_reason(dish, prefs)
            })
        
        # Sort by match score
        recommendations.sort(key=lambda x: x["match_score"], reverse=True)
        return recommendations[:10]  # Top 10
    
    def _calculate_match_score(self, dish: Dish, prefs: List[str], party_size: int) -> float:
        """计算菜品与偏好的匹配度"""
        score = dish.popularity * 0.3  # Base popularity
        
        # Preference matching
        for pref in prefs:
            if pref.lower() in dish.tags:
                score += 0.2
            if pref.lower() in dish.description.lower():
                score += 0.1
        
        # Suitable for party size (shareable dishes)
        if party_size > 2 and "shareable" in dish.tags:
            score += 0.15
        
        return min(score, 1.0)
    
    def _get_recommendation_reason(self, dish: Dish, prefs: List[str]) -> str:
        """生成推荐原因"""
        if any(p in dish.tags for p in prefs):
            return f"符合您的口味偏好"
        if dish.popularity > 0.8:
            return "本店招牌"
        if "chef_recommended" in dish.tags:
            return "厨师推荐"
        return "热销菜品"
    
    def join_queue(self, customer_agent_id: str, party_size: int, pre_order: dict = None) -> QueueEntry:
        """顾客加入队列"""
        self.current_queue_number += 1
        
        entry = QueueEntry(
            queue_number=self.current_queue_number,
            customer_agent_id=customer_agent_id,
            party_size=party_size,
            pre_order=pre_order
        )
        
        self.queue.append(entry)
        logger.info(f"Customer joined queue: #{entry.queue_number}, party: {party_size}")
        
        return entry
    
    def _get_queue_position(self, queue_number: int) -> int:
        """获取队列位置"""
        for i, entry in enumerate(self.queue):
            if entry.queue_number == queue_number and entry.status == "waiting":
                return i + 1
        return 0
    
    def assign_table(self, queue_number: int) -> Optional[str]:
        """为队列号码分配桌位"""
        entry = next((e for e in self.queue if e.queue_number == queue_number), None)
        if not entry:
            return None
        
        available = self.get_available_tables(entry.party_size)
        if not available:
            return None
        
        # Assign best fit table
        table = min(available, key=lambda t: t.capacity - entry.party_size)
        entry.status = "seated"
        self.update_table_status(table.table_id, "occupied")
        
        logger.info(f"Table assigned: {table.table_id} to queue #{queue_number}")
        return table.table_id
    
    def create_order(self, customer_agent_id: str, items: List[Dict], party_size: int) -> Order:
        """创建订单"""
        order_id = f"ord_{datetime.now().strftime('%Y%m%d')}_{uuid.uuid4().hex[:6]}"
        
        # Calculate total
        total = 0.0
        for item in items:
            dish = self.menu.get(item["dish_id"])
            if dish:
                total += dish.price * item.get("quantity", 1)
        
        # Calculate estimated ready time
        max_prep = max(
            self.menu.get(i["dish_id"], Dish("", "", "", 0, "")).prep_time
            for i in items
        )
        estimated_ready = datetime.now() + timedelta(minutes=max_prep + 5)
        
        order = Order(
            order_id=order_id,
            customer_agent_id=customer_agent_id,
            items=items,
            party_size=party_size,
            total_amount=total,
            estimated_ready=estimated_ready
        )
        
        self.orders[order_id] = order
        logger.info(f"Order created: {order_id}, amount: {total}")
        
        return order
    
    def confirm_order(self, order_id: str, table_id: str = None) -> Order:
        """确认订单"""
        if order_id not in self.orders:
            raise ValueError(f"Order not found: {order_id}")
        
        order = self.orders[order_id]
        order.status = "confirmed"
        order.table_id = table_id
        
        logger.info(f"Order confirmed: {order_id}")
        return order
    
    def update_order_status(self, order_id: str, status: str):
        """更新订单状态"""
        if order_id in self.orders:
            self.orders[order_id].status = status
            logger.info(f"Order {order_id} status: {status}")
            
            # Notify customer
            order = self.orders[order_id]
            asyncio.create_task(
                self._send_order_update(order.customer_agent_id, order_id, status)
            )
    
    async def _send_queue_update(self, customer_agent_id: str, position: int, estimated_wait: int):
        """发送队列更新"""
        if customer_agent_id in self.connected_customers:
            message = {
                "message_type": "QUEUE_UPDATE",
                "payload": {
                    "position": position,
                    "estimated_wait_minutes": estimated_wait,
                    "status": "waiting"
                }
            }
            try:
                await self.connected_customers[customer_agent_id].send(json.dumps(message))
            except Exception as e:
                logger.error(f"Failed to send queue update: {e}")
    
    async def _send_order_update(self, customer_agent_id: str, order_id: str, status: str):
        """发送订单状态更新"""
        if customer_agent_id in self.connected_customers:
            message = {
                "message_type": "ORDER_STATUS",
                "payload": {
                    "order_id": order_id,
                    "status": status
                }
            }
            try:
                await self.connected_customers[customer_agent_id].send(json.dumps(message))
            except Exception as e:
                logger.error(f"Failed to send order update: {e}")
    
    async def handle_message(self, websocket, message: str):
        """处理收到的消息"""
        try:
            data = json.loads(message)
            msg_type = data.get("message_type")
            sender = data.get("sender", {})
            customer_agent_id = sender.get("agent_id")
            
            logger.info(f"Received: {msg_type} from {customer_agent_id}")
            
            if msg_type == "DISCOVERY":
                await self._handle_discovery(websocket, customer_agent_id)
            
            elif msg_type == "HANDSHAKE_REQUEST":
                await self._handle_handshake(websocket, data)
            
            elif msg_type == "MENU_REQUEST":
                await self._handle_menu_request(websocket, customer_agent_id)
            
            elif msg_type == "RECOMMENDATION_REQUEST":
                await self._handle_recommendation_request(websocket, data)
            
            elif msg_type == "QUEUE_JOIN":
                await self._handle_queue_join(websocket, data)
            
            elif msg_type == "ORDER_SUBMIT":
                await self._handle_order_submit(websocket, data)
            
            else:
                logger.warning(f"Unknown message type: {msg_type}")
        
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON: {message}")
        except Exception as e:
            logger.error(f"Error handling message: {e}")
    
    async def _handle_discovery(self, websocket, customer_agent_id: str):
        """处理发现请求"""
        self.connected_customers[customer_agent_id] = websocket
        
        response = {
            "message_type": "DISCOVERY_RESPONSE",
            "sender": {
                "agent_id": self.restaurant_id,
                "agent_type": "restaurant"
            },
            "payload": {
                "restaurant_name": self.name,
                "status": "accepting_customers"
            }
        }
        await websocket.send(json.dumps(response))
    
    async def _handle_handshake(self, websocket, data: dict):
        """处理握手请求"""
        customer_agent_id = data["sender"]["agent_id"]
        user_profile = data.get("payload", {}).get("user_profile", {})
        
        # Store customer context
        self.customer_contexts[customer_agent_id] = user_profile
        
        # Get current status
        available_tables = self.get_available_tables(
            user_profile.get("party_size", 2)
        )
        
        response = {
            "message_type": "HANDSHAKE_RESPONSE",
            "sender": {
                "agent_id": self.restaurant_id,
                "agent_type": "restaurant"
            },
            "payload": {
                "restaurant_info": {
                    "name": self.name,
                    "location": self.location
                },
                "current_status": {
                    "queue_length": len(self.queue),
                    "current_number": self.current_queue_number,
                    "available_tables": len(available_tables)
                },
                "menu_summary": {
                    "categories": [c["name"] for c in self.categories],
                    "total_dishes": len(self.menu)
                }
            }
        }
        await websocket.send(json.dumps(response))
        logger.info(f"Handshake completed with {customer_agent_id}")
    
    async def _handle_menu_request(self, websocket, customer_agent_id: str):
        """处理菜单请求"""
        menu_response = {
            "message_type": "MENU_RESPONSE",
            "payload": {
                "categories": self.categories,
                "dishes": [
                    {
                        "dish_id": d.dish_id,
                        "name": d.name,
                        "name_cn": d.name_cn,
                        "price": d.price,
                        "description": d.description,
                        "allergens": d.allergens,
                        "tags": d.tags,
                        "is_available": d.is_available
                    }
                    for d in self.menu.values()
                ]
            }
        }
        await websocket.send(json.dumps(menu_response))
    
    async def _handle_recommendation_request(self, websocket, data: dict):
        """处理推荐请求"""
        customer_agent_id = data["sender"]["agent_id"]
        preferences = data.get("payload", {})
        
        recommendations = self.get_recommendations(preferences)
        
        response = {
            "message_type": "RECOMMENDATION_RESPONSE",
            "payload": {
                "recommendations": recommendations,
                "combo_suggestions": self._get_combo_suggestions(preferences)
            }
        }
        await websocket.send(json.dumps(response))
    
    def _get_combo_suggestions(self, preferences: dict) -> List[Dict]:
        """获取套餐建议"""
        # Simplified combo logic
        party_size = preferences.get("party_size", 2)
        
        # Find dishes suitable for combo
        available = [d for d in self.menu.values() if d.is_available]
        
        # Build a combo
        combo = []
        total = 0.0
        
        # Add one dish per person
        for i, dish in enumerate(available[:party_size]):
            combo.append({
                "dish_id": dish.dish_id,
                "name": dish.name,
                "quantity": 1
            })
            total += dish.price
        
        return [{
            "combo_id": "suggested_001",
            "name": f"{party_size}人推荐套餐",
            "items": combo,
            "total_price": total,
            "estimated_prep_minutes": 25
        }]
    
    async def _handle_queue_join(self, websocket, data: dict):
        """处理加入队列请求"""
        customer_agent_id = data["sender"]["agent_id"]
        payload = data.get("payload", {})
        
        party_size = payload.get("party_size", 2)
        pre_order = payload.get("pre_order")
        
        entry = self.join_queue(customer_agent_id, party_size, pre_order)
        
        response = {
            "message_type": "QUEUE_CONFIRMATION",
            "payload": {
                "queue_number": entry.queue_number,
                "position": self._get_queue_position(entry.queue_number),
                "estimated_wait_minutes": len(self.queue) * 10,
                "status": "waiting"
            }
        }
        await websocket.send(json.dumps(response))
    
    async def _handle_order_submit(self, websocket, data: dict):
        """处理订单提交"""
        customer_agent_id = data["sender"]["agent_id"]
        payload = data.get("payload", {})
        
        items = payload.get("items", [])
        party_size = payload.get("party_size", 2)
        
        # Create order
        order = self.create_order(customer_agent_id, items, party_size)
        
        # Try to assign table
        table_id = None
        if self.config.get("auto_assign_tables", True):
            # Find queue entry
            entry = next(
                (e for e in self.queue if e.customer_agent_id == customer_agent_id),
                None
            )
            if entry:
                table_id = self.assign_table(entry.queue_number)
                order.queue_number = entry.queue_number
        
        # Confirm order
        order = self.confirm_order(order.order_id, table_id)
        
        response = {
            "message_type": "ORDER_CONFIRMATION",
            "payload": {
                "order_id": order.order_id,
                "status": order.status,
                "table_id": order.table_id,
                "queue_number": order.queue_number,
                "total_amount": order.total_amount,
                "estimated_ready": order.estimated_ready.isoformat() if order.estimated_ready else None
            }
        }
        await websocket.send(json.dumps(response))
        logger.info(f"Order confirmed: {order.order_id}")
    
    async def ws_handler(self, websocket, path):
        """WebSocket连接处理器"""
        logger.info(f"New connection from {websocket.remote_address}")
        
        try:
            async for message in websocket:
                await self.handle_message(websocket, message)
        except websockets.exceptions.ConnectionClosed:
            logger.info(f"Connection closed: {websocket.remote_address}")
        finally:
            # Remove from connected customers
            for agent_id, ws in list(self.connected_customers.items()):
                if ws == websocket:
                    del self.connected_customers[agent_id]
                    logger.info(f"Customer disconnected: {agent_id}")
                    break
    
    def start_server(self, host: str = "0.0.0.0", port: int = 8080):
        """启动服务器"""
        self.server = websockets.serve(self.ws_handler, host, port)
        self.is_running = True
        
        logger.info(f"Restaurant server starting on {host}:{port}")
        
        asyncio.get_event_loop().run_until_complete(self.server)
        asyncio.get_event_loop().run_forever()
    
    def stop_server(self):
        """停止服务器"""
        self.is_running = False
        if self.server:
            self.server.close()
        logger.info("Restaurant server stopped")


# Example usage
if __name__ == "__main__":
    # Create restaurant
    restaurant = RestaurantAgent(
        restaurant_id="rst_demo_001",
        name="Demo Restaurant",
        location={"lat": 39.9042, "lng": 116.4074}
    )
    
    # Set menu
    sample_menu = {
        "categories": [
            {"category_id": "cat_1", "name": "Appetizers", "order": 1},
            {"category_id": "cat_2", "name": "Main Courses", "order": 2}
        ],
        "dishes": [
            {
                "dish_id": "dish_001",
                "name": "Mapo Tofu",
                "name_cn": "麻婆豆腐",
                "category_id": "cat_2",
                "description": "Spicy tofu with minced pork",
                "price": 28.00,
                "dietary_tags": ["spicy", "sichuan"],
                "popularity_score": 0.95
            }
        ]
    }
    restaurant.set_menu(sample_menu)
    
    # Add tables
    for i in range(1, 11):
        restaurant.add_table(f"tbl_{i:02d}", f"Table {i}", 4)
    
    # Start server
    restaurant.start_server()
