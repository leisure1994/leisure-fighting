#!/usr/bin/env python3
"""
Dining Assistant - QR Code Generator
QR码生成器

Generates QR codes for restaurant discovery and table-specific access.
"""

import qrcode
import qrcode.image.svg
from typing import Optional, Dict
import json
import hashlib
import time


class QRCodeGenerator:
    """QR码生成器"""
    
    BASE_URL = "https://dining.openclaw.ai"
    
    def __init__(self, secret_key: str = None):
        self.secret_key = secret_key or self._generate_secret()
    
    def _generate_secret(self) -> str:
        """生成密钥用于签名"""
        return hashlib.sha256(str(time.time()).encode()).hexdigest()[:16]
    
    def generate_restaurant_qr(self, restaurant_id: str, 
                                expires_hours: int = 24,
                                format: str = "svg") -> Dict:
        """
        生成餐厅级QR码
        
        Args:
            restaurant_id: 餐厅ID
            expires_hours: QR码有效期（小时）
            format: 输出格式 (svg, png)
        
        Returns:
            包含QR码数据和文件路径的字典
        """
        # Generate URL
        timestamp = int(time.time())
        expires = timestamp + (expires_hours * 3600)
        
        url = f"{self.BASE_URL}/r/{restaurant_id}?t={timestamp}&e={expires}"
        
        # Add signature
        signature = self._sign_url(url)
        url += f"&s={signature}"
        
        # Generate QR code
        filename = f"qr_restaurant_{restaurant_id}_{timestamp}"
        
        if format == "svg":
            filepath = self._generate_svg(url, filename)
        else:
            filepath = self._generate_png(url, filename)
        
        return {
            "url": url,
            "filepath": filepath,
            "restaurant_id": restaurant_id,
            "expires_at": expires,
            "format": format
        }
    
    def generate_table_qr(self, restaurant_id: str, table_id: str,
                           table_name: str, capacity: int,
                           expires_hours: int = 168,  # 7 days default
                           format: str = "svg") -> Dict:
        """
        生成桌位级QR码
        
        Args:
            restaurant_id: 餐厅ID
            table_id: 桌位ID
            table_name: 桌位名称（如 "A1"）
            capacity: 容量
            expires_hours: QR码有效期（小时）
            format: 输出格式
        
        Returns:
            包含QR码数据和文件路径的字典
        """
        timestamp = int(time.time())
        expires = timestamp + (expires_hours * 3600)
        
        # Include table info in URL
        url = f"{self.BASE_URL}/r/{restaurant_id}/t/{table_id}?n={table_name}&c={capacity}&t={timestamp}&e={expires}"
        
        signature = self._sign_url(url)
        url += f"&s={signature}"
        
        filename = f"qr_table_{restaurant_id}_{table_id}_{timestamp}"
        
        if format == "svg":
            filepath = self._generate_svg(url, filename)
        else:
            filepath = self._generate_png(url, filename)
        
        return {
            "url": url,
            "filepath": filepath,
            "restaurant_id": restaurant_id,
            "table_id": table_id,
            "table_name": table_name,
            "capacity": capacity,
            "expires_at": expires,
            "format": format
        }
    
    def generate_takeout_qr(self, restaurant_id: str,
                             expires_hours: int = 24,
                             format: str = "svg") -> Dict:
        """
        生成外卖专用QR码
        
        Args:
            restaurant_id: 餐厅ID
            expires_hours: QR码有效期
            format: 输出格式
        
        Returns:
            QR码数据字典
        """
        timestamp = int(time.time())
        expires = timestamp + (expires_hours * 3600)
        
        url = f"{self.BASE_URL}/r/{restaurant_id}/takeout?t={timestamp}&e={expires}"
        
        signature = self._sign_url(url)
        url += f"&s={signature}"
        
        filename = f"qr_takeout_{restaurant_id}_{timestamp}"
        
        if format == "svg":
            filepath = self._generate_svg(url, filename)
        else:
            filepath = self._generate_png(url, filename)
        
        return {
            "url": url,
            "filepath": filepath,
            "restaurant_id": restaurant_id,
            "mode": "takeout",
            "expires_at": expires,
            "format": format
        }
    
    def _sign_url(self, url: str) -> str:
        """为URL签名"""
        return hashlib.sha256(
            (url + self.secret_key).encode()
        ).hexdigest()[:16]
    
    def _generate_svg(self, data: str, filename: str) -> str:
        """生成SVG格式的QR码"""
        factory = qrcode.image.svg.SvgImage
        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=10,
            border=4,
            image_factory=factory
        )
        qr.add_data(data)
        qr.make(fit=True)
        
        img = qr.make_image()
        filepath = f"{filename}.svg"
        img.save(filepath)
        return filepath
    
    def _generate_png(self, data: str, filename: str) -> str:
        """生成PNG格式的QR码"""
        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=10,
            border=4
        )
        qr.add_data(data)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        filepath = f"{filename}.png"
        img.save(filepath)
        return filepath
    
    def verify_qr_url(self, url: str) -> bool:
        """验证QR码URL的有效性"""
        try:
            # Parse URL
            parts = url.split("&")
            params = {}
            for part in parts:
                if "=" in part:
                    key, value = part.split("=", 1)
                    params[key.split("?")[-1]] = value
            
            # Check expiration
            expires = int(params.get("e", 0))
            if time.time() > expires:
                return False  # Expired
            
            # Verify signature
            original_url = url.split("&s=")[0]
            signature = params.get("s", "")
            expected = self._sign_url(original_url)
            
            return signature == expected
            
        except Exception:
            return False
    
    def parse_qr_url(self, url: str) -> Optional[Dict]:
        """
        解析QR码URL
        
        Returns:
            包含解析后数据的字典，或None如果无效
        """
        if not self.verify_qr_url(url):
            return None
        
        try:
            # Parse path
            path_start = url.find("/r/")
            if path_start == -1:
                return None
            
            path_part = url[path_start:].split("?")[0]
            path_segments = path_part.split("/")
            
            result = {
                "base_url": url[:path_start],
                "restaurant_id": None,
                "table_id": None,
                "table_name": None,
                "capacity": None,
                "mode": "dine_in"  # default
            }
            
            # Parse segments
            if len(path_segments) >= 3:
                result["restaurant_id"] = path_segments[2]
            
            if len(path_segments) >= 4:
                if path_segments[3] == "t" and len(path_segments) >= 5:
                    result["table_id"] = path_segments[4]
                    result["mode"] = "table"
                elif path_segments[3] == "takeout":
                    result["mode"] = "takeout"
            
            # Parse query params
            query_start = url.find("?")
            if query_start != -1:
                query = url[query_start + 1:]
                params = {}
                for param in query.split("&"):
                    if "=" in param and not param.startswith("s="):
                        key, value = param.split("=", 1)
                        params[key] = value
                
                result["table_name"] = params.get("n")
                result["capacity"] = int(params.get("c", 0)) if params.get("c") else None
                result["timestamp"] = int(params.get("t", 0))
                result["expires_at"] = int(params.get("e", 0))
            
            return result
            
        except Exception:
            return None


class QRCodeBatchGenerator:
    """批量QR码生成器"""
    
    def __init__(self, secret_key: str = None):
        self.generator = QRCodeGenerator(secret_key)
    
    def generate_for_restaurant(self, restaurant_id: str, 
                                 tables: list,
                                 output_dir: str = "./qr_codes") -> Dict:
        """
        为餐厅生成所有QR码
        
        Args:
            restaurant_id: 餐厅ID
            tables: 桌位列表 [{"table_id": "", "name": "", "capacity": 4}, ...]
            output_dir: 输出目录
        
        Returns:
            生成的文件列表
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        results = {
            "restaurant_qr": None,
            "table_qrs": [],
            "takeout_qr": None,
            "output_dir": output_dir
        }
        
        # Generate restaurant QR
        restaurant_qr = self.generator.generate_restaurant_qr(
            restaurant_id, format="png"
        )
        results["restaurant_qr"] = restaurant_qr
        
        # Generate table QRs
        for table in tables:
            table_qr = self.generator.generate_table_qr(
                restaurant_id=restaurant_id,
                table_id=table["table_id"],
                table_name=table["name"],
                capacity=table["capacity"],
                format="png"
            )
            results["table_qrs"].append(table_qr)
        
        # Generate takeout QR
        takeout_qr = self.generator.generate_takeout_qr(
            restaurant_id, format="png"
        )
        results["takeout_qr"] = takeout_qr
        
        return results


# Example usage
def demo():
    """演示QR码生成"""
    
    generator = QRCodeGenerator()
    
    # Generate restaurant QR
    print("=== 餐厅级QR码 ===")
    restaurant_qr = generator.generate_restaurant_qr("rst_demo_001", format="png")
    print(f"URL: {restaurant_qr['url']}")
    print(f"文件: {restaurant_qr['filepath']}")
    print(f"过期时间: {restaurant_qr['expires_at']}")
    
    # Generate table QR
    print("\n=== 桌位QR码 ===")
    table_qr = generator.generate_table_qr(
        "rst_demo_001",
        "tbl_A01",
        "A1",
        4,
        format="png"
    )
    print(f"URL: {table_qr['url']}")
    print(f"文件: {table_qr['filepath']}")
    print(f"桌位: {table_qr['table_name']} (容量: {table_qr['capacity']})")
    
    # Parse QR URL
    print("\n=== 解析QR码 ===")
    parsed = generator.parse_qr_url(table_qr['url'])
    print(f"解析结果: {json.dumps(parsed, indent=2, ensure_ascii=False)}")
    
    # Batch generation
    print("\n=== 批量生成 ===")
    batch = QRCodeBatchGenerator()
    tables = [
        {"table_id": "tbl_A01", "name": "A1", "capacity": 4},
        {"table_id": "tbl_A02", "name": "A2", "capacity": 4},
        {"table_id": "tbl_B01", "name": "B1", "capacity": 6},
    ]
    results = batch.generate_for_restaurant("rst_demo_001", tables)
    print(f"生成了 {len(results['table_qrs'])} 个桌位QR码")


if __name__ == "__main__":
    demo()
