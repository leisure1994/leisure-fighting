#!/usr/bin/env python3
"""
Dining Assistant - Handshake Protocol Implementation
握手协议实现

Handles Agent-to-Agent discovery and secure handshake.
"""

import json
import hashlib
import hmac
import time
from typing import Dict, Optional
from dataclasses import dataclass
from enum import Enum


class MessageType(Enum):
    # Discovery
    DISCOVERY = "DISCOVERY"
    DISCOVERY_RESPONSE = "DISCOVERY_RESPONSE"
    
    # Handshake
    HANDSHAKE_REQUEST = "HANDSHAKE_REQUEST"
    HANDSHAKE_RESPONSE = "HANDSHAKE_RESPONSE"
    HANDSHAKE_ACK = "HANDSHAKE_ACK"
    
    # Data Exchange
    MENU_REQUEST = "MENU_REQUEST"
    MENU_RESPONSE = "MENU_RESPONSE"
    
    RECOMMENDATION_REQUEST = "RECOMMENDATION_REQUEST"
    RECOMMENDATION_RESPONSE = "RECOMMENDATION_RESPONSE"
    
    # Queue
    QUEUE_JOIN = "QUEUE_JOIN"
    QUEUE_CONFIRMATION = "QUEUE_CONFIRMATION"
    QUEUE_UPDATE = "QUEUE_UPDATE"
    
    # Order
    ORDER_SUBMIT = "ORDER_SUBMIT"
    ORDER_CONFIRMATION = "ORDER_CONFIRMATION"
    ORDER_MODIFY = "ORDER_MODIFY"
    ORDER_STATUS = "ORDER_STATUS"
    
    # Error
    ERROR = "ERROR"
    PING = "PING"
    PONG = "PONG"


@dataclass
class AgentIdentity:
    """Agent身份标识"""
    agent_id: str
    agent_type: str  # "restaurant" or "customer"
    capabilities: list
    public_key: str = ""
    
    def to_dict(self) -> dict:
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "capabilities": self.capabilities
        }


class HandshakeProtocol:
    """握手协议处理器"""
    
    # Protocol version
    VERSION = "1.0.0"
    
    # Timeout settings (seconds)
    DISCOVERY_TIMEOUT = 5
    HANDSHAKE_TIMEOUT = 10
    
    def __init__(self, identity: AgentIdentity, secret_key: str = None):
        self.identity = identity
        self.secret_key = secret_key or self._generate_secret()
        self.sessions: Dict[str, dict] = {}  # Active sessions
    
    def _generate_secret(self) -> str:
        """生成密钥"""
        return hashlib.sha256(str(time.time()).encode()).hexdigest()[:32]
    
    def create_discovery_message(self) -> dict:
        """创建发现消息"""
        timestamp = int(time.time())
        
        message = {
            "message_type": MessageType.DISCOVERY.value,
            "protocol_version": self.VERSION,
            "sender": self.identity.to_dict(),
            "timestamp": timestamp,
            "nonce": self._generate_nonce()
        }
        
        # Add signature if secret key exists
        if self.secret_key:
            message["signature"] = self._sign_message(message)
        
        return message
    
    def create_handshake_request(self, user_profile: dict) -> dict:
        """创建握手请求"""
        timestamp = int(time.time())
        
        message = {
            "message_type": MessageType.HANDSHAKE_REQUEST.value,
            "protocol_version": self.VERSION,
            "sender": self.identity.to_dict(),
            "payload": {
                "user_profile": user_profile,
                "supported_formats": ["json"],
                "preferred_language": "zh-CN"
            },
            "timestamp": timestamp,
            "session_id": self._generate_session_id()
        }
        
        if self.secret_key:
            message["signature"] = self._sign_message(message)
        
        return message
    
    def create_handshake_response(self, restaurant_info: dict, 
                                   current_status: dict,
                                   session_id: str = None) -> dict:
        """创建握手响应"""
        timestamp = int(time.time())
        
        message = {
            "message_type": MessageType.HANDSHAKE_RESPONSE.value,
            "protocol_version": self.VERSION,
            "sender": self.identity.to_dict(),
            "payload": {
                "restaurant_info": restaurant_info,
                "current_status": current_status,
                "supported_features": [
                    "queue_management",
                    "pre_order",
                    "table_reservation",
                    "recommendations"
                ]
            },
            "timestamp": timestamp,
            "session_id": session_id or self._generate_session_id()
        }
        
        if self.secret_key:
            message["signature"] = self._sign_message(message)
        
        return message
    
    def verify_message(self, message: dict) -> bool:
        """验证消息签名"""
        if not self.secret_key:
            return True  # No verification if no secret
        
        signature = message.pop("signature", None)
        if not signature:
            return False
        
        expected = self._sign_message(message)
        return hmac.compare_digest(signature, expected)
    
    def _sign_message(self, message: dict) -> str:
        """签名消息"""
        if not self.secret_key:
            return ""
        
        # Create canonical JSON representation
        canonical = json.dumps(message, sort_keys=True, separators=(',', ':'))
        
        # HMAC-SHA256
        return hmac.new(
            self.secret_key.encode(),
            canonical.encode(),
            hashlib.sha256
        ).hexdigest()
    
    def _generate_nonce(self) -> str:
        """生成随机nonce"""
        return hashlib.sha256(str(time.time()).encode()).hexdigest()[:16]
    
    def _generate_session_id(self) -> str:
        """生成会话ID"""
        return f"sess_{int(time.time())}_{hashlib.sha256(str(time.time()).encode()).hexdigest()[:8]}"
    
    def validate_discovery_response(self, message: dict) -> bool:
        """验证发现响应"""
        if message.get("message_type") != MessageType.DISCOVERY_RESPONSE.value:
            return False
        
        # Check timestamp freshness
        timestamp = message.get("timestamp", 0)
        if int(time.time()) - timestamp > self.DISCOVERY_TIMEOUT:
            return False
        
        return True
    
    def validate_handshake_response(self, message: dict, expected_session: str = None) -> bool:
        """验证握手响应"""
        if message.get("message_type") != MessageType.HANDSHAKE_RESPONSE.value:
            return False
        
        # Check timestamp freshness
        timestamp = message.get("timestamp", 0)
        if int(time.time()) - timestamp > self.HANDSHAKE_TIMEOUT:
            return False
        
        # Check session ID if provided
        if expected_session:
            if message.get("session_id") != expected_session:
                return False
        
        return True


class SecureChannel:
    """安全通信通道"""
    
    def __init__(self, session_id: str, local_agent: AgentIdentity, remote_agent: AgentIdentity):
        self.session_id = session_id
        self.local_agent = local_agent
        self.remote_agent = remote_agent
        self.established_at = time.time()
        self.last_activity = time.time()
        self.is_active = True
    
    def update_activity(self):
        """更新活动时间"""
        self.last_activity = time.time()
    
    def is_expired(self, timeout: int = 300) -> bool:
        """检查会话是否过期"""
        return (time.time() - self.last_activity) > timeout
    
    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "local_agent": self.local_agent.to_dict(),
            "remote_agent": self.remote_agent.to_dict(),
            "established_at": self.established_at,
            "last_activity": self.last_activity,
            "is_active": self.is_active
        }


# Message builders for common operations

class MessageBuilder:
    """消息构建器"""
    
    @staticmethod
    def menu_request(agent_id: str) -> dict:
        return {
            "message_type": MessageType.MENU_REQUEST.value,
            "sender": {"agent_id": agent_id, "agent_type": "customer"}
        }
    
    @staticmethod
    def menu_response(agent_id: str, categories: list, dishes: list) -> dict:
        return {
            "message_type": MessageType.MENU_RESPONSE.value,
            "sender": {"agent_id": agent_id, "agent_type": "restaurant"},
            "payload": {
                "categories": categories,
                "dishes": dishes
            }
        }
    
    @staticmethod
    def recommendation_request(agent_id: str, preferences: dict) -> dict:
        return {
            "message_type": MessageType.RECOMMENDATION_REQUEST.value,
            "sender": {"agent_id": agent_id, "agent_type": "customer"},
            "payload": preferences
        }
    
    @staticmethod
    def recommendation_response(agent_id: str, recommendations: list, combos: list = None) -> dict:
        return {
            "message_type": MessageType.RECOMMENDATION_RESPONSE.value,
            "sender": {"agent_id": agent_id, "agent_type": "restaurant"},
            "payload": {
                "recommendations": recommendations,
                "combo_suggestions": combos or []
            }
        }
    
    @staticmethod
    def queue_join(agent_id: str, party_size: int, pre_order: dict = None) -> dict:
        return {
            "message_type": MessageType.QUEUE_JOIN.value,
            "sender": {"agent_id": agent_id, "agent_type": "customer"},
            "payload": {
                "party_size": party_size,
                "pre_order": pre_order
            }
        }
    
    @staticmethod
    def queue_confirmation(agent_id: str, queue_number: int, position: int, 
                            wait_minutes: int) -> dict:
        return {
            "message_type": MessageType.QUEUE_CONFIRMATION.value,
            "sender": {"agent_id": agent_id, "agent_type": "restaurant"},
            "payload": {
                "queue_number": queue_number,
                "position": position,
                "estimated_wait_minutes": wait_minutes
            }
        }
    
    @staticmethod
    def queue_update(agent_id: str, position: int, wait_minutes: int) -> dict:
        return {
            "message_type": MessageType.QUEUE_UPDATE.value,
            "sender": {"agent_id": agent_id, "agent_type": "restaurant"},
            "payload": {
                "position": position,
                "estimated_wait_minutes": wait_minutes
            }
        }
    
    @staticmethod
    def order_submit(agent_id: str, items: list, party_size: int, 
                     estimated_arrival: str) -> dict:
        return {
            "message_type": MessageType.ORDER_SUBMIT.value,
            "sender": {"agent_id": agent_id, "agent_type": "customer"},
            "payload": {
                "items": items,
                "party_size": party_size,
                "estimated_arrival": estimated_arrival
            }
        }
    
    @staticmethod
    def order_confirmation(agent_id: str, order_id: str, status: str,
                           queue_number: int, table_id: str, total: float) -> dict:
        return {
            "message_type": MessageType.ORDER_CONFIRMATION.value,
            "sender": {"agent_id": agent_id, "agent_type": "restaurant"},
            "payload": {
                "order_id": order_id,
                "status": status,
                "queue_number": queue_number,
                "table_id": table_id,
                "total_amount": total
            }
        }
    
    @staticmethod
    def order_status(agent_id: str, order_id: str, status: str) -> dict:
        return {
            "message_type": MessageType.ORDER_STATUS.value,
            "sender": {"agent_id": agent_id, "agent_type": "restaurant"},
            "payload": {
                "order_id": order_id,
                "status": status
            }
        }
    
    @staticmethod
    def error(agent_id: str, code: str, message: str) -> dict:
        return {
            "message_type": MessageType.ERROR.value,
            "sender": {"agent_id": agent_id},
            "payload": {
                "code": code,
                "message": message
            }
        }


# Example usage
def demo():
    """演示握手协议"""
    
    # Create restaurant identity
    restaurant_id = AgentIdentity(
        agent_id="rst_demo_001",
        agent_type="restaurant",
        capabilities=["menu", "queue", "ordering", "recommendations"]
    )
    
    # Create customer identity
    customer_id = AgentIdentity(
        agent_id="cust_123",
        agent_type="customer",
        capabilities=["preferences", "ordering", "payment"]
    )
    
    # Create protocol handlers
    restaurant_protocol = HandshakeProtocol(restaurant_id, "restaurant_secret")
    customer_protocol = HandshakeProtocol(customer_id, "customer_secret")
    
    # Customer sends discovery
    discovery = customer_protocol.create_discovery_message()
    print(f"Discovery message: {json.dumps(discovery, indent=2)}")
    
    # Restaurant responds
    discovery_response = {
        "message_type": "DISCOVERY_RESPONSE",
        "sender": restaurant_id.to_dict(),
        "timestamp": int(time.time()),
        "payload": {"status": "accepting"}
    }
    
    # Customer sends handshake request
    user_profile = {
        "dietary_restrictions": {"allergies": ["peanuts"]},
        "preferences": {"cuisines": ["chinese"]},
        "party_size": 4
    }
    handshake_req = customer_protocol.create_handshake_request(user_profile)
    print(f"\nHandshake request: {json.dumps(handshake_req, indent=2)}")
    
    # Restaurant responds with handshake
    restaurant_info = {
        "name": "Demo Restaurant",
        "cuisine": "Chinese",
        "rating": 4.5
    }
    current_status = {
        "queue_length": 10,
        "current_number": 45
    }
    handshake_resp = restaurant_protocol.create_handshake_response(
        restaurant_info, current_status, handshake_req.get("session_id")
    )
    print(f"\nHandshake response: {json.dumps(handshake_resp, indent=2)}")
    
    # Create secure channel
    channel = SecureChannel(
        session_id=handshake_req["session_id"],
        local_agent=customer_id,
        remote_agent=restaurant_id
    )
    print(f"\nSecure channel established: {channel.to_dict()}")


if __name__ == "__main__":
    demo()
