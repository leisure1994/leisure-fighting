#!/usr/bin/env python3
"""
Dining Assistant - Customer Mode Client
顾客模式客户端

Handles:
- Restaurant discovery via QR code
- Agent handshake with preference sharing
- Menu browsing and recommendations
- Order placement and modification
- Queue management
- Restaurant favorites and quick reorder
"""

import asyncio
import json
import logging
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from dataclasses import dataclass, field
import websockets

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class SavedRestaurant:
    restaurant_id: str
    name: str
    notes: str = ""
    favorite_dishes: List[str] = field(default_factory=list)
    preferred_table: str = ""
    auto_order_template: Optional[Dict] = None
    added_at: datetime = field(default_factory=datetime.now)
    last_visited: Optional[datetime] = None


@dataclass
class DiningPreferences:
    allergies: List[str] = field(default_factory=list)
    intolerances: List[str] = field(default_factory=list)
    diet_type: str = "omnivore"  # vegetarian, vegan, omnivore, pescatarian
    cuisines: List[str] = field(default_factory=list)
    flavors: List[str] = field(default_factory=list)
    avoid_ingredients: List[str] = field(default_factory=list)
    spice_tolerance: str = "medium"  # none, low, medium, high
    
    # Meal time preferences
    meal_times: Dict[str, Dict] = field(default_factory=dict)
    
    # Party preferences
    default_party_size: int = 2
    has_children: bool = False
    has_elderly: bool = False


class CustomerAgent:
    """顾客模式Agent - 发现餐厅、下单、管理偏好"""
    
    def __init__(self, user_id: str, preferences: dict = None, config: dict = None):
        self.user_id = user_id
        self.agent_id = f"cust_{user_id}_{uuid.uuid4().hex[:8]}"
        self.config = config or {}
        
        # Preferences
        self.preferences = DiningPreferences()
        if preferences:
            self.set_preferences(preferences)
        
        # Saved restaurants
        self.saved_restaurants: Dict[str, SavedRestaurant] = {}
        
        # Current connection
        self.websocket: Optional[websockets.WebSocketClientProtocol] = None
        self.connected_restaurant: Optional[str] = None
        self.restaurant_info: Optional[Dict] = None
        self.current_queue: Optional[Dict] = None
        self.current_order: Optional[Dict] = None
        
        # Event handlers
        self.event_handlers: Dict[str, List[callable]] = {
            "connected": [],
            "recommendations_received": [],
            "order_confirmed": [],
            "queue_update": [],
            "table_ready": [],
            "order_ready": []
        }
        
        # Message listener task
        self.listener_task: Optional[asyncio.Task] = None
        
        logger.info(f"CustomerAgent initialized: {self.agent_id}")
    
    def set_preferences(self, preferences: dict):
        """设置用餐偏好"""
        if "allergies" in preferences:
            self.preferences.allergies = preferences["allergies"]
        if "favorites" in preferences:
            self.preferences.cuisines = preferences.get("cuisines", [])
            self.preferences.flavors = preferences.get("flavors", [])
        if "avoid" in preferences:
            self.preferences.avoid_ingredients = preferences["avoid"]
        if "spice_tolerance" in preferences:
            self.preferences.spice_tolerance = preferences["spice_tolerance"]
        if "meal_times" in preferences:
            self.preferences.meal_times = preferences["meal_times"]
        if "party_size" in preferences:
            self.preferences.default_party_size = preferences["party_size"]
        
        logger.info(f"Preferences updated for {self.user_id}")
    
    def get_user_profile(self, party_size: int = None, occasion: str = None) -> dict:
        """获取用户档案用于握手"""
        return {
            "dietary_restrictions": {
                "allergies": self.preferences.allergies,
                "intolerances": self.preferences.intolerances,
                "diet_type": self.preferences.diet_type
            },
            "preferences": {
                "cuisines": self.preferences.cuisines,
                "flavors": self.preferences.flavors,
                "avoid_ingredients": self.preferences.avoid_ingredients,
                "spice_tolerance": self.preferences.spice_tolerance
            },
            "meal_time_preferences": self.preferences.meal_times,
            "party_composition": {
                "size": party_size or self.preferences.default_party_size,
                "has_children": self.preferences.has_children,
                "has_elderly": self.preferences.has_elderly
            },
            "occasion": occasion or "casual"
        }
    
    async def connect_to_restaurant(self, qr_code_or_url: str) -> bool:
        """通过QR码连接到餐厅"""
        # Parse QR code/URL
        restaurant_info = self._parse_qr_code(qr_code_or_url)
        if not restaurant_info:
            logger.error(f"Invalid QR code: {qr_code_or_url}")
            return False
        
        restaurant_id = restaurant_info["restaurant_id"]
        ws_url = f"ws://localhost:8080/ws"  # Simplified for demo
        
        try:
            # Connect WebSocket
            self.websocket = await websockets.connect(ws_url)
            
            # Send discovery
            await self._send_discovery()
            
            # Wait for discovery response
            response = await self._wait_for_message("DISCOVERY_RESPONSE", timeout=5)
            if not response:
                logger.error("No discovery response")
                await self.disconnect()
                return False
            
            # Perform handshake
            await self._perform_handshake(restaurant_id)
            
            # Start message listener
            self.listener_task = asyncio.create_task(self._message_listener())
            
            self.connected_restaurant = restaurant_id
            logger.info(f"Connected to restaurant: {restaurant_id}")
            
            self._trigger_event("connected", {"restaurant_id": restaurant_id})
            return True
            
        except Exception as e:
            logger.error(f"Connection failed: {e}")
            await self.disconnect()
            return False
    
    def _parse_qr_code(self, qr_data: str) -> Optional[Dict]:
        """解析QR码数据"""
        # Expected formats:
        # https://dining.openclaw.ai/r/{restaurant_id}
        # https://dining.openclaw.ai/r/{restaurant_id}/t/{table_id}
        
        try:
            if qr_data.startswith("http"):
                parts = qr_data.split("/")
                restaurant_id = parts[-1] if "t" not in parts else parts[-3]
                table_id = parts[-1] if "t" in parts else None
                return {
                    "restaurant_id": restaurant_id,
                    "table_id": table_id
                }
            else:
                # Assume direct ID
                return {"restaurant_id": qr_data}
        except Exception:
            return None
    
    async def _send_discovery(self):
        """发送发现消息"""
        message = {
            "message_type": "DISCOVERY",
            "sender": {
                "agent_id": self.agent_id,
                "agent_type": "customer",
                "capabilities": ["preferences", "ordering", "payment"]
            },
            "timestamp": datetime.now().isoformat()
        }
        await self.websocket.send(json.dumps(message))
    
    async def _perform_handshake(self, restaurant_id: str):
        """执行握手协议"""
        message = {
            "message_type": "HANDSHAKE_REQUEST",
            "sender": {
                "agent_id": self.agent_id,
                "agent_type": "customer"
            },
            "payload": {
                "user_profile": self.get_user_profile()
            },
            "timestamp": datetime.now().isoformat()
        }
        await self.websocket.send(json.dumps(message))
        
        # Wait for handshake response
        response = await self._wait_for_message("HANDSHAKE_RESPONSE", timeout=10)
        if response:
            self.restaurant_info = response.get("payload", {})
            logger.info("Handshake completed")
    
    async def get_menu(self) -> List[Dict]:
        """获取菜单"""
        if not self.websocket:
            logger.error("Not connected to restaurant")
            return []
        
        message = {
            "message_type": "MENU_REQUEST",
            "sender": {
                "agent_id": self.agent_id,
                "agent_type": "customer"
            }
        }
        await self.websocket.send(json.dumps(message))
        
        response = await self._wait_for_message("MENU_RESPONSE", timeout=10)
        if response:
            return response.get("payload", {}).get("dishes", [])
        return []
    
    async def get_recommendations(self, party_size: int = None, occasion: str = None) -> Dict:
        """获取个性化推荐"""
        if not self.websocket:
            logger.error("Not connected to restaurant")
            return {}
        
        message = {
            "message_type": "RECOMMENDATION_REQUEST",
            "sender": {
                "agent_id": self.agent_id,
                "agent_type": "customer"
            },
            "payload": {
                "user_profile": self.get_user_profile(party_size, occasion)
            }
        }
        await self.websocket.send(json.dumps(message))
        
        response = await self._wait_for_message("RECOMMENDATION_RESPONSE", timeout=10)
        if response:
            recommendations = response.get("payload", {})
            self._trigger_event("recommendations_received", recommendations)
            return recommendations
        return {}
    
    async def submit_order(self, items: List[Dict], party_size: int = None, 
                          estimated_arrival: str = None) -> Optional[Dict]:
        """提交订单"""
        if not self.websocket:
            logger.error("Not connected to restaurant")
            return None
        
        message = {
            "message_type": "ORDER_SUBMIT",
            "sender": {
                "agent_id": self.agent_id,
                "agent_type": "customer"
            },
            "payload": {
                "items": items,
                "party_size": party_size or self.preferences.default_party_size,
                "estimated_arrival": estimated_arrival or datetime.now().isoformat()
            }
        }
        await self.websocket.send(json.dumps(message))
        
        response = await self._wait_for_message("ORDER_CONFIRMATION", timeout=10)
        if response:
            order_data = response.get("payload", {})
            self.current_order = order_data
            self._trigger_event("order_confirmed", order_data)
            logger.info(f"Order confirmed: {order_data.get('order_id')}")
            return order_data
        return None
    
    async def join_queue(self, party_size: int = None) -> Optional[Dict]:
        """加入队列"""
        if not self.websocket:
            logger.error("Not connected to restaurant")
            return None
        
        size = party_size or self.preferences.default_party_size
        pre_order = self.current_order.get("items") if self.current_order else None
        
        message = {
            "message_type": "QUEUE_JOIN",
            "sender": {
                "agent_id": self.agent_id,
                "agent_type": "customer"
            },
            "payload": {
                "party_size": size,
                "pre_order": pre_order,
                "estimated_arrival": (datetime.now() + timedelta(minutes=30)).isoformat()
            }
        }
        await self.websocket.send(json.dumps(message))
        
        response = await self._wait_for_message("QUEUE_CONFIRMATION", timeout=10)
        if response:
            queue_data = response.get("payload", {})
            self.current_queue = queue_data
            logger.info(f"Joined queue: #{queue_data.get('queue_number')}")
            return queue_data
        return None
    
    def save_restaurant(self, notes: str = ""):
        """保存当前餐厅到收藏"""
        if not self.restaurant_info:
            return
        
        info = self.restaurant_info.get("restaurant_info", {})
        restaurant_id = self.connected_restaurant
        
        saved = SavedRestaurant(
            restaurant_id=restaurant_id,
            name=info.get("name", "Unknown"),
            notes=notes,
            last_visited=datetime.now()
        )
        
        self.saved_restaurants[restaurant_id] = saved
        logger.info(f"Restaurant saved: {saved.name}")
    
    def quick_order_from_saved(self, restaurant_id: str, 
                               party_size: int = None) -> Optional[Dict]:
        """从收藏的餐厅快速下单"""
        if restaurant_id not in self.saved_restaurants:
            logger.error(f"Restaurant not saved: {restaurant_id}")
            return None
        
        saved = self.saved_restaurants[restaurant_id]
        
        if saved.auto_order_template:
            # Use template
            template = saved.auto_order_template
            return {
                "restaurant_id": restaurant_id,
                "items": template.get("items", []),
                "party_size": party_size or template.get("party_size", 2)
            }
        
        # Return favorite dishes
        return {
            "restaurant_id": restaurant_id,
            "favorite_dishes": saved.favorite_dishes,
            "party_size": party_size or self.preferences.default_party_size
        }
    
    async def disconnect(self):
        """断开连接"""
        if self.listener_task:
            self.listener_task.cancel()
            try:
                await self.listener_task
            except asyncio.CancelledError:
                pass
        
        if self.websocket:
            await self.websocket.close()
            self.websocket = None
        
        self.connected_restaurant = None
        self.restaurant_info = None
        logger.info("Disconnected from restaurant")
    
    async def _message_listener(self):
        """监听服务器消息"""
        try:
            async for message in self.websocket:
                await self._handle_message(message)
        except websockets.exceptions.ConnectionClosed:
            logger.info("Connection closed by server")
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Listener error: {e}")
    
    async def _handle_message(self, message: str):
        """处理收到的消息"""
        try:
            data = json.loads(message)
            msg_type = data.get("message_type")
            payload = data.get("payload", {})
            
            logger.info(f"Received: {msg_type}")
            
            if msg_type == "QUEUE_UPDATE":
                self.current_queue = payload
                self._trigger_event("queue_update", payload)
            
            elif msg_type == "ORDER_STATUS":
                if payload.get("status") == "ready":
                    self._trigger_event("order_ready", payload)
                # Update current order
                if self.current_order and self.current_order.get("order_id") == payload.get("order_id"):
                    self.current_order["status"] = payload.get("status")
            
            elif msg_type == "TABLE_READY":
                self._trigger_event("table_ready", payload)
            
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON: {message}")
    
    async def _wait_for_message(self, message_type: str, timeout: int = 10) -> Optional[Dict]:
        """等待特定类型的消息"""
        try:
            async with asyncio.timeout(timeout):
                async for message in self.websocket:
                    try:
                        data = json.loads(message)
                        if data.get("message_type") == message_type:
                            return data
                    except json.JSONDecodeError:
                        continue
        except asyncio.TimeoutError:
            logger.warning(f"Timeout waiting for {message_type}")
            return None
    
    def on(self, event: str, handler: callable):
        """注册事件处理器"""
        if event in self.event_handlers:
            self.event_handlers[event].append(handler)
    
    def _trigger_event(self, event: str, data: dict):
        """触发事件"""
        for handler in self.event_handlers.get(event, []):
            try:
                handler(data)
            except Exception as e:
                logger.error(f"Event handler error: {e}")
    
    def get_queue_status(self) -> Optional[Dict]:
        """获取当前队列状态"""
        return self.current_queue
    
    def get_order_status(self) -> Optional[Dict]:
        """获取当前订单状态"""
        return self.current_order


# Example usage
async def demo():
    """演示用法"""
    # Create customer agent
    customer = CustomerAgent(
        user_id="demo_user",
        preferences={
            "allergies": ["peanuts"],
            "cuisines": ["chinese", "japanese"],
            "flavors": ["spicy", "savory"],
            "spice_tolerance": "high",
            "party_size": 4
        }
    )
    
    # Event handlers
    def on_connected(data):
        print(f"Connected to restaurant: {data}")
    
    def on_recommendations(data):
        print(f"Got recommendations: {len(data.get('recommendations', []))} dishes")
    
    def on_order_confirmed(data):
        print(f"Order confirmed: {data.get('order_id')}")
    
    customer.on("connected", on_connected)
    customer.on("recommendations_received", on_recommendations)
    customer.on("order_confirmed", on_order_confirmed)
    
    # Connect to restaurant
    connected = await customer.connect_to_restaurant("rst_demo_001")
    if connected:
        # Get recommendations
        recommendations = await customer.get_recommendations(party_size=4)
        
        # Select top 3 recommendations
        top_dishes = [
            {"dish_id": r["dish_id"], "quantity": 1}
            for r in recommendations.get("recommendations", [])[:3]
        ]
        
        # Submit order
        order = await customer.submit_order(
            items=top_dishes,
            party_size=4,
            estimated_arrival=(datetime.now() + timedelta(minutes=30)).isoformat()
        )
        
        if order:
            # Join queue
            queue_info = await customer.join_queue(party_size=4)
            print(f"Queue number: {queue_info.get('queue_number')}")
        
        # Save restaurant
        customer.save_restaurant(notes="Great for family dinners")
        
        # Keep connection alive for a while
        await asyncio.sleep(60)
        
        # Disconnect
        await customer.disconnect()


if __name__ == "__main__":
    asyncio.run(demo())
