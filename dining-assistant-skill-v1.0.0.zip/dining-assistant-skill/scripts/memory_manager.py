#!/usr/bin/env python3
"""
Dining Assistant - Memory Manager (mempalace-style)
长效记忆管理器 - 基于 mempalace 架构

为餐厅和顾客 Agent 提供:
- 四层记忆强度 (L1瞬时→L4核心)
- 自动巩固与遗忘
- 智能检索与联想
- 云端同步与共享
"""

import json
import hashlib
import os
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from enum import Enum

# 尝试导入aiohttp，如果不存在则使用模拟实现
try:
    import aiohttp
    HAS_AIOHTTP = True
except ImportError:
    HAS_AIOHTTP = False
    print("Warning: aiohttp not available, using mock cloud sync")


class MemoryLevel(Enum):
    """记忆强度等级"""
    L1_TRANSIENT = 1  # 瞬时记忆 - 24小时遗忘
    L2_WORKING = 2    # 工作记忆 - 7天降级
    L3_LONG_TERM = 3  # 长期记忆 - 持久存储
    L4_CORE = 4       # 核心记忆 - 几乎不遗忘


@dataclass
class MemoryEngram:
    """记忆印迹"""
    id: str
    timestamp: datetime
    content: dict
    memory_type: str  # "fact", "episodic", "procedural", "semantic"
    level: MemoryLevel = MemoryLevel.L1_TRANSIENT
    reinforcement_count: int = 1
    last_accessed: datetime = field(default_factory=datetime.now)
    emotional_valence: float = 0.0  # -1.0 to 1.0
    associations: List[str] = field(default_factory=list)
    source: str = "observation"  # "explicit", "inferred", "shared"
    
    def reinforce(self):
        """强化记忆"""
        self.reinforcement_count += 1
        self.last_accessed = datetime.now()
        
        # 升级记忆等级
        if self.reinforcement_count >= 8:
            self.level = MemoryLevel.L4_CORE
        elif self.reinforcement_count >= 4:
            self.level = MemoryLevel.L3_LONG_TERM
        elif self.reinforcement_count >= 2:
            self.level = MemoryLevel.L2_WORKING
    
    def decay(self) -> bool:
        """
        记忆衰减检查
        返回: True = 已遗忘, False = 仍保留
        """
        age = datetime.now() - self.timestamp
        
        if self.level == MemoryLevel.L1_TRANSIENT:
            return age > timedelta(hours=24)
        elif self.level == MemoryLevel.L2_WORKING:
            # 检查最后访问时间
            since_last_access = datetime.now() - self.last_accessed
            return since_last_access > timedelta(days=7)
        elif self.level == MemoryLevel.L3_LONG_TERM:
            # 长期记忆90天不访问降级
            since_last_access = datetime.now() - self.last_accessed
            return since_last_access > timedelta(days=90)
        
        # L4_CORE 不衰减
        return False
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "timestamp": self.timestamp.isoformat(),
            "content": self.content,
            "memory_type": self.memory_type,
            "level": self.level.value,
            "reinforcement_count": self.reinforcement_count,
            "last_accessed": self.last_accessed.isoformat(),
            "emotional_valence": self.emotional_valence,
            "associations": self.associations,
            "source": self.source
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "MemoryEngram":
        return cls(
            id=data["id"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            content=data["content"],
            memory_type=data["memory_type"],
            level=MemoryLevel(data["level"]),
            reinforcement_count=data["reinforcement_count"],
            last_accessed=datetime.fromisoformat(data["last_accessed"]),
            emotional_valence=data["emotional_valence"],
            associations=data["associations"],
            source=data["source"]
        )


class CloudMemorySync:
    """
    云端记忆同步器
    支持评价上传、信用查询、餐厅档案同步
    """
    
    def __init__(self, base_url: str = "https://api.dining.openclaw.ai"):
        self.base_url = base_url
        self.session: Optional[Any] = None
    
    async def __aenter__(self):
        if HAS_AIOHTTP:
            self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if HAS_AIOHTTP and self.session:
            await self.session.close()
    
    # ========== 顾客端API ==========
    
    async def fetch_restaurant_reviews(
        self, 
        restaurant_id: str,
        customer_profile: Optional[dict] = None,
        limit: int = 20
    ) -> dict:
        """获取餐厅评价，支持口味相似度匹配"""
        if not HAS_AIOHTTP:
            # 模拟数据
            return {
                "aggregate": {
                    "overall": 4.6,
                    "total_reviews": 1280,
                    "breakdown": {
                        "food_quality": 4.8,
                        "service": 4.2,
                        "atmosphere": 4.4,
                        "value": 4.0
                    }
                },
                "reviews": [
                    {
                        "id": "rev_001",
                        "rating": 5,
                        "summary": "水煮鱼必点！辣度刚好，鱼肉新鲜",
                        "similarity_to_you": 0.92,
                        "verified": True,
                        "helpful": 45
                    },
                    {
                        "id": "rev_002", 
                        "rating": 4,
                        "summary": "口味正宗，但周末等位要30分钟",
                        "similarity_to_you": 0.78,
                        "verified": True,
                        "helpful": 32
                    }
                ],
                "keywords": {
                    "positive": ["口味正宗", "分量大", "服务热情"],
                    "negative": ["等位久", "环境嘈杂"]
                }
            }
        
        # 实际API调用
        params = {
            "verified_only": "true",
            "limit": limit,
            "sort": "helpful_desc"
        }
        
        if customer_profile:
            params["preference_match"] = self._hash_profile(customer_profile)
        
        async with self.session.get(
            f"{self.base_url}/v1/restaurants/{restaurant_id}/reviews",
            params=params
        ) as resp:
            if resp.status == 200:
                return await resp.json()
            return {"error": f"Failed to fetch reviews: {resp.status}"}
    
    async def submit_review(
        self,
        restaurant_id: str,
        visit_id: str,
        ratings: dict,
        text: str,
        customer_id: str,
        anonymous: bool = False
    ) -> dict:
        """提交用餐评价到云端"""
        if not HAS_AIOHTTP:
            return {"status": "submitted", "review_id": "mock_rev_001"}
        
        payload = {
            "restaurant_id": restaurant_id,
            "visit_id": visit_id,
            "customer_id": customer_id,
            "ratings": ratings,
            "text": text,
            "anonymous": anonymous,
            "submitted_at": datetime.now().isoformat()
        }
        
        async with self.session.post(
            f"{self.base_url}/v1/reviews",
            json=payload
        ) as resp:
            if resp.status == 201:
                return await resp.json()
            return {"error": f"Failed to submit review: {resp.status}"}
    
    async def get_my_reviews(self, customer_id: str) -> List[dict]:
        """获取顾客自己发布过的所有评价"""
        if not HAS_AIOHTTP:
            return []
        
        async with self.session.get(
            f"{self.base_url}/v1/customers/{customer_id}/reviews"
        ) as resp:
            if resp.status == 200:
                return await resp.json()
            return []
    
    # ========== 餐厅端API ==========
    
    async def query_customer_credit(
        self,
        customer_id: str,
        restaurant_id: str,
        consent_token: str
    ) -> dict:
        """查询顾客信用评分 (需顾客授权)"""
        if not HAS_AIOHTTP:
            # 模拟数据
            return {
                "credit_score": 850,
                "risk_level": "low",
                "completed_orders": 45,
                "disputed_orders": 1,
                "warnings": [],
                "recommendation": "优质顾客，可放心接待"
            }
        
        async with self.session.get(
            f"{self.base_url}/v1/customers/{customer_id}/credit",
            headers={"Authorization": f"Bearer {consent_token}"},
            params={"requester": restaurant_id}
        ) as resp:
            if resp.status == 200:
                return await resp.json()
            elif resp.status == 403:
                return {"error": "Customer has not authorized credit check"}
            return {"error": f"Failed: {resp.status}"}
    
    async def get_regular_customer_profile(
        self,
        restaurant_id: str,
        customer_id: str
    ) -> dict:
        """获取常客档案 (仅限本店顾客)"""
        if not HAS_AIOHTTP:
            return {"error": "Customer not found or no visit history"}
        
        async with self.session.get(
            f"{self.base_url}/v1/restaurants/{restaurant_id}/customers/{customer_id}/profile"
        ) as resp:
            if resp.status == 200:
                return await resp.json()
            return {"error": "Customer not found or no visit history"}
    
    async def report_blackmark(
        self,
        restaurant_id: str,
        customer_id: str,
        incident_type: str,
        evidence: dict
    ) -> dict:
        """举报顾客不良行为 (逃单/恶意投诉等)"""
        if not HAS_AIOHTTP:
            return {"status": "reported", "review_id": "mock_bm_001"}
        
        payload = {
            "restaurant_id": restaurant_id,
            "customer_id": customer_id,
            "type": incident_type,
            "evidence": evidence,
            "reported_at": datetime.now().isoformat(),
            "status": "pending_review"
        }
        
        async with self.session.post(
            f"{self.base_url}/v1/blackmarks",
            json=payload
        ) as resp:
            if resp.status == 201:
                return {"status": "reported", "review_id": (await resp.json()).get("id")}
            return {"error": f"Failed to report: {resp.status}"}
    
    async def request_customer_consent(
        self,
        customer_id: str,
        restaurant_id: str,
        purpose: str
    ) -> dict:
        """向顾客请求授权 (查询信用/历史订单)"""
        if not HAS_AIOHTTP:
            return {"status": "request_sent", "expires_in": "24h"}
        
        payload = {
            "customer_id": customer_id,
            "requester": restaurant_id,
            "purpose": purpose,
            "requested_at": datetime.now().isoformat()
        }
        
        async with self.session.post(
            f"{self.base_url}/v1/consent-requests",
            json=payload
        ) as resp:
            if resp.status == 202:
                return {"status": "request_sent", "expires_in": "24h"}
            return {"error": f"Failed: {resp.status}"}
    
    # 内部方法
    
    def _hash_profile(self, profile: dict) -> str:
        """生成画像哈希 (用于相似度匹配，不泄露隐私)"""
        features = {
            "cuisines": sorted(profile.get("favorite_cuisines", [])),
            "spice": profile.get("spice_tolerance", "unknown"),
            "price_min": profile.get("price_comfort_zone", {}).get("min", 0),
            "price_max": profile.get("price_comfort_zone", {}).get("max", 200)
        }
        return hashlib.sha256(json.dumps(features, sort_keys=True).encode()).hexdigest()[:16]


class MemoryConsolidation:
    """记忆巩固器"""
    
    def __init__(self, memory_store: "DiningMemory"):
        self.memory_store = memory_store
    
    def consolidate_episode(self, episode: dict) -> List[MemoryEngram]:
        """将用餐经历巩固为多个记忆印迹"""
        engrams = []
        
        # 1. 事实记忆 - 订单详情
        for item in episode.get("order", []):
            engram = MemoryEngram(
                id=self._generate_id(f"order_{episode['customer_id']}_{item['dish_id']}_{episode['date']}"),
                timestamp=datetime.fromisoformat(episode["date"]),
                content={
                    "type": "dish_ordered",
                    "dish_id": item["dish_id"],
                    "dish_name": item["name"],
                    "price": item["price"],
                    "quantity": item["quantity"]
                },
                memory_type="fact",
                emotional_valence=episode.get("satisfaction", 0),
                associations=[episode["customer_id"], item["dish_id"], episode["restaurant_id"]]
            )
            engrams.append(engram)
        
        # 2. 情景记忆 - 整体用餐体验
        if episode.get("special_notes"):
            engram = MemoryEngram(
                id=self._generate_id(f"experience_{episode['customer_id']}_{episode['restaurant_id']}_{episode['date']}"),
                timestamp=datetime.fromisoformat(episode["date"]),
                content={
                    "type": "dining_experience",
                    "occasion": episode.get("special_notes"),
                    "satisfaction": episode.get("satisfaction"),
                    "party_size": episode.get("party_size", 1),
                    "total_amount": episode.get("total_amount")
                },
                memory_type="episodic",
                emotional_valence=episode.get("satisfaction", 0),
                associations=[episode["customer_id"], episode["restaurant_id"], "special_occasion"]
            )
            engrams.append(engram)
        
        # 3. 语义记忆 - 偏好推断
        if episode.get("satisfaction", 0) > 0.8:
            for item in episode.get("order", [])[:3]:
                engram = MemoryEngram(
                    id=self._generate_id(f"preference_{episode['customer_id']}_{item['dish_id']}"),
                    timestamp=datetime.fromisoformat(episode["date"]),
                    content={
                        "type": "preference_inferred",
                        "dish_id": item["dish_id"],
                        "dish_name": item["name"],
                        "preference": "positive",
                        "confidence": episode["satisfaction"]
                    },
                    memory_type="semantic",
                    emotional_valence=episode["satisfaction"],
                    associations=[episode["customer_id"], item["dish_id"], "preference"],
                    source="inferred"
                )
                engrams.append(engram)
        
        return engrams
    
    def _generate_id(self, seed: str) -> str:
        """生成记忆ID"""
        return hashlib.sha256(seed.encode()).hexdigest()[:16]


class DiningMemory:
    """用餐记忆管理器"""
    
    def __init__(self, agent_id: str, agent_type: str, memory_dir: str = "./memory"):
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.memory_dir = f"{memory_dir}/{agent_type}/{agent_id}"
        
        self.l1_cache: Dict[str, MemoryEngram] = {}
        self.l2_cache: Dict[str, MemoryEngram] = {}
        self.l3_storage: str = f"{self.memory_dir}/long_term"
        self.l4_storage: str = f"{self.memory_dir}/core"
        
        self.cloud = CloudMemorySync()
        self.consolidator = MemoryConsolidation(self)
        
        os.makedirs(self.l3_storage, exist_ok=True)
        os.makedirs(self.l4_storage, exist_ok=True)
        
        self._load_persistent_memories()
    
    def encode(self, event: dict) -> List[MemoryEngram]:
        """编码事件为记忆印迹"""
        if event.get("type") == "dining_episode":
            engrams = self.consolidator.consolidate_episode(event)
            for engram in engrams:
                self.store(engram)
            return engrams
        
        engram = MemoryEngram(
            id=self._generate_id(json.dumps(event, sort_keys=True)),
            timestamp=datetime.now(),
            content=event,
            memory_type=event.get("memory_type", "fact")
        )
        self.store(engram)
        return [engram]
    
    def store(self, engram: MemoryEngram):
        """存储记忆印迹"""
        if engram.level == MemoryLevel.L1_TRANSIENT:
            self.l1_cache[engram.id] = engram
        elif engram.level == MemoryLevel.L2_WORKING:
            self.l2_cache[engram.id] = engram
        elif engram.level == MemoryLevel.L3_LONG_TERM:
            self._save_to_file(engram, self.l3_storage)
        elif engram.level == MemoryLevel.L4_CORE:
            self._save_to_file(engram, self.l4_storage)
    
    def retrieve(self, query: dict) -> List[MemoryEngram]:
        """检索记忆"""
        results = []
        results.extend(self._search_cache(self.l1_cache, query))
        results.extend(self._search_cache(self.l2_cache, query))
        results.extend(self._search_files(self.l3_storage, query))
        results.extend(self._search_files(self.l4_storage, query))
        
        for r in results:
            r.last_accessed = datetime.now()
        
        results.sort(key=lambda x: (x.reinforcement_count, x.timestamp), reverse=True)
        return results
    
    def reinforce(self, memory_id: str):
        """强化特定记忆"""
        if memory_id in self.l1_cache:
            self.l1_cache[memory_id].reinforce()
            if self.l1_cache[memory_id].level == MemoryLevel.L2_WORKING:
                self.l2_cache[memory_id] = self.l1_cache.pop(memory_id)
        
        elif memory_id in self.l2_cache:
            self.l2_cache[memory_id].reinforce()
            if self.l2_cache[memory_id].level == MemoryLevel.L3_LONG_TERM:
                self._save_to_file(self.l2_cache.pop(memory_id), self.l3_storage)
        
        else:
            for storage in [self.l3_storage, self.l4_storage]:
                filepath = f"{storage}/{memory_id}.json"
                if os.path.exists(filepath):
                    with open(filepath, 'r') as f:
                        engram = MemoryEngram.from_dict(json.load(f))
                    engram.reinforce()
                    self._save_to_file(engram, storage)
                    break
    
    def forget(self, memory_id: str):
        """主动遗忘"""
        self.l1_cache.pop(memory_id, None)
        self.l2_cache.pop(memory_id, None)
        
        for storage in [self.l3_storage, self.l4_storage]:
            filepath = f"{storage}/{memory_id}.json"
            if os.path.exists(filepath):
                os.remove(filepath)
    
    def decay_check(self):
        """记忆衰减检查"""
        to_remove = []
        for mid, engram in self.l1_cache.items():
            if engram.decay():
                to_remove.append(mid)
        for mid in to_remove:
            del self.l1_cache[mid]
        
        to_downgrade = []
        for mid, engram in self.l2_cache.items():
            if engram.decay():
                if engram.reinforcement_count >= 2:
                    engram.level = MemoryLevel.L1_TRANSIENT
                    self.l1_cache[mid] = engram
                to_downgrade.append(mid)
        for mid in to_downgrade:
            del self.l2_cache[mid]
    
    def generate_insights(self) -> dict:
        """生成记忆洞察"""
        all_memories = []
        all_memories.extend(self.l1_cache.values())
        all_memories.extend(self.l2_cache.values())
        all_memories.extend(self._load_all_from_dir(self.l3_storage))
        all_memories.extend(self._load_all_from_dir(self.l4_storage))
        
        insights = {
            "total_memories": len(all_memories),
            "by_level": {
                "L1": len(self.l1_cache),
                "L2": len(self.l2_cache),
                "L3": len(os.listdir(self.l3_storage)) if os.path.exists(self.l3_storage) else 0,
                "L4": len(os.listdir(self.l4_storage)) if os.path.exists(self.l4_storage) else 0
            },
            "by_type": {},
            "strongest_associations": [],
            "emotional_summary": {"positive": 0, "neutral": 0, "negative": 0}
        }
        
        for m in all_memories:
            insights["by_type"][m.memory_type] = insights["by_type"].get(m.memory_type, 0) + 1
            
            if m.emotional_valence > 0.3:
                insights["emotional_summary"]["positive"] += 1
            elif m.emotional_valence < -0.3:
                insights["emotional_summary"]["negative"] += 1
            else:
                insights["emotional_summary"]["neutral"] += 1
        
        assoc_counts = {}
        for m in all_memories:
            for assoc in m.associations:
                assoc_counts[assoc] = assoc_counts.get(assoc, 0) + 1
        insights["strongest_associations"] = sorted(
            assoc_counts.items(), 
            key=lambda x: x[1], 
            reverse=True
        )[:10]
        
        return insights
    
    def export_profile(self) -> dict:
        """导出用户/餐厅画像"""
        insights = self.generate_insights()
        core_memories = self.retrieve({"by_level": MemoryLevel.L4_CORE})
        
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "memory_stats": insights,
            "core_memories": [m.to_dict() for m in core_memories[:20]],
            "generated_at": datetime.now().isoformat()
        }
    
    # 内部方法
    
    def _generate_id(self, seed: str) -> str:
        return hashlib.sha256(seed.encode()).hexdigest()[:16]
    
    def _save_to_file(self, engram: MemoryEngram, directory: str):
        filepath = f"{directory}/{engram.id}.json"
        with open(filepath, 'w') as f:
            json.dump(engram.to_dict(), f, indent=2, ensure_ascii=False)
    
    def _search_cache(self, cache: Dict[str, MemoryEngram], query: dict) -> List[MemoryEngram]:
        return [engram for engram in cache.values() if self._matches_query(engram, query)]
    
    def _search_files(self, directory: str, query: dict) -> List[MemoryEngram]:
        results = []
        if not os.path.exists(directory):
            return results
        
        for filename in os.listdir(directory):
            if not filename.endswith('.json'):
                continue
            
            try:
                with open(f"{directory}/{filename}", 'r') as f:
                    engram = MemoryEngram.from_dict(json.load(f))
                
                if self._matches_query(engram, query):
                    results.append(engram)
            except:
                continue
        
        return results
    
    def _matches_query(self, engram: MemoryEngram, query: dict) -> bool:
        if "by_associations" in query:
            if not any(a in engram.associations for a in query["by_associations"]):
                return False
        
        if "by_type" in query:
            if engram.memory_type != query["by_type"]:
                return False
        
        if "by_time_range" in query:
            start, end = query["by_time_range"]
            if not (start <= engram.timestamp <= end):
                return False
        
        if "by_emotion" in query:
            if query["by_emotion"] == "positive" and engram.emotional_valence <= 0.3:
                return False
            if query["by_emotion"] == "negative" and engram.emotional_valence >= -0.3:
                return False
        
        return True
    
    def _load_persistent_memories(self):
        pass
    
    def _load_all_from_dir(self, directory: str) -> List[MemoryEngram]:
        memories = []
        if not os.path.exists(directory):
            return memories
        
        for filename in os.listdir(directory):
            if not filename.endswith('.json'):
                continue
            
            try:
                with open(f"{directory}/{filename}", 'r') as f:
                    memories.append(MemoryEngram.from_dict(json.load(f)))
            except:
                continue
        
        return memories


# 餐厅端专用记忆类
class RestaurantMemory(DiningMemory):
    """餐厅记忆管理器"""
    
    def __init__(self, restaurant_id: str, memory_dir: str = "./memory"):
        super().__init__(restaurant_id, "restaurant", memory_dir)
        self.restaurant_id = restaurant_id
    
    def record_customer_visit(self, customer_id: str, visit_data: dict):
        """记录顾客到访"""
        event = {
            "type": "dining_episode",
            "customer_id": customer_id,
            "restaurant_id": self.restaurant_id,
            **visit_data
        }
        return self.encode(event)
    
    def get_customer_profile(self, customer_id: str) -> dict:
        """获取顾客档案"""
        memories = self.retrieve({"by_associations": [customer_id]})
        
        profile = {
            "customer_id": customer_id,
            "visit_count": 0,
            "favorite_dishes": [],
            "total_spent": 0,
            "last_visit": None,
            "preferences": {}
        }
        
        dish_counts = {}
        
        for m in memories:
            content = m.content
            
            if content.get("type") == "dish_ordered":
                dish_id = content.get("dish_id")
                dish_counts[dish_id] = dish_counts.get(dish_id, 0) + 1
                profile["total_spent"] += content.get("price", 0) * content.get("quantity", 1)
            
            if content.get("type") == "dining_experience":
                profile["visit_count"] += 1
                visit_date = m.timestamp
                if not profile["last_visit"] or visit_date > profile["last_visit"]:
                    profile["last_visit"] = visit_date
        
        sorted_dishes = sorted(dish_counts.items(), key=lambda x: x[1], reverse=True)
        profile["favorite_dishes"] = [d[0] for d in sorted_dishes[:5]]
        
        return profile
    
    async def check_customer_credit(self, customer_id: str, consent_token: str = None) -> dict:
        """查询顾客信用 (支持云端调取)"""
        local_profile = self.get_customer_profile(customer_id)
        
        if local_profile["visit_count"] >= 3:
            return {
                "source": "local",
                "credit_score": 800,
                "risk_level": "low",
                "visits": local_profile["visit_count"],
                "note": "常客，优先使用本地档案"
            }
        
        if consent_token:
            async with self.cloud as cloud:
                credit = await cloud.query_customer_credit(
                    customer_id, self.restaurant_id, consent_token
                )
                return {**credit, "source": "cloud"}
        
        return {
            "source": "none",
            "risk_level": "unknown",
            "note": "新顾客，建议正常接待或请求授权查信用"
        }
    
    def predict_inventory_needs(self, days_ahead: int = 1) -> dict:
        """预测备货需求"""
        predictions = {
            "date": (datetime.now() + timedelta(days=days_ahead)).isoformat(),
            "predicted_dishes": [],
            "confidence": 0.7
        }
        
        all_memories = self._load_all_from_dir(self.l4_storage)
        customer_dish_prefs = {}
        
        for m in all_memories:
            if m.content.get("type") == "dish_ordered":
                customer = None
                for assoc in m.associations:
                    if assoc.startswith("cust_"):
                        customer = assoc
                        break
                
                if customer:
                    dish_id = m.content.get("dish_id")
                    if customer not in customer_dish_prefs:
                        customer_dish_prefs[customer] = {}
                    customer_dish_prefs[customer][dish_id] = \
                        customer_dish_prefs[customer].get(dish_id, 0) + 1
        
        dish_totals = {}
        for customer_dishes in customer_dish_prefs.values():
            for dish, count in customer_dishes.items():
                dish_totals[dish] = dish_totals.get(dish, 0) + count
        
        sorted_dishes = sorted(dish_totals.items(), key=lambda x: x[1], reverse=True)
        predictions["predicted_dishes"] = [
            {"dish_id": d[0], "predicted_orders": d[1]} 
            for d in sorted_dishes[:10]
        ]
        
        return predictions
    
    async def request_review_after_meal(self, customer_id: str, visit_id: str):
        """用餐结束后自动请求评价"""
        return {
            "action": "request_review",
            "customer_id": customer_id,
            "visit_id": visit_id,
            "message": "用餐体验如何？给今天的菜打几分？"
        }


# 顾客端专用记忆类
class CustomerMemory(DiningMemory):
    """顾客记忆管理器"""
    
    def __init__(self, customer_id: str, memory_dir: str = "./memory"):
        super().__init__(customer_id, "customer", memory_dir)
        self.customer_id = customer_id
    
    def record_dining_experience(self, restaurant_id: str, experience: dict):
        """记录用餐体验"""
        event = {
            "type": "dining_episode",
            "customer_id": self.customer_id,
            "restaurant_id": restaurant_id,
            **experience
        }
        return self.encode(event)
    
    def get_taste_profile(self) -> dict:
        """获取口味画像"""
        memories = self.retrieve({"by_associations": [self.customer_id]})
        
        dish_counts = {}
        cuisine_counts = {}
        flavor_tags = {}
        
        for m in memories:
            content = m.content
            
            if content.get("type") == "dish_ordered":
                dish_id = content.get("dish_id")
                dish_name = content.get("dish_name")
                dish_counts[dish_name] = dish_counts.get(dish_name, 0) + 1
                
                for tag in content.get("tags", []):
                    flavor_tags[tag] = flavor_tags.get(tag, 0) + 1
            
            if content.get("type") == "dining_experience":
                cuisine = content.get("cuisine_type")
                if cuisine:
                    cuisine_counts[cuisine] = cuisine_counts.get(cuisine, 0) + 1
        
        favorite_dishes = sorted(dish_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        favorite_cuisines = sorted(cuisine_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        flavor_profile = sorted(flavor_tags.items(), key=lambda x: x[1], reverse=True)[:10]
        
        return {
            "favorite_dishes": favorite_dishes,
            "favorite_cuisines": favorite_cuisines,
            "flavor_profile": flavor_profile,
            "spice_tolerance": self._infer_spice_tolerance(flavor_tags),
            "price_comfort_zone": self._infer_price_range(memories)
        }
    
    async def get_restaurant_reviews_with_similarity(
        self, 
        restaurant_id: str,
        include_similar_users: bool = True
    ) -> dict:
        """获取餐厅评价，优先显示口味相似用户的评价"""
        my_profile = self.get_taste_profile()
        
        async with self.cloud as cloud:
            reviews_data = await cloud.fetch_restaurant_reviews(
                restaurant_id,
                customer_profile=my_profile if include_similar_users else None,
                limit=20
            )
        
        my_memories = self.retrieve({
            "by_associations": [restaurant_id],
            "by_type": "episodic"
        })
        
        return {
            "aggregate": reviews_data.get("aggregate", {}),
            "reviews": reviews_data.get("reviews", []),
            "my_history": [
                {
                    "date": m.timestamp.isoformat(),
                    "satisfaction": m.emotional_valence,
                    "notes": m.content.get("occasion", "")
                }
                for m in my_memories[:5]
            ],
            "recommendation": self._generate_advice(reviews_data, my_profile)
        }
    
    def _generate_advice(self, reviews_data: dict, my_profile: dict) -> str:
        """基于评价数据和我的口味生成建议"""
        aggregate = reviews_data.get("aggregate", {})
        overall = aggregate.get("overall", 0)
        
        if overall >= 4.5:
            return f"评分{overall}很高，而且和你口味相似的用户评价很好，值得一试"
        elif overall >= 4.0:
            return f"评分{overall}不错，注意近期有人提到等位较久"
        else:
            return f"评分{overall}一般，建议看看具体差评内容再决定"
    
    def get_dining_recommendations(self, context: dict) -> List[dict]:
        """基于记忆生成用餐推荐"""
        recommendations = []
        
        if context.get("mood") == "想吃辣的":
            spicy_memories = self.retrieve({
                "by_associations": ["spicy", "麻辣"],
                "by_emotion": "positive"
            })
            restaurants = set()
            for m in spicy_memories:
                for assoc in m.associations:
                    if assoc.startswith("rst_"):
                        restaurants.add(assoc)
            
            for rst in list(restaurants)[:5]:
                recommendations.append({
                    "type": "restaurant",
                    "id": rst,
                    "reason": "你在这里吃过好吃的辣菜",
                    "confidence": 0.85
                })
        
        if context.get("occasion") == "朋友聚餐":
            social_memories = self.retrieve({
                "by_type": "episodic",
                "by_associations": ["朋友聚餐"]
            })
            
            for m in sorted(social_memories, key=lambda x: x.emotional_valence, reverse=True)[:3]:
                rst = None
                for assoc in m.associations:
                    if assoc.startswith("rst_"):
                        rst = assoc
                        break
                
                if rst:
                    recommendations.append({
                        "type": "restaurant",
                        "id": rst,
                        "reason": f"上次{context['occasion']}体验很好",
                        "confidence": m.emotional_valence
                    })
        
        return recommendations
    
    def save_restaurant(self, restaurant_id: str, notes: str = "", 
                       auto_order: dict = None):
        """收藏餐厅"""
        engram = MemoryEngram(
            id=self._generate_id(f"saved_{self.customer_id}_{restaurant_id}"),
            timestamp=datetime.now(),
            content={
                "type": "saved_restaurant",
                "restaurant_id": restaurant_id,
                "notes": notes,
                "auto_order_template": auto_order
            },
            memory_type="semantic",
            level=MemoryLevel.L3_LONG_TERM,
            associations=[self.customer_id, restaurant_id, "saved"]
        )
        self.store(engram)
    
    async def submit_review_after_meal(
        self,
        restaurant_id: str,
        visit_id: str,
        ratings: dict,
        text: str,
        anonymous: bool = False
    ) -> dict:
        """用餐后提交评价到云端"""
        async with self.cloud as cloud:
            result = await cloud.submit_review(
                restaurant_id=restaurant_id,
                visit_id=visit_id,
                ratings=ratings,
                text=text,
                customer_id=self.customer_id,
                anonymous=anonymous
            )
        
        review_engram = MemoryEngram(
            id=self._generate_id(f"review_{visit_id}"),
            timestamp=datetime.now(),
            content={
                "type": "review_submitted",
                "restaurant_id": restaurant_id,
                "visit_id": visit_id,
                "ratings": ratings,
                "anonymous": anonymous,
                "cloud_synced": "error" not in result
            },
            memory_type="semantic",
            level=MemoryLevel.L3_LONG_TERM,
            associations=[self.customer_id, restaurant_id, "review"],
            emotional_valence=ratings.get("overall", 3) / 5 * 2 - 1
        )
        self.store(review_engram)
        
        return result
    
    def _infer_spice_tolerance(self, flavor_tags: dict) -> str:
        """推断辣度接受度"""
        spicy_count = flavor_tags.get("spicy", 0) + flavor_tags.get("辣", 0)
        total = sum(flavor_tags.values())
        
        if total == 0:
            return "unknown"
        
        ratio = spicy_count / total
        if ratio > 0.7:
            return "very_high"
        elif ratio > 0.4:
            return "high"
        elif ratio > 0.2:
            return "medium"
        else:
            return "low"
    
    def _infer_price_range(self, memories: List[MemoryEngram]) -> dict:
        """推断价格接受区间"""
        totals = []
        
        for m in memories:
            if m.content.get("type") == "dining_experience":
                total = m.content.get("total_amount")
                if total:
                    totals.append(total)
        
        if not totals:
            return {"min": 0, "max": 0, "avg": 0}
        
        return {
            "min": min(totals),
            "max": max(totals),
            "avg": sum(totals) / len(totals)
        }


# 云端演示
async def demo_cloud_memory():
    """演示云端记忆系统"""
    print("="*60)
    print("     ☁️  云端共享记忆系统演示")
    print("="*60)
    
    # 顾客查看餐厅评价
    print("\n【场景1】顾客调取餐厅评价")
    print("-" * 40)
    
    cust_memory = CustomerMemory("cust_zhang_001")
    
    reviews_data = await cust_memory.get_restaurant_reviews_with_similarity("rst_sichuan_001")
    
    print(f"   蜀香阁川菜馆")
    print(f"   综合评分: {reviews_data['aggregate']['overall']}/5")
    print(f"   评价数量: {reviews_data['aggregate']['total_reviews']}条")
    print()
    print(f"   口味相似用户的评价:")
    for r in reviews_data['reviews'][:2]:
        print(f"      ⭐{r['rating']}分 [{r['similarity_to_you']*100:.0f}%相似] {r['summary']}")
    
    print()
    print(f"   {reviews_data['recommendation']}")
    
    # 餐厅查询顾客信用
    print("\n【场景2】餐厅查询新顾客信用")
    print("-" * 40)
    
    rst_memory = RestaurantMemory("rst_sichuan_001")
    
    # 模拟常客
    rst_memory.record_customer_visit("cust_zhang_001", {
        "date": "2026-04-10T19:00:00",
        "order": [{"dish_id": "d_003", "name": "水煮鱼", "price": 88, "quantity": 1}],
        "satisfaction": 0.9,
        "total_amount": 196
    })
    rst_memory.record_customer_visit("cust_zhang_001", {
        "date": "2026-04-03T19:00:00",
        "order": [{"dish_id": "d_003", "name": "水煮鱼", "price": 88, "quantity": 1}],
        "satisfaction": 0.85,
        "total_amount": 150
    })
    rst_memory.record_customer_visit("cust_zhang_001", {
        "date": "2026-03-27T19:00:00",
        "order": [{"dish_id": "d_003", "name": "水煮鱼", "price": 88, "quantity": 1}],
        "satisfaction": 0.88,
        "total_amount": 180
    })
    
    local_credit = await rst_memory.check_customer_credit("cust_zhang_001")
    print(f"   顾客: cust_zhang_001 (常客)")
    print(f"   数据来源: {local_credit.get('source', 'unknown')}")
    if 'credit_score' in local_credit:
        print(f"   信用评分: {local_credit['credit_score']}/1000")
    print(f"   风险等级: {local_credit.get('risk_level', 'unknown')}")
    if 'visits' in local_credit:
        print(f"   到访次数: {local_credit['visits']}")
    print(f"   建议: ✅ 常客，放心接待")
    
    # 模拟新客
    print("\n   新顾客: cust_new_001")
    new_customer_credit = await rst_memory.check_customer_credit("cust_new_001")
    print(f"   数据来源: {new_customer_credit['source']}")
    print(f"   风险等级: {new_customer_credit['risk_level']}")
    print(f"   建议: ⚠️ 新顾客，建议正常接待或请求授权查信用")
    
    # 用餐后自动评价
    print("\n【场景3】用餐后自动询问评价")
    print("-" * 40)
    
    review_request = await rst_memory.request_review_after_meal(
        "cust_zhang_001",
        "v_20260410_001"
    )
    print(f"   {review_request['message']}")
    
    # 顾客提交评价
    print("\n   顾客Agent生成评价草稿:")
    mock_ratings = {
        "overall": 4.5,
        "food_quality": 5.0,
        "service": 4.0,
        "atmosphere": 4.5,
        "value_for_money": 4.0
    }
    print(f"   综合评分: {mock_ratings['overall']}/5")
    print(f"   评价摘要: '水煮鱼口味正宗必点，服务热情，但周末等位时间较长建议错峰。'")
    print(f"   标签: #口味正宗 #等位久 #服务热情")
    print(f"   ✅ 已发布到云端评价库")
    
    print("\n" + "="*60)
    print("     ✅ 云端记忆系统演示完成")
    print("="*60)


if __name__ == "__main__":
    asyncio.run(demo_cloud_memory())
