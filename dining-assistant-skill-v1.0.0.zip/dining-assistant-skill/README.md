# Dining Assistant Skill for OpenClaw

一个用于 OpenClaw Agent 的用餐助手 Skill，支持餐厅和顾客双端 Agent 握手交互，实现智能点餐、自动排号、个性化推荐等功能。

## 核心特性

### 餐厅模式 (Restaurant Mode)
- 📋 **菜单管理** - 动态更新菜品、价格、库存
- 📊 **队列管理** - 实时排队号码和进度追踪
- 🪑 **桌号管理** - 精确到桌位的状态管理
- 🤖 **智能推荐** - 基于顾客偏好的AI推荐
- 📱 **QR码生成** - 餐厅级、桌位级、外卖级QR码

### 顾客模式 (Customer Mode)
- 👤 **用餐档案** - 保存忌口、偏好、用餐习惯
- 🔍 **餐厅发现** - 扫码快速连接餐厅Agent
- 🎯 **智能推荐** - 接收个性化菜品推荐
- 📝 **一键下单** - 确认或修改推荐后直接下单
- ⏱️ **自动排号** - 远程加入队列，实时位置追踪
- 📌 **收藏餐厅** - 保存常去餐厅，快捷复购

### 握手协议 (Handshake Protocol)
- 🔐 **安全握手** - Agent双向身份验证
- 📡 **信息交换** - 菜单↔偏好智能匹配
- ⚡ **实时同步** - 订单状态、队列位置实时更新

## 快速开始

### 安装依赖

```bash
pip install -r requirements.txt
```

### 餐厅端部署

1. 复制配置模板：
```bash
cp assets/templates/config.restaurant.template.json config.json
```

2. 编辑 `config.json`，填写餐厅信息

3. 启动餐厅Agent：
```bash
python scripts/restaurant_server.py
```

### 顾客端部署

1. 复制配置模板：
```bash
cp assets/templates/config.customer.template.json config.json
```

2. 编辑 `config.json`，设置个人偏好

3. 启动顾客Agent：
```bash
python scripts/customer_client.py
```

## 使用流程

### 顾客扫码点餐流程

```
顾客扫码 → Agent握手 → 交换信息 → 智能推荐 → 确认订单 → 自动排号 → 到店即食
   ↑                                                                  ↓
   └──────────────── 实时队列更新 ← 订单状态推送 ← 开始制作 ───────────┘
```

### 餐厅管理流程

```
部署Agent → 配置菜单 → 生成QR码 → 顾客连接 → 接收订单 → 队列管理
```

## 项目结构

```
dining-assistant-skill/
├── SKILL.md                          # Skill入口文档
├── README.md                           # 本文件
├── requirements.txt                    # Python依赖
├── scripts/
│   ├── restaurant_server.py           # 餐厅端服务器
│   ├── customer_client.py             # 顾客端客户端
│   ├── handshake.py                   # 握手协议实现
│   └── qr_generator.py                # QR码生成器
├── references/
│   ├── protocol.md                    # 通信协议规范
│   ├── database_schema.md             # 数据模型
│   └── api_reference.md               # API文档
└── assets/
    └── templates/                      # 配置模板
        ├── config.restaurant.template.json
        └── config.customer.template.json
```

## 通信协议

### Agent握手流程

```
Customer                    Restaurant
   |                            |
   |-------- DISCOVERY -------->|
   |<------- DISCOVERY_RESPONSE-|
   |                            |
   |----- HANDSHAKE_REQUEST --->|
   |<---- HANDSHAKE_RESPONSE----|
   |                            |
   |======== CONNECTED =========|
   |                            |
```

### 消息类型

| 类型 | 方向 | 用途 |
|------|------|------|
| `DISCOVERY` | C→R | 发现餐厅Agent |
| `HANDSHAKE_REQUEST` | C→R | 发送用户档案 |
| `HANDSHAKE_RESPONSE` | R→C | 返回餐厅状态 |
| `MENU_REQUEST` | C→R | 请求菜单 |
| `RECOMMENDATION_REQUEST` | C→R | 请求推荐 |
| `QUEUE_JOIN` | C→R | 加入队列 |
| `ORDER_SUBMIT` | C→R | 提交订单 |

详细协议规范参见 [references/protocol.md](references/protocol.md)

## API参考

### RestaurantAgent

```python
from scripts.restaurant_server import RestaurantAgent

# 初始化
restaurant = RestaurantAgent(
    restaurant_id="rst_001",
    name="My Restaurant",
    location={"lat": 39.9042, "lng": 116.4074}
)

# 设置菜单
restaurant.set_menu(menu_data)

# 更新队列状态
restaurant.update_queue_status(current_number=45, wait_minutes=30)

# 启动服务器
restaurant.start_server(host="0.0.0.0", port=8080)
```

### CustomerAgent

```python
from scripts.customer_client import CustomerAgent

# 初始化
customer = CustomerAgent(
    user_id="user_001",
    preferences={"allergies": ["peanuts"], "cuisines": ["chinese"]}
)

# 连接餐厅
await customer.connect_to_restaurant("https://dining.ai/r/rst_001")

# 获取推荐
recommendations = await customer.get_recommendations(party_size=4)

# 提交订单
order = await customer.submit_order(items, party_size=4)
```

完整API文档参见 [references/api_reference.md](references/api_reference.md)

## 配置说明

### 餐厅配置 (`config.restaurant.template.json`)

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| `server.port` | 服务器端口 | 8080 |
| `queue.max_size` | 最大队列长度 | 50 |
| `ordering.require_prepayment` | 是否需要预付款 | false |
| `notifications.queue_updates` | 队列更新通知 | true |

### 顾客配置 (`config.customer.template.json`)

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| `user.default_party_size` | 默认用餐人数 | 2 |
| `preferences.spice_tolerance` | 辣度接受程度 | medium |
| `ordering.auto_join_queue` | 自动加入队列 | true |

## QR码类型

| 类型 | URL格式 | 用途 |
|------|---------|------|
| 餐厅级 | `/r/{restaurant_id}` | 通用入口 |
| 桌位级 | `/r/{restaurant_id}/t/{table_id}` | 指定桌位 |
| 外卖级 | `/r/{restaurant_id}/takeout` | 外卖专用 |

## 依赖项

- Python 3.8+
- `websockets` - WebSocket通信
- `qrcode` - QR码生成
- `asyncio` - 异步IO

完整依赖列表见 [requirements.txt](requirements.txt)

## 路线图

- [x] 基础握手协议
- [x] 餐厅模式核心功能
- [x] 顾客模式核心功能
- [x] QR码生成与解析
- [ ] 支付集成
- [ ] 多语言支持
- [ ] 云端同步
- [ ] 数据分析仪表盘

## 贡献指南

1. Fork本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送分支 (`git push origin feature/AmazingFeature`)
5. 创建Pull Request

## 开源协议

本项目采用 [MIT License](LICENSE)

## 联系我们

- 问题反馈: [GitHub Issues](https://github.com/yourusername/dining-assistant-skill/issues)
- 文档: [GitHub Wiki](https://github.com/yourusername/dining-assistant-skill/wiki)

---

<p align="center">Built with ❤️ for the OpenClaw Agent ecosystem</p>
