---
name: dining-assistant
description: A dual-mode dining assistant Skill for OpenClaw Agent that enables restaurant-customer Agent handshake. Restaurant mode provides menu, queue status, and table management. Customer mode stores dining preferences, dietary restrictions, and handles automatic handshake, recommendations, ordering, and queueing. Use when setting up dining-related Agent interactions, restaurant management automation, or smart dining experiences.
---

# Dining Assistant Skill

A comprehensive dining assistant for OpenClaw Agent ecosystem, enabling seamless restaurant-customer interactions through Agent-to-Agent handshake protocol.

## Overview

This Skill provides two operational modes:

1. **Restaurant Mode**: For restaurant owners/agents to manage menu, queue, tables, and orders
2. **Customer Mode**: For diners to store preferences, discover restaurants, and automate ordering

## Quick Start

### Restaurant Setup
```python
# Initialize restaurant agent
from dining_assistant import RestaurantAgent

restaurant = RestaurantAgent(
    name="My Restaurant",
    location={"lat": 39.9042, "lng": 116.4074}
)
restaurant.set_menu(menu_data)
restaurant.start_server(port=8080)
```

### Customer Setup
```python
# Initialize customer agent
from dining_assistant import CustomerAgent

customer = CustomerAgent(
    user_id="user_123",
    preferences={
        "allergies": ["peanuts"],
        "favorites": ["spicy", "sichuan"],
        "avoid": ["cilantro"]
    }
)
```

## Core Workflows

### 1. QR Code Handshake

When customer scans restaurant QR code:

1. Customer Agent discovers Restaurant Agent
2. Exchange capabilities (menu ↔ preferences)
3. Restaurant sends current queue status
4. Customer requests recommendations
5. Negotiate order and queue position

### 2. Automatic Ordering

After handshake completion:

1. Customer Agent analyzes menu against user preferences
2. Generates personalized recommendations
3. User confirms or modifies
4. Order sent to Restaurant Agent
5. Kitchen receives order with estimated prep time

### 3. Queue Management

Restaurant Agent maintains:
- Current queue number
- Estimated wait time
- Table availability
- Pre-order status

Customer Agent can:
- Join queue remotely
- Monitor position in real-time
- Receive notification when table ready
- Arrive with food preparation timed to arrival

## Reference Documentation

- [Protocol Specification](references/protocol.md) - Agent handshake protocol
- [Database Schema](references/database_schema.md) - Data models
- [API Reference](references/api_reference.md) - Complete API documentation

## Scripts

- `scripts/restaurant_server.py` - Restaurant mode server
- `scripts/customer_client.py` - Customer mode client  
- `scripts/handshake.py` - Handshake protocol implementation
- `scripts/qr_generator.py` - QR code generation for restaurants

## Configuration

Copy `assets/templates/config.template.json` to `config.json` and customize:

```json
{
  "mode": "restaurant|customer",
  "server": {
    "host": "0.0.0.0",
    "port": 8080
  },
  "agent_id": "unique_agent_identifier"
}
```
