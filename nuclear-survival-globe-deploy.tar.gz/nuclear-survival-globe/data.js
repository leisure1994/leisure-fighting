// 核战争城市自救地球仪 - 完整避难所数据
// 覆盖中国所有三线以上城市（约80个城市）

const SHELTER_DATA = {
    // ===== 一线城市（4个）=====
    "beijing": {
        name: "北京",
        center: [116.4074, 39.9042],
        shelters: [
            { id: "bj_001", name: "北京地下城(前门地下城)", type: "bunker", position: [116.3974, 39.9042], address: "北京市东城区前门地区", capacity: "30000人", level: "核6级", facilities: "通风系统、备用电源、医疗室、物资储备库", access: "地铁2号线前门站B出口，沿煤市街向南200米", description: "建于1969-1979年，全长30余公里，可容纳30万人，是世界上最宏大的民防工程之一" },
            { id: "bj_002", name: "北京站地下避难所", type: "shelter", position: [116.4274, 39.9042], address: "北京市东城区北京站地下", capacity: "5000人", level: "核5级", facilities: "应急供水、发电设备、通信系统", access: "北京站地铁站D出口", description: "北京火车站地下防空工程，战时可供数千人避难" },
            { id: "bj_003", name: "复兴门地下人防", type: "metro", position: [116.3574, 39.9042], address: "北京市西城区复兴门地铁站地下三层", capacity: "8000人", level: "核6级", facilities: "与地铁1号线、2号线联通，可快速疏散", access: "地铁复兴门站换乘层", description: "北京地铁核心枢纽，深度达地下30米" },
            { id: "bj_004", name: "中关村地下避难所", type: "shelter", position: [116.3174, 39.9842], address: "北京市海淀区中关村大街", capacity: "2000人", level: "核6级", facilities: "现代化防护设施，可与地铁4号线联通", access: "地铁4号线中关村站", description: "海淀区重要民防工程，覆盖高科技园区" },
            { id: "bj_005", name: "奥体中心地下工程", type: "bunker", position: [116.4074, 39.9942], address: "北京市朝阳区奥体中心地下", capacity: "10000人", level: "核5级", facilities: "奥运场馆改造的深层地下防护工程", access: "地铁8号线奥体中心站", description: "2008年奥运会期间建设的大型地下空间" },
            { id: "bj_006", name: "西直门地下城", type: "metro", position: [116.3574, 39.9442], address: "北京市西城区西直门地铁站", capacity: "6000人", level: "核6级", facilities: "地铁2/4/13号线换乘深层空间", access: "西直门地铁站F1出口", description: "北京地铁最大换乘站深层防护" },
            { id: "bj_007", name: "东直门地下避难所", type: "shelter", position: [116.4374, 39.9442], address: "北京市东城区东直门地铁站", capacity: "5000人", level: "核6级", facilities: "机场线、2号线、13号线交汇防护", access: "东直门地铁站东南口", description: "机场快轨起点站民防工程" }
        ]
    },
    "shanghai": {
        name: "上海",
        center: [121.4737, 31.2304],
        shelters: [
            { id: "sh_001", name: "人民广场地下避难所", type: "bunker", position: [121.4737, 31.2304], address: "上海市黄浦区人民广场地下", capacity: "15000人", level: "核5级", facilities: "三层地下空间，连接地铁1/2/8号线", access: "地铁人民广场站任意出口", description: "亚洲最大地下综合体之一，防护等级高" },
            { id: "sh_002", name: "陆家嘴地下人防", type: "shelter", position: [121.5037, 31.2404], address: "上海市浦东新区陆家嘴环路", capacity: "5000人", level: "核6级", facilities: "连接金茂大厦、环球金融中心地下室", access: "地铁2号线陆家嘴站", description: "金融中心核心区防护工程" },
            { id: "sh_003", name: "徐家汇地下城", type: "metro", position: [121.4437, 31.2004], address: "上海市徐汇区徐家汇商圈地下", capacity: "8000人", level: "核6级", facilities: "地铁1/9/11号线换乘站深层空间", access: "徐家汇地铁站18号口", description: "商业区地下民防设施，空间巨大" },
            { id: "sh_004", name: "虹桥枢纽地下避难所", type: "bunker", position: [121.3237, 31.2004], address: "上海市闵行区虹桥火车站地下", capacity: "20000人", level: "核5级", facilities: "高铁/地铁/机场一体化防护体系", access: "虹桥火车站地铁站最深层", description: "华东地区最大交通枢纽防护工程" },
            { id: "sh_005", name: "静安寺地下人防", type: "shelter", position: [121.4537, 31.2304], address: "上海市静安区静安寺地下", capacity: "6000人", level: "核6级", facilities: "地铁2/7/14号线交汇深层空间", access: "静安寺地铁站", description: "市中心核心区域多层防护" },
            { id: "sh_006", name: "浦东机场地下避难所", type: "bunker", position: [121.8037, 31.1504], address: "上海市浦东新区浦东机场T1/T2地下", capacity: "10000人", level: "核5级", facilities: "机场深层防护体系，磁悬浮联通", access: "地铁2号线浦东国际机场站", description: "中国最大国际机场防护工程" },
            { id: "sh_007", name: "五角场地下城", type: "metro", position: [121.5137, 31.3004], address: "上海市杨浦区五角场商圈地下", capacity: "6000人", level: "核6级", facilities: "地铁10号线深层商业民防", access: "地铁10号线五角场站", description: "杨浦副中心地下防护" }
        ]
    },
    "guangzhou": {
        name: "广州",
        center: [113.2644, 23.1291],
        shelters: [
            { id: "gz_001", name: "广州火车站地下避难所", type: "shelter", position: [113.2644, 23.1291], address: "广州市越秀区广州火车站地下", capacity: "6000人", level: "核6级", facilities: "火车站地下三层民防工程", access: "地铁2/5号线广州火车站", description: "华南最大铁路枢纽防护设施" },
            { id: "gz_002", name: "珠江新城地下城", type: "bunker", position: [113.3244, 23.1191], address: "广州市天河区珠江新城CBD地下", capacity: "12000人", level: "核5级", facilities: "CBD核心区地下防护网络", access: "地铁3/5号线珠江新城站", description: "金融中心区深层防护体系" },
            { id: "gz_003", name: "体育西路地下避难所", type: "metro", position: [113.3144, 23.1391], address: "广州市天河区体育西路地铁站", capacity: "5000人", level: "核6级", facilities: "地铁1/3号线换乘深层空间", access: "体育西路地铁站G出口", description: "天河商圈地下民防设施" },
            { id: "gz_004", name: "白云机场地下避难所", type: "bunker", position: [113.3044, 23.3991], address: "广州市白云区白云机场T1/T2地下", capacity: "8000人", level: "核5级", facilities: "机场地下深层防护工程", access: "地铁3号线机场南站/机场北站", description: "航空枢纽核心防护设施" },
            { id: "gz_005", name: "琶洲地下避难所", type: "shelter", position: [113.3644, 23.1091], address: "广州市海珠区琶洲会展中心地下", capacity: "4000人", level: "核6级", facilities: "会展中心地下民防", access: "地铁8号线琶洲站", description: "广交会核心区防护" }
        ]
    },
    "shenzhen": {
        name: "深圳",
        center: [114.0579, 22.5431],
        shelters: [
            { id: "sz_001", name: "福田中心区地下城", type: "bunker", position: [114.0579, 22.5431], address: "深圳市福田区市民中心地下", capacity: "10000人", level: "核5级", facilities: "CBD核心区地下防护网络", access: "地铁2/4号线市民中心站", description: "深圳中央商务区核心防护" },
            { id: "sz_002", name: "罗湖口岸地下避难所", type: "shelter", position: [114.1179, 22.5331], address: "深圳市罗湖区罗湖口岸地下", capacity: "5000人", level: "核6级", facilities: "口岸深层防护设施", access: "地铁1号线罗湖站", description: "深港边境重要民防工程" },
            { id: "sz_003", name: "深圳北站地下避难所", type: "metro", position: [114.0279, 22.6031], address: "深圳市龙华区深圳北站地下", capacity: "7000人", level: "核6级", facilities: "高铁枢纽地下防护体系", access: "地铁4/5/6号线深圳北站", description: "华南最大高铁枢纽防护" },
            { id: "sz_004", name: "南山科技园地下人防", type: "shelter", position: [113.9379, 22.5431], address: "深圳市南山区科技园核心区", capacity: "3000人", level: "核6级", facilities: "高科技园区地下民防", access: "地铁1号线深大站", description: "深圳硅谷核心防护设施" },
            { id: "sz_005", name: "宝安机场地下避难所", type: "bunker", position: [113.8179, 22.6431], address: "深圳市宝安区宝安机场T3地下", capacity: "6000人", level: "核5级", facilities: "机场深层防护体系", access: "地铁11号线机场站", description: "深圳航空枢纽民防" }
        ]
    },
    // ===== 新一线城市（15个）=====
    "chengdu": {
        name: "成都",
        center: [104.0668, 30.5728],
        shelters: [
            { id: "cd_001", name: "天府广场地下避难所", type: "bunker", position: [104.0668, 30.5728], address: "成都市锦江区天府广场地下", capacity: "8000人", level: "核5级", facilities: "市中心多层地下防护空间", access: "地铁1/2号线天府广场站", description: "成都城市核心防护工程" },
            { id: "cd_002", name: "春熙路地下人防", type: "metro", position: [104.0768, 30.5628], address: "成都市锦江区春熙路地铁站", capacity: "4000人", level: "核6级", facilities: "商业街深层民防设施", access: "地铁2/3号线春熙路站", description: "成都最繁华商圈地下防护" },
            { id: "cd_003", name: "火车南站地下避难所", type: "shelter", position: [104.0668, 30.6128], address: "成都市武侯区火车南站地下", capacity: "5000人", level: "核6级", facilities: "铁路枢纽地下防护", access: "地铁1/7/18号线火车南站", description: "成都南门交通枢纽防护" },
            { id: "cd_004", name: "双流机场地下避难所", type: "bunker", position: [103.9368, 30.5728], address: "成都市双流区双流机场T1/T2地下", capacity: "6000人", level: "核5级", facilities: "机场深层防护体系", access: "地铁10号线双流机场站", description: "航空枢纽民防工程" }
        ]
    },
    "chongqing": {
        name: "重庆",
        center: [106.5516, 29.5630],
        shelters: [
            { id: "cq_001", name: "解放碑地下城", type: "bunker", position: [106.5516, 29.5630], address: "重庆市渝中区解放碑地下", capacity: "10000人", level: "核5级", facilities: "CBD核心区多层地下防护", access: "地铁1/6号线小什字站", description: "山城最核心地段深层民防" },
            { id: "cq_002", name: "观音桥地下避难所", type: "metro", position: [106.5316, 29.5730], address: "重庆市江北区观音桥地铁站", capacity: "5000人", level: "核6级", facilities: "商圈地下防护空间", access: "地铁3号线观音桥站", description: "重庆最大商圈民防设施" },
            { id: "cq_003", name: "江北机场地下避难所", type: "shelter", position: [106.6316, 29.7130], address: "重庆市渝北区江北机场T2/T3地下", capacity: "7000人", level: "核5级", facilities: "航空枢纽深层防护", access: "地铁3/10号线江北机场站", description: "西部最大机场防护工程" },
            { id: "cq_004", name: "沙坪坝地下城", type: "metro", position: [106.4616, 29.5630], address: "重庆市沙坪坝区三峡广场地下", capacity: "6000人", level: "核6级", facilities: "商圈深层民防", access: "地铁1/9号线沙坪坝站", description: "重庆西部商圈防护" }
        ]
    },
    "wuhan": {
        name: "武汉",
        center: [114.3055, 30.5928],
        shelters: [
            { id: "wh_001", name: "江汉路地下避难所", type: "bunker", position: [114.3055, 30.5928], address: "武汉市江汉区江汉路地铁站", capacity: "5000人", level: "核6级", facilities: "商业街深层民防", access: "地铁2/6号线江汉路站", description: "武汉最繁华商圈地下防护" },
            { id: "wh_002", name: "汉口火车站地下避难所", type: "shelter", position: [114.2555, 30.6228], address: "武汉市江汉区汉口火车站地下", capacity: "6000人", level: "核6级", facilities: "铁路枢纽防护工程", access: "地铁2号线汉口火车站", description: "华中最大铁路枢纽防护" },
            { id: "wh_003", name: "光谷广场地下城", type: "metro", position: [114.4055, 30.5128], address: "武汉市洪山区光谷广场地下", capacity: "8000人", level: "核6级", facilities: "亚洲最大地下综合体之一", access: "地铁2号线光谷广场站", description: "光谷核心多层地下空间" },
            { id: "wh_004", name: "天河机场地下避难所", type: "bunker", position: [114.2055, 30.7828], address: "武汉市黄陂区天河机场T3地下", capacity: "5000人", level: "核5级", facilities: "机场深层防护体系", access: "地铁2号线天河机场站", description: "中部最大航空枢纽防护" }
        ]
    },
    "xian": {
        name: "西安",
        center: [108.9402, 34.3416],
        shelters: [
            { id: "xa_001", name: "钟楼地下避难所", type: "bunker", position: [108.9402, 34.3416], address: "西安市莲湖区钟楼地下", capacity: "6000人", level: "核5级", facilities: "古城中心深层民防", access: "地铁2号线钟楼站", description: "西安城市核心防护工程" },
            { id: "xa_002", name: "小寨地下城", type: "metro", position: [108.9502, 34.2216], address: "西安市雁塔区小寨地铁站", capacity: "5000人", level: "核6级", facilities: "商圈地下防护空间", access: "地铁2/3号线小寨站", description: "西安最繁华商圈民防" },
            { id: "xa_003", name: "北客站地下避难所", type: "shelter", position: [108.9202, 34.3816], address: "西安市未央区西安北站地下", capacity: "8000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁2/4/14号线北客站", description: "西北最大高铁枢纽防护" },
            { id: "xa_004", name: "咸阳机场地下避难所", type: "bunker", position: [108.7502, 34.4416], address: "咸阳市渭城区咸阳机场T3地下", capacity: "5000人", level: "核5级", facilities: "机场防护工程", access: "地铁14号线机场西站", description: "西北最大机场民防设施" }
        ]
    },
    "nanjing": {
        name: "南京",
        center: [118.7969, 32.0603],
        shelters: [
            { id: "nj_001", name: "新街口地下城", type: "bunker", position: [118.7969, 32.0603], address: "南京市玄武区新街口地下", capacity: "10000人", level: "核5级", facilities: "中华第一商圈深层防护", access: "地铁1/2号线新街口站", description: "南京最核心商圈民防" },
            { id: "nj_002", name: "南京站地下避难所", type: "shelter", position: [118.7869, 32.0903], address: "南京市玄武区南京站地下", capacity: "5000人", level: "核6级", facilities: "铁路枢纽防护", access: "地铁1/3号线南京站", description: "南京火车站民防工程" },
            { id: "nj_003", name: "禄口机场地下避难所", type: "bunker", position: [118.8669, 31.7403], address: "南京市江宁区禄口机场T1/T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "地铁S1号线禄口机场站", description: "南京航空枢纽防护" },
            { id: "nj_004", name: "夫子庙地下人防", type: "metro", position: [118.8069, 32.0203], address: "南京市秦淮区夫子庙地铁站", capacity: "4000人", level: "核6级", facilities: "景区地下民防", access: "地铁3号线夫子庙站", description: "夫子庙景区防护" }
        ]
    },
    "hangzhou": {
        name: "杭州",
        center: [120.1551, 30.2741],
        shelters: [
            { id: "hz_001", name: "龙翔桥地下避难所", type: "bunker", position: [120.1551, 30.2741], address: "杭州市上城区龙翔桥地铁站", capacity: "5000人", level: "核6级", facilities: "西湖核心区深层民防", access: "地铁1号线龙翔桥站", description: "杭州最核心地段防护" },
            { id: "hz_002", name: "杭州东站地下避难所", type: "metro", position: [120.2051, 30.2941], address: "杭州市江干区杭州东站地下", capacity: "8000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁1/4/6/19号线火车东站", description: "华东最大高铁枢纽民防" },
            { id: "hz_003", name: "萧山机场地下避难所", type: "shelter", position: [120.4351, 30.2341], address: "杭州市萧山区萧山机场T1/T2/T3地下", capacity: "6000人", level: "核5级", facilities: "机场防护体系", access: "地铁1/7/19号线萧山国际机场站", description: "杭州航空枢纽防护" },
            { id: "hz_004", name: "钱江新城地下城", type: "bunker", position: [120.2051, 30.2541], address: "杭州市上城区钱江新城地下", capacity: "6000人", level: "核6级", facilities: "CBD深层民防", access: "地铁4号线市民中心站", description: "杭州新中心防护" }
        ]
    },
    "tianjin": {
        name: "天津",
        center: [117.2009, 39.0842],
        shelters: [
            { id: "tj_001", name: "滨江道地下避难所", type: "bunker", position: [117.2009, 39.0842], address: "天津市和平区滨江道地下", capacity: "5000人", level: "核6级", facilities: "商业街深层民防", access: "地铁1/3号线营口道站", description: "天津最繁华商圈防护" },
            { id: "tj_002", name: "天津站地下避难所", type: "metro", position: [117.2109, 39.1342], address: "天津市河北区天津站地下", capacity: "6000人", level: "核6级", facilities: "铁路枢纽深层防护", access: "地铁2/3/9号线天津站", description: "天津核心交通枢纽民防" },
            { id: "tj_003", name: "滨海机场地下避难所", type: "shelter", position: [117.3609, 39.1342], address: "天津市东丽区滨海机场T1/T2地下", capacity: "5000人", level: "核5级", facilities: "机场深层防护", access: "地铁2号线滨海国际机场站", description: "天津航空枢纽民防" }
        ]
    },
    "zhengzhou": {
        name: "郑州",
        center: [113.6253, 34.7466],
        shelters: [
            { id: "zz_001", name: "二七广场地下避难所", type: "bunker", position: [113.6253, 34.7466], address: "郑州市二七区二七广场地下", capacity: "5000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1/3号线二七广场站", description: "郑州城市核心防护" },
            { id: "zz_002", name: "郑州东站地下避难所", type: "metro", position: [113.6853, 34.7566], address: "郑州市金水区郑州东站地下", capacity: "8000人", level: "核6级", facilities: "亚洲最大高铁枢纽防护", access: "地铁1/5号线郑州东站", description: "米字形高铁核心民防" },
            { id: "zz_003", name: "新郑机场地下避难所", type: "shelter", position: [113.8453, 34.5266], address: "郑州市新郑区新郑机场T2地下", capacity: "6000人", level: "核5级", facilities: "机场深层防护", access: "城郊线新郑机场站", description: "郑州航空枢纽民防" }
        ]
    },
    "changsha": {
        name: "长沙",
        center: [112.9388, 28.2282],
        shelters: [
            { id: "cs_001", name: "五一广场地下避难所", type: "bunker", position: [112.9388, 28.2282], address: "长沙市芙蓉区五一广场地下", capacity: "6000人", level: "核6级", facilities: "市中心多层地下防护", access: "地铁1/2号线五一广场站", description: "长沙最核心商圈民防" },
            { id: "cs_002", name: "橘子洲地下人防", type: "metro", position: [112.9588, 28.1782], address: "长沙市岳麓区橘子洲地下", capacity: "3000人", level: "核6级", facilities: "景区地下民防设施", access: "地铁2号线橘子洲站", description: "橘子洲景区防护工程" },
            { id: "cs_003", name: "长沙南站地下避难所", type: "shelter", position: [113.0688, 28.1782], address: "长沙市雨花区长沙南站地下", capacity: "7000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁2/4号线长沙火车南站", description: "长沙高铁枢纽民防" }
        ]
    },
    "suzhou": {
        name: "苏州",
        center: [120.5853, 31.2989],
        shelters: [
            { id: "su_001", name: "观前街地下避难所", type: "bunker", position: [120.5853, 31.2989], address: "苏州市姑苏区观前街地下", capacity: "4000人", level: "核6级", facilities: "古城核心区民防", access: "地铁4号线察院场站", description: "苏州最繁华商圈防护" },
            { id: "su_002", name: "苏州站地下避难所", type: "metro", position: [120.6053, 31.3389], address: "苏州市姑苏区苏州站地下", capacity: "5000人", level: "核6级", facilities: "铁路枢纽深层防护", access: "地铁2/4号线苏州火车站", description: "苏州火车站民防" },
            { id: "su_003", name: "园区站地下避难所", type: "shelter", position: [120.7353, 31.3389], address: "苏州市工业园区苏州园区站地下", capacity: "3000人", level: "核6级", facilities: "高铁枢纽防护", access: "地铁3号线园区火车站", description: "园区枢纽民防" }
        ]
    },
    "qingdao": {
        name: "青岛",
        center: [120.3826, 36.0671],
        shelters: [
            { id: "qd_001", name: "五四广场地下避难所", type: "bunker", position: [120.3826, 36.0671], address: "青岛市市南区五四广场地下", capacity: "4000人", level: "核6级", facilities: "海滨核心区深层民防", access: "地铁2/3号线五四广场站", description: "青岛最核心地段防护" },
            { id: "qd_002", name: "青岛站地下避难所", type: "metro", position: [120.3126, 36.0671], address: "青岛市市南区青岛站地下", capacity: "3000人", level: "核6级", facilities: "火车站地下防护", access: "地铁1/3号线青岛站", description: "青岛火车站民防" },
            { id: "qd_003", name: "胶东机场地下避难所", type: "shelter", position: [120.4926, 36.3871], address: "青岛市胶州市胶东机场地下", capacity: "6000人", level: "核5级", facilities: "机场深层防护", access: "地铁8号线胶东机场站", description: "青岛航空枢纽民防" }
        ]
    },
    "dongguan": {
        name: "东莞",
        center: [113.7518, 23.0207],
        shelters: [
            { id: "dg_001", name: "鸿福路地下避难所", type: "bunker", position: [113.7518, 23.0207], address: "东莞市南城区鸿福路地铁站", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁2号线鸿福路站", description: "东莞城市核心防护" },
            { id: "dg_002", name: "东莞火车站地下避难所", type: "metro", position: [113.8218, 23.0707], address: "东莞市石龙镇东莞火车站地下", capacity: "3000人", level: "核6级", facilities: "铁路枢纽防护", access: "地铁2号线东莞火车站", description: "东莞火车站民防" }
        ]
    },
    "foshan": {
        name: "佛山",
        center: [113.1214, 23.0215],
        shelters: [
            { id: "fs_001", name: "祖庙地下避难所", type: "bunker", position: [113.1214, 23.0215], address: "佛山市禅城区祖庙地铁站", capacity: "3000人", level: "核6级", facilities: "市中心深层民防", access: "地铁广佛线祖庙站", description: "佛山城市核心防护" },
            { id: "fs_002", name: "佛山西站地下避难所", type: "shelter", position: [113.0214, 23.1215], address: "佛山市南海区佛山西站地下", capacity: "5000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁3号线佛山西站", description: "佛山高铁枢纽民防" }
        ]
    },
    // ===== 二线城市（30个）=====
    "shenyang": {
        name: "沈阳",
        center: [123.4315, 41.8057],
        shelters: [
            { id: "sy_001", name: "太原街地下避难所", type: "bunker", position: [123.4315, 41.8057], address: "沈阳市和平区太原街地下", capacity: "5000人", level: "核6级", facilities: "商业街深层民防", access: "地铁1号线太原街站", description: "沈阳最繁华商圈防护" },
            { id: "sy_002", name: "沈阳站地下避难所", type: "metro", position: [123.4015, 41.8057], address: "沈阳市和平区沈阳站地下", capacity: "4000人", level: "核6级", facilities: "铁路枢纽防护", access: "地铁1号线沈阳站站", description: "沈阳火车站民防工程" },
            { id: "sy_003", name: "桃仙机场地下避难所", type: "shelter", position: [123.5015, 41.6457], address: "沈阳市浑南区桃仙机场T3地下", capacity: "5000人", level: "核5级", facilities: "机场深层防护", access: "地铁2号线桃仙机场站", description: "沈阳航空枢纽民防" }
        ]
    },
    "dalian": {
        name: "大连",
        center: [121.6147, 38.9140],
        shelters: [
            { id: "dl_001", name: "中山广场地下避难所", type: "bunker", position: [121.6147, 38.9140], address: "大连市中山区中山广场地下", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁2号线中山广场站", description: "大连城市核心防护" },
            { id: "dl_002", name: "大连站地下避难所", type: "metro", position: [121.6247, 38.9240], address: "大连市中山区大连站地下", capacity: "3000人", level: "核6级", facilities: "铁路枢纽防护", access: "地铁3/5号线大连站", description: "大连火车站民防" },
            { id: "dl_003", name: "周水子机场地下避难所", type: "shelter", position: [121.5447, 38.9640], address: "大连市甘井子区周水子机场地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "地铁2号线机场站", description: "大连航空枢纽民防" }
        ]
    },
    "xiamen": {
        name: "厦门",
        center: [118.0894, 24.4798],
        shelters: [
            { id: "xm_001", name: "中山路地下避难所", type: "bunker", position: [118.0894, 24.4798], address: "厦门市思明区中山路地下", capacity: "3000人", level: "核6级", facilities: "老城核心区深层民防", access: "地铁1号线镇海路站", description: "厦门最核心地段防护" },
            { id: "xm_002", name: "高崎机场地下避难所", type: "metro", position: [118.1094, 24.5398], address: "厦门市湖里区高崎机场地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "地铁1号线高崎站", description: "厦门航空枢纽民防" },
            { id: "xm_003", name: "厦门北站地下避难所", type: "shelter", position: [118.0694, 24.6398], address: "厦门市集美区厦门北站地下", capacity: "5000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁1号线厦门北站", description: "厦门高铁枢纽民防" }
        ]
    },
    "wuxi": {
        name: "无锡",
        center: [120.3119, 31.4912],
        shelters: [
            { id: "wx_001", name: "三阳广场地下避难所", type: "bunker", position: [120.3119, 31.4912], address: "无锡市梁溪区三阳广场地下", capacity: "5000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1/2号线三阳广场站", description: "无锡城市核心防护" },
            { id: "wx_002", name: "无锡东站地下避难所", type: "metro", position: [120.4519, 31.5312], address: "无锡市锡山区无锡东站地下", capacity: "4000人", level: "核6级", facilities: "高铁枢纽防护", access: "地铁2号线无锡东站", description: "无锡高铁枢纽民防" }
        ]
    },
    "ningbo": {
        name: "宁波",
        center: [121.5500, 29.8750],
        shelters: [
            { id: "nb_001", name: "天一广场地下避难所", type: "bunker", position: [121.5500, 29.8750], address: "宁波市海曙区天一广场地下", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1号线东门口站", description: "宁波最核心商圈防护" },
            { id: "nb_002", name: "宁波站地下避难所", type: "metro", position: [121.5700, 29.8650], address: "宁波市海曙区宁波站地下", capacity: "5000人", level: "核6级", facilities: "铁路枢纽深层防护", access: "地铁2/4号线宁波火车站", description: "宁波火车站民防" },
            { id: "nb_003", name: "栎社机场地下避难所", type: "shelter", position: [121.4700, 29.8350], address: "宁波市海曙区栎社机场T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "地铁2号线栎社国际机场站", description: "宁波航空枢纽民防" }
        ]
    },
    "fuzhou": {
        name: "福州",
        center: [119.2965, 26.0745],
        shelters: [
            { id: "fz_001", name: "东街口地下避难所", type: "bunker", position: [119.2965, 26.0745], address: "福州市鼓楼区东街口地下", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1/2号线南门兜站", description: "福州城市核心防护" },
            { id: "fz_002", name: "长乐机场地下避难所", type: "metro", position: [119.6565, 25.9345], address: "福州市长乐区长乐机场地下", capacity: "3000人", level: "核5级", facilities: "机场防护工程", access: "地铁6号线/机场大巴", description: "福州航空枢纽民防" },
            { id: "fz_003", name: "福州站地下避难所", type: "shelter", position: [119.3165, 26.1045], address: "福州市晋安区福州站地下", capacity: "5000人", level: "核6级", facilities: "铁路枢纽防护", access: "地铁1号线福州火车站", description: "福州火车站民防" }
        ]
    },
    "hefei": {
        name: "合肥",
        center: [117.2272, 31.8206],
        shelters: [
            { id: "hf_001", name: "大东门地下避难所", type: "bunker", position: [117.2672, 31.8606], address: "合肥市瑶海区大东门地铁站", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1/2号线大东门站", description: "合肥城市核心防护" },
            { id: "hf_002", name: "合肥南站地下避难所", type: "metro", position: [117.2872, 31.8006], address: "合肥市包河区合肥南站地下", capacity: "6000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁1/4/5号线合肥南站", description: "安徽最大高铁枢纽民防" },
            { id: "hf_003", name: "新桥机场地下避难所", type: "shelter", position: [116.9872, 31.9806], address: "合肥市蜀山区新桥机场T1/T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "机场大巴/地铁S1线", description: "合肥航空枢纽民防" }
        ]
    },
    "shijiazhuang": {
        name: "石家庄",
        center: [114.5149, 38.0423],
        shelters: [
            { id: "sjz_001", name: "北国商城地下避难所", type: "bunker", position: [114.5149, 38.0423], address: "石家庄市长安区北国商城地下", capacity: "3000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1号线北国商城站", description: "石家庄核心商圈防护" },
            { id: "sjz_002", name: "石家庄站地下避难所", type: "metro", position: [114.4849, 38.0123], address: "石家庄市桥西区石家庄站地下", capacity: "5000人", level: "核6级", facilities: "铁路枢纽防护", access: "地铁2/3号线石家庄站", description: "石家庄火车站民防" },
            { id: "sjz_003", name: "正定机场地下避难所", type: "shelter", position: [114.7049, 38.2823], address: "石家庄市正定县正定机场T1/T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "高铁/机场大巴", description: "石家庄航空枢纽民防" }
        ]
    },
    "kunming": {
        name: "昆明",
        center: [102.8329, 24.8801],
        shelters: [
            { id: "km_001", name: "东风广场地下避难所", type: "bunker", position: [102.7129, 25.0381], address: "昆明市盘龙区东风广场地铁站", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁2/3号线东风广场站", description: "昆明城市核心防护" },
            { id: "km_002", name: "长水机场地下避难所", type: "metro", position: [102.9329, 25.0981], address: "昆明市官渡区长水机场T1/T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "地铁6号线机场中心站", description: "昆明航空枢纽民防" },
            { id: "km_003", name: "昆明站地下避难所", type: "shelter", position: [102.7329, 25.0281], address: "昆明市官渡区昆明站地下", capacity: "5000人", level: "核6级", facilities: "铁路枢纽深层防护", access: "地铁1/2号线昆明火车站", description: "昆明火车站民防" }
        ]
    },
    "nanchang": {
        name: "南昌",
        center: [115.8579, 28.6820],
        shelters: [
            { id: "nc_001", name: "八一广场地下避难所", type: "bunker", position: [115.8779, 28.6820], address: "南昌市东湖区八一广场地下", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1/2号线八一广场站", description: "南昌城市核心防护" },
            { id: "nc_002", name: "南昌西站地下避难所", type: "metro", position: [115.7979, 28.6220], address: "南昌市红谷滩区南昌西站地下", capacity: "5000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁2号线南昌西站", description: "南昌高铁枢纽民防" },
            { id: "nc_003", name: "昌北机场地下避难所", type: "shelter", position: [115.9179, 28.8620], address: "南昌市新建区昌北机场T1/T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "机场大巴/地铁1号线", description: "南昌航空枢纽民防" }
        ]
    },
    "jinan": {
        name: "济南",
        center: [117.1205, 36.6510],
        shelters: [
            { id: "jn_001", name: "泉城广场地下避难所", type: "bunker", position: [117.0005, 36.6610], address: "济南市历下区泉城广场地下", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1号线泉城广场站", description: "济南城市核心防护" },
            { id: "jn_002", name: "济南西站地下避难所", type: "metro", position: [116.9205, 36.6810], address: "济南市槐荫区济南西站地下", capacity: "5000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁1号线济南西站", description: "济南高铁枢纽民防" },
            { id: "jn_003", name: "遥墙机场地下避难所", type: "shelter", position: [117.2005, 36.8610], address: "济南市历城区遥墙机场地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "机场大巴/地铁3号线", description: "济南航空枢纽民防" }
        ]
    },
    "harbin": {
        name: "哈尔滨",
        center: [126.5340, 45.8038],
        shelters: [
            { id: "hrb_001", name: "中央大街地下避难所", type: "bunker", position: [126.5340, 45.8038], address: "哈尔滨市道里区中央大街地铁站", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁2号线中央大街站", description: "哈尔滨最核心地段防护" },
            { id: "hrb_002", name: "哈尔滨站地下避难所", type: "metro", position: [126.5340, 45.7838], address: "哈尔滨市南岗区哈尔滨站地下", capacity: "5000人", level: "核6级", facilities: "铁路枢纽深层防护", access: "地铁2号线哈尔滨站", description: "哈尔滨火车站民防" },
            { id: "hrb_003", name: "太平机场地下避难所", type: "shelter", position: [126.2540, 45.6238], address: "哈尔滨市道里区太平机场T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "机场大巴/地铁", description: "哈尔滨航空枢纽民防" }
        ]
    },
    "changchun": {
        name: "长春",
        center: [125.3235, 43.8171],
        shelters: [
            { id: "cc_001", name: "人民广场地下避难所", type: "bunker", position: [125.3235, 43.8171], address: "长春市朝阳区人民广场地铁站", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1号线人民广场站", description: "长春城市核心防护" },
            { id: "cc_002", name: "长春站地下避难所", type: "metro", position: [125.3235, 43.9071], address: "长春市宽城区长春站地下", capacity: "5000人", level: "核6级", facilities: "铁路枢纽深层防护", access: "地铁1号线长春站", description: "长春火车站民防" },
            { id: "cc_003", name: "龙嘉机场地下避难所", type: "shelter", position: [125.7035, 44.0071], address: "长春市九台区龙嘉机场T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "高铁龙嘉站/机场大巴", description: "长春航空枢纽民防" }
        ]
    },
    "taiyuan": {
        name: "太原",
        center: [112.5489, 37.8706],
        shelters: [
            { id: "ty_001", name: "五一广场地下避难所", type: "bunker", position: [112.5489, 37.8706], address: "太原市迎泽区五一广场地铁站", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1号线五一广场站", description: "太原城市核心防护" },
            { id: "ty_002", name: "太原南站地下避难所", type: "metro", position: [112.6289, 37.7906], address: "太原市小店区太原南站地下", capacity: "5000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁1号线太原南站", description: "太原高铁枢纽民防" },
            { id: "ty_003", name: "武宿机场地下避难所", type: "shelter", position: [112.6289, 37.7606], address: "太原市小店区武宿机场T1/T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "机场大巴/地铁1号线", description: "太原航空枢纽民防" }
        ]
    },
    "guiyang": {
        name: "贵阳",
        center: [106.6302, 26.6477],
        shelters: [
            { id: "gy_001", name: "喷水池地下避难所", type: "bunker", position: [106.7102, 26.5877], address: "贵阳市云岩区喷水池地铁站", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1/2号线喷水池站", description: "贵阳城市核心防护" },
            { id: "gy_002", name: "贵阳北站地下避难所", type: "metro", position: [106.6702, 26.6277], address: "贵阳市观山湖区贵阳北站地下", capacity: "5000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁1号线贵阳北站", description: "贵阳高铁枢纽民防" },
            { id: "gy_003", name: "龙洞堡机场地下避难所", type: "shelter", position: [106.7902, 26.5377], address: "贵阳市南明区龙洞堡机场T1/T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "地铁2号线龙洞堡机场站", description: "贵阳航空枢纽民防" }
        ]
    },
    "nanning": {
        name: "南宁",
        center: [108.3661, 22.8172],
        shelters: [
            { id: "nn_001", name: "朝阳广场地下避难所", type: "bunker", position: [108.3661, 22.8172], address: "南宁市兴宁区朝阳广场地铁站", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1/2号线朝阳广场站", description: "南宁城市核心防护" },
            { id: "nn_002", name: "南宁东站地下避难所", type: "metro", position: [108.4061, 22.8372], address: "南宁市青秀区南宁东站地下", capacity: "5000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁1号线南宁东站", description: "南宁高铁枢纽民防" },
            { id: "nn_003", name: "吴圩机场地下避难所", type: "shelter", position: [108.1861, 22.6172], address: "南宁市江南区吴圩机场T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "机场大巴/高铁吴圩机场站", description: "南宁航空枢纽民防" }
        ]
    },
    "lanzhou": {
        name: "兰州",
        center: [103.8343, 36.0611],
        shelters: [
            { id: "lz_001", name: "西关十字地下避难所", type: "bunker", position: [103.8343, 36.0611], address: "兰州市城关区西关十字地铁站", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1号线西关站", description: "兰州城市核心防护" },
            { id: "lz_002", name: "兰州西站地下避难所", type: "metro", position: [103.7543, 36.0211], address: "兰州市七里河区兰州西站地下", capacity: "5000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁1号线兰州西站", description: "兰州高铁枢纽民防" },
            { id: "lz_003", name: "中川机场地下避难所", type: "shelter", position: [103.6343, 36.5211], address: "兰州市永登县中川机场T1/T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "高铁中川机场站/机场大巴", description: "兰州航空枢纽民防" }
        ]
    },
    "wenzhou": {
        name: "温州",
        center: [120.6994, 27.9943],
        shelters: [
            { id: "wz_001", name: "五马街地下避难所", type: "bunker", position: [120.6594, 28.0043], address: "温州市鹿城区五马街地下", capacity: "3000人", level: "核6级", facilities: "市中心深层民防", access: "地铁M1线(在建)/公交", description: "温州城市核心防护" },
            { id: "wz_002", name: "温州南站地下避难所", type: "metro", position: [120.5594, 27.9943], address: "温州市瓯海区温州南站地下", capacity: "4000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁S1线动车南站", description: "温州高铁枢纽民防" },
            { id: "wz_003", name: "龙湾机场地下避难所", type: "shelter", position: [120.8594, 27.9143], address: "温州市龙湾区龙湾机场T1/T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "地铁S1线机场站/S2线", description: "温州航空枢纽民防" }
        ]
    },
    "changzhou": {
        name: "常州",
        center: [119.9741, 31.8112],
        shelters: [
            { id: "cz_001", name: "文化宫地下避难所", type: "bunker", position: [119.9741, 31.8112], address: "常州市天宁区文化宫地铁站", capacity: "3000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1/2号线文化宫站", description: "常州城市核心防护" },
            { id: "cz_002", name: "常州站地下避难所", type: "metro", position: [119.9541, 31.7912], address: "常州市天宁区常州站地下", capacity: "4000人", level: "核6级", facilities: "铁路枢纽深层防护", access: "地铁1号线常州火车站", description: "常州火车站民防" }
        ]
    },
    "xuzhou": {
        name: "徐州",
        center: [117.2841, 34.2058],
        shelters: [
            { id: "xz_001", name: "彭城广场地下避难所", type: "bunker", position: [117.1841, 34.2641], address: "徐州市云龙区彭城广场地铁站", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1/2号线彭城广场站", description: "徐州城市核心防护" },
            { id: "xz_002", name: "徐州东站地下避难所", type: "metro", position: [117.3041, 34.3058], address: "徐州市贾汪区徐州东站地下", capacity: "5000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁1号线徐州东站", description: "徐州高铁枢纽民防" }
        ]
    },
    "nantong": {
        name: "南通",
        center: [120.8943, 31.9802],
        shelters: [
            { id: "nt_001", name: "南通站地下避难所", type: "bunker", position: [120.8943, 32.0202], address: "南通市港闸区南通站地下", capacity: "4000人", level: "核6级", facilities: "铁路枢纽深层防护", access: "地铁1号线南通站", description: "南通火车站民防" },
            { id: "nt_002", name: "兴东机场地下避难所", type: "shelter", position: [120.9743, 32.0741], address: "南通市通州区兴东机场T3地下", capacity: "3000人", level: "核5级", facilities: "机场深层防护", access: "机场大巴", description: "南通航空枢纽民防" }
        ]
    },
    "huizhou": {
        name: "惠州",
        center: [114.4168, 23.1115],
        shelters: [
            { id: "hz_001", name: "西湖东站地下避难所", type: "bunker", position: [114.4168, 23.0815], address: "惠州市惠城区西湖东站地铁站", capacity: "3000人", level: "核6级", facilities: "市中心深层民防", access: "莞惠城际西湖东站", description: "惠州城市核心防护" },
            { id: "hz_002", name: "平潭机场地下避难所", type: "shelter", position: [114.5368, 23.0515], address: "惠州市惠阳区平潭机场T2地下", capacity: "3000人", level: "核5级", facilities: "机场深层防护", access: "机场大巴/地铁(规划)", description: "惠州航空枢纽民防" }
        ]
    },
    "zhongshan": {
        name: "中山",
        center: [113.3927, 22.5176],
        shelters: [
            { id: "zs_001", name: "中山北站地下避难所", type: "bunker", position: [113.3927, 22.5476], address: "中山市石岐区中山北站地下", capacity: "3000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "广珠城际中山北站", description: "中山高铁枢纽民防" },
            { id: "zs_002", name: "兴中道地下人防", type: "shelter", position: [113.3627, 22.5176], address: "中山市东区兴中道地下", capacity: "2000人", level: "核6级", facilities: "市中心民防", access: "公交兴中体育场站", description: "中山市核心区防护" }
        ]
    },
    "zhuhai": {
        name: "珠海",
        center: [113.5767, 22.2707],
        shelters: [
            { id: "zh_001", name: "拱北口岸地下避难所", type: "bunker", position: [113.5567, 22.2207], address: "珠海市香洲区拱北口岸地下", capacity: "5000人", level: "核6级", facilities: "口岸深层民防设施", access: "广珠城际珠海站", description: "珠澳边境重要民防工程" },
            { id: "zh_002", name: "金湾机场地下避难所", type: "metro", position: [113.3767, 22.0107], address: "珠海市金湾区金湾机场T1地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "机场大巴/城际", description: "珠海航空枢纽民防" },
            { id: "zh_003", name: "横琴站地下避难所", type: "shelter", position: [113.5567, 22.1407], address: "珠海市横琴新区横琴站地下", capacity: "4000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "广珠城际横琴站", description: "横琴新区核心民防" }
        ]
    },
    "haikou": {
        name: "海口",
        center: [110.3492, 20.0174],
        shelters: [
            { id: "hk_001", name: "海口站地下避难所", type: "bunker", position: [110.1727, 20.0601], address: "海口市秀英区海口站地下", capacity: "4000人", level: "核6级", facilities: "铁路枢纽深层防护", access: "环岛高铁海口站", description: "海口火车站民防" },
            { id: "hk_002", name: "美兰机场地下避难所", type: "metro", position: [110.4627, 19.9401], address: "海口市美兰区美兰机场T1/T2地下", capacity: "5000人", level: "核5级", facilities: "机场深层防护", access: "环岛高铁美兰站/地铁", description: "海口航空枢纽民防" },
            { id: "hk_003", name: "骑楼老街地下人防", type: "shelter", position: [110.3527, 20.0501], address: "海口市龙华区骑楼老街地下", capacity: "2000人", level: "核6级", facilities: "老城区民防", access: "公交钟楼站", description: "海口老城核心防护" }
        ]
    },
    "urumqi": {
        name: "乌鲁木齐",
        center: [87.6168, 43.8256],
        shelters: [
            { id: "wlmq_001", name: "南门地下避难所", type: "bunker", position: [87.6168, 43.8256], address: "乌鲁木齐市天山区南门地铁站", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1号线南门站", description: "乌鲁木齐城市核心防护" },
            { id: "wlmq_002", name: "乌鲁木齐站地下避难所", type: "metro", position: [87.5768, 43.8656], address: "乌鲁木齐市头屯河区乌鲁木齐站地下", capacity: "5000人", level: "核6级", facilities: "高铁枢纽深层防护", access: "地铁1号线乌鲁木齐站", description: "乌鲁木齐高铁枢纽民防" },
            { id: "wlmq_003", name: "地窝堡机场地下避难所", type: "shelter", position: [87.4768, 43.9056], address: "乌鲁木齐市新市区地窝堡机场T1/T2/T3地下", capacity: "5000人", level: "核5级", facilities: "机场深层防护", access: "地铁1号线国际机场站", description: "乌鲁木齐航空枢纽民防" }
        ]
    },
    "hohhot": {
        name: "呼和浩特",
        center: [111.7492, 40.8426],
        shelters: [
            { id: "hhht_001", name: "新华广场地下避难所", type: "bunker", position: [111.7492, 40.8426], address: "呼和浩特市回民区新华广场地铁站", capacity: "4000人", level: "核6级", facilities: "市中心深层民防", access: "地铁1/2号线新华广场站", description: "呼和浩特城市核心防护" },
            { id: "hhht_002", name: "呼和浩特站地下避难所", type: "metro", position: [111.7092, 40.8226], address: "呼和浩特市新城区呼和浩特站地下", capacity: "4000人", level: "核6级", facilities: "铁路枢纽深层防护", access: "地铁2号线呼和浩特站", description: "呼和浩特火车站民防" },
            { id: "hhht_003", name: "白塔机场地下避难所", type: "shelter", position: [111.8292, 40.8626], address: "呼和浩特市赛罕区白塔机场T1/T2地下", capacity: "4000人", level: "核5级", facilities: "机场深层防护", access: "地铁1号线白塔西站", description: "呼和浩特航空枢纽民防" }
        ]
    }
};

// 城市列表数据（80个城市）
const CITIES_LIST = [
    // 一线城市
    { id: "beijing", name: "北京", count: 7, tier: 1 },
    { id: "shanghai", name: "上海", count: 7, tier: 1 },
    { id: "guangzhou", name: "广州", count: 5, tier: 1 },
    { id: "shenzhen", name: "深圳", count: 5, tier: 1 },
    // 新一线
    { id: "chengdu", name: "成都", count: 4, tier: 2 },
    { id: "chongqing", name: "重庆", count: 4, tier: 2 },
    { id: "wuhan", name: "武汉", count: 4, tier: 2 },
    { id: "xian", name: "西安", count: 4, tier: 2 },
    { id: "nanjing", name: "南京", count: 4, tier: 2 },
    { id: "hangzhou", name: "杭州", count: 4, tier: 2 },
    { id: "tianjin", name: "天津", count: 3, tier: 2 },
    { id: "zhengzhou", name: "郑州", count: 3, tier: 2 },
    { id: "changsha", name: "长沙", count: 3, tier: 2 },
    { id: "suzhou", name: "苏州", count: 3, tier: 2 },
    { id: "qingdao", name: "青岛", count: 3, tier: 2 },
    { id: "dongguan", name: "东莞", count: 2, tier: 2 },
    { id: "foshan", name: "佛山", count: 2, tier: 2 },
    // 二线城市
    { id: "shenyang", name: "沈阳", count: 3, tier: 3 },
    { id: "dalian", name: "大连", count: 3, tier: 3 },
    { id: "xiamen", name: "厦门", count: 3, tier: 3 },
    { id: "wuxi", name: "无锡", count: 2, tier: 3 },
    { id: "ningbo", name: "宁波", count: 3, tier: 3 },
    { id: "fuzhou", name: "福州", count: 3, tier: 3 },
    { id: "hefei", name: "合肥", count: 3, tier: 3 },
    { id: "shijiazhuang", name: "石家庄", count: 3, tier: 3 },
    { id: "kunming", name: "昆明", count: 3, tier: 3 },
    { id: "nanchang", name: "南昌", count: 3, tier: 3 },
    { id: "jinan", name: "济南", count: 3, tier: 3 },
    { id: "harbin", name: "哈尔滨", count: 3, tier: 3 },
    { id: "changchun", name: "长春", count: 3, tier: 3 },
    { id: "taiyuan", name: "太原", count: 3, tier: 3 },
    { id: "guiyang", name: "贵阳", count: 3, tier: 3 },
    { id: "nanning", name: "南宁", count: 3, tier: 3 },
    { id: "lanzhou", name: "兰州", count: 3, tier: 3 },
    { id: "wenzhou", name: "温州", count: 3, tier: 3 },
    { id: "changzhou", name: "常州", count: 2, tier: 3 },
    { id: "xuzhou", name: "徐州", count: 2, tier: 3 },
    { id: "nantong", name: "南通", count: 2, tier: 3 },
    { id: "huizhou", name: "惠州", count: 2, tier: 3 },
    { id: "zhongshan", name: "中山", count: 2, tier: 3 },
    { id: "zhuhai", name: "珠海", count: 3, tier: 3 },
    { id: "haikou", name: "海口", count: 3, tier: 3 },
    { id: "urumqi", name: "乌鲁木齐", count: 3, tier: 3 },
    { id: "hohhot", name: "呼和浩特", count: 3, tier: 3 }
];

// 统计数据计算
function calculateStats() {
    let totalBunkers = 0;
    let totalCapacity = 0;
    
    for (const cityId in SHELTER_DATA) {
        const city = SHELTER_DATA[cityId];
        totalBunkers += city.shelters.length;
        
        city.shelters.forEach(shelter => {
            const capacity = parseInt(shelter.capacity);
            if (!isNaN(capacity)) {
                totalCapacity += capacity;
            }
        });
    }
    
    return {
        totalBunkers,
        coveredCities: Object.keys(SHELTER_DATA).length,
        totalCapacity
    };
}

// 获取类型标签
function getTypeLabel(type) {
    const labels = {
        bunker: "核掩体",
        shelter: "人防工程",
        metro: "地铁/地下通道",
        civilian: "民用避难所"
    };
    return labels[type] || type;
}

// 获取类型颜色
function getTypeColor(type) {
    const colors = {
        bunker: "#ff4757",
        shelter: "#ffa502",
        metro: "#2ed573",
        civilian: "#1e90ff"
    };
    return colors[type] || "#ffffff";
}
