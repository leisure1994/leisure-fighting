# urhox-wuxia-combat

## UrhoX 武侠战斗系统

---

## 一、技能简介

**urhox-wuxia-combat** 是一套专为 UrhoX 引擎（兼容 Urho3D 及其衍生版本）打造的**武侠特化战斗系统**。它融合了现代动作游戏（Action Game）与格斗游戏（Fighting Game）的底层设计理念，以 Lua 脚本全栈实现，提供从输入缓冲、状态机驱动、碰撞框（Hitbox/Hurtbox）管理到伤害结算与受击反馈的完整链路。

无论是开发《只狼》风格的见招拆招、还是《金庸群侠传》式的武侠 RPG 战斗，本系统都能作为即插即用的底层框架。所有代码不依赖第三方二进制库，纯 Lua 编写，可直接嵌入 UrhoX/Love2D/任意 Lua 运行时中运行或移植。

---

## 二、适用场景

请在以下场景中使用本技能：

1. **UrhoX / Urho3D 武侠/仙侠动作游戏** 需要一套完整的近战战斗底层系统。
2. **需要实现“连招（Combo）”机制** 的项目——包括轻攻击三段连击、重击起手、特殊技取消等。
3. **需要精确的碰撞判定** ——如扇形剑气、直线突刺、球形气劲、矩形横扫等武侠招式范围。
4. **需要“霸体 / 格挡 / 弹反 / 闪避无敌帧”** 等高级动作游戏机制。
5. **需要输入缓冲（Input Buffer）** 来优化玩家按键手感，避免“按早了没反应”的糟糕体验。
6. **需要状态机（FSM）驱动角色动画与战斗逻辑** 的项目。
7. **需要在服务端跑战斗逻辑校验** 的联网游戏（Lua 代码可无缝迁移到服务端）。

---

## 三、触发关键词

如果你或你的团队成员在讨论中提到以下词汇，本技能会自动触发：

- `武侠战斗`、`wuxia combat`、`action combat`、`kungfu`
- `连招`、`combo`、`连击`、`三段攻击`
- `状态机`、`FSM`、`finite state machine`
- `Hitbox`、`Hurtbox`、`碰撞框`、`攻击判定`、`受击框`
- `输入缓冲`、`input buffer`、`指令记忆`
- `霸体`、`super armor`、`格挡`、`block`、`弹反`、`parry`
- `闪避无敌帧`、`dodge iframe`、`翻滚`
- `伤害结算`、`damage calculation`、`暴击`、`闪避`、`击退`
- `技能数据库`、`skill database`、`招式表`、`cooldown`

---

## 四、安装方式

### 4.1 作为 OpenClaw Skill 安装

将本技能解压或复制到 OpenClaw 技能目录：

```bash
# 假设 OpenClaw 技能目录为 ~/.openclaw/skills/
cp -r urhox-wuxia-combat ~/.openclaw/skills/
```

然后在对话中直接提及触发关键词即可使用。

### 4.2 手动集成到 UrhoX 项目

将本目录下的所有 `scripts/*.lua` 文件复制到你的项目 `scripts/` 目录中，并确保 Lua 的模块搜索路径（`package.path`）包含该目录。然后在你的入口脚本中：

```lua
local Combat = require("scripts/main")
```

### 4.3 文件清单

```
urhox-wuxia-combat/
├── scripts/
│   ├── main.lua              -- 入口与快速初始化工厂
│   ├── CombatUtils.lua       -- 向量/角度/表工具/安全节点操作
│   ├── ComboBuffer.lua       -- 输入缓冲与连招管理
│   ├── WuxiaFSM.lua          -- 武侠特化有限状态机
│   ├── HitboxManager.lua     -- 攻击框/受击框碰撞管理
│   ├── CombatDamage.lua      -- 伤害计算与命中反馈
│   └── SkillDatabase.lua     -- 技能配置数据库
└── game.json                 -- 技能元数据
```

---

## 五、文字版系统架构图

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Player Input Layer                          │
│    [键盘/手柄/触摸屏] -> PushLight/PushHeavy/PushDodge/PushBlock     │
└─────────────────────────────────┬───────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      ComboBuffer (输入缓冲层)                        │
│   - 缓冲时间窗口 (默认 0.25s)                                       │
│   - 连招序列记录 (Light1 -> Light2 -> Light3)                       │
│   - 连招窗口通知 (ComboWindow Open/Close)                           │
│   - 被击中断回调 (BreakCombo)                                       │
└─────────────────────────────────┬───────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    WuxiaFSM (武侠战斗状态机)                         │
│   ┌─────────┐    light_attack    ┌─────────┐    light_2    ┌──────┐│
│   │  idle   │ -----------------> │ light_1 │ ------------> │light_2│
│   └────┬────┘                    └────┬────┘               └──┬───┘│
│        │                               │                      │    │
│        │ heavy_attack                  │ combo window         │    │
│        ▼                               ▼                      ▼    │
│   ┌─────────┐                     ┌─────────┐              ┌──────┐│
│   │ heavy_1 │                     │  dodge  │              │block ││
│   └─────────┘                     └─────────┘              └──────┘│
│                                                                    │
│   状态优先级系统：idle(0) < dodge(5) < block(10) < light(15)      │
│                   < heavy(25) < special(35) < hit_stun(50)        │
│                   < knockdown(60) < super_armor(100)              │
└─────────────────────────────────┬───────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    SkillDatabase (技能数据库)                        │
│   - 平砍 / 连斩 / 收招 / 重劈 / 降龙掌 / 翻滚 / 格挡 / 弹反        │
│   - 每招配置：动画名、帧数据、hitbox 列表、伤害事件、消耗、CD      │
│   - 冷却与资源校验（体力 stamina、内力 internalForce）             │
└─────────────────────────────────┬───────────────────────────────────┘
                                  │
              ┌───────────────────┴───────────────────┐
              │                                       │
              ▼                                       ▼
┌─────────────────────────────┐           ┌─────────────────────────────┐
│      HitboxManager          │           │      CombatDamage           │
│  (攻击框 / 受击框管理器)    │           │   (伤害计算与命中反馈)      │
│                             │           │                             │
│  形状支持：                 │           │  - 攻防属性提取             │
│  - Sphere 球形 (气劲/掌风)  │           │  - 暴击/闪避/格挡判定       │
│  - Box 矩形 (剑气横扫)      │           │  - 元素克制矩阵             │
│  - Fan 扇形 (旋风腿)        │           │  - 受击反应：硬直/击退/击飞 │
│  - Line 直线 (突刺/枪法)    │           │  - 物理脉冲应用             │
│                             │           │  - 击杀回调                 │
│  特性：                     │           │                             │
│  - 友军伤害过滤             │           │                             │
│  - 多段命中 (DOT/持续伤害)  │           │                             │
│  - 命中去重                 │           │                             │
└─────────────────────────────┘           └─────────────────────────────┘
              │                                       │
              └───────────────────┬───────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                     输出到游戏表现层                                │
│   动画播放 / 粒子特效 / 音效 / 屏幕震动 / UI 飘字 / 物理击退       │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 六、开源调研分析

本技能的设计参考了多个开源项目与行业经典方案，以下是核心调研结论：

### 6.1 Fray (Godot 4 动作游戏插件)

**Fray** 是一款面向 Godot 4 的模块化动作游戏开发插件，提供了战斗状态管理、复杂输入检测、输入缓冲以及碰撞框组织。它将战斗系统拆分为独立的子模块：StateMachine（状态机）、InputBuffer（输入缓冲）、Hitbox（碰撞框集合）。

**借鉴点：**
- **输入缓冲的通用性**：不再将输入缓冲硬编码在玩家控制器中，而是抽象为独立的 `ComboBuffer` 类，任何需要连招的实体都可以挂载。
- **碰撞框的组织方式**：Fray 使用“碰撞框集合（Hitbox Builder）”来批量管理同一招式下的多个碰撞框。本技能的 `HitboxManager` 采用了类似思路，支持同一技能释放多个不同形状的 hitbox（如降龙掌同时释放球形气劲 + 直线掌风）。

### 6.2 DelayNoMore (开源联机平台跳跃动作游戏)

**DelayNoMore** 是由 genxium 开发的一款基于 WebSocket + GGPO 风格回滚网络代码（Rollback Netcode）的联机平台跳跃动作游戏。项目使用 CocosCreator + Golang 实现，核心亮点在于输入同步与延迟输入处理。

**借鉴点：**
- **输入缓冲与网络抖动的关系**：在网络对战或任何存在延迟的场景中，输入缓冲不仅能优化手感，还能掩盖网络波动。本技能的 `ComboBuffer` 保留了输入的“时间戳”，便于后续扩展为带延迟补偿的输入队列。
- **碰撞检测的高效性**：项目中的碰撞器可视化工具（`collider_visualizer`）证明了在动作游戏中，碰撞框必须是简单几何体（AABB、圆、胶囊体）而非复杂 Mesh。这与本技能 `HitboxManager` 中仅使用球/盒/扇/线四种基本形状的设计理念完全一致。

### 6.3 kys-cpp (《金庸群侠传》SDL2 开源重制版)

**kys-cpp** 是基于 SDL2 开发的《金庸群侠传》开源重制项目，保留了原版 DOS 资源，但用现代 C++ 重写了底层系统。作为一款经典武侠 RPG，它的战斗系统虽然偏回合制，但招式表、武功秘籍、伤害计算等设计极具武侠特色。

**借鉴点：**
- **武侠招式的“招式表”设计**：`SkillDatabase.lua` 中的“平砍、连斩、收招、重劈、降龙掌”等命名与数据结构设计参考了该类武侠游戏的技能配置思路——每门武功都有独立的动画、伤害、消耗、CD 与特效。
- ** Lua 生态的亲和力**：原版项目使用 C++，但本技能将其设计理念迁移到纯 Lua 环境中，使得在 UrhoX 这种支持 Lua 绑定的引擎里可以快速落地。

### 6.4 云风博客《动作游戏中的击打判定》

云风（吴云洋，网易前核心程序员，《大话西游》引擎作者）在这篇博客中详细分析了 2D 格斗游戏与 3D 动作游戏的碰撞判定差异。

**核心观点：**
- **2D 格斗**：几乎 universally 使用 AABB（轴对齐矩形）作为 hitbox/hurtbox。代表作如《Street Fighter V》。
- **3D FPS**：使用绑定在骨骼上的 Cuboid（立方体）或 Capsule（胶囊体）作为 hitbox，子弹轨迹简化为线段求交。
- **3D 动作游戏（如怪物猎人）**：建议使用空间四边形或绑定在骨骼/武器上的 OBB（定向包围盒）来模拟刀剑挥砍轨迹。

**对本技能的直接影响：**
- `HitboxManager` 中实现了 **Sphere（球）、Box（OBB 矩形）、Fan（扇形）、Line（线段/圆柱）** 四种形状，覆盖了武侠游戏中常见的拳掌、剑气、突刺、横扫等攻击类型。
- 扇形与直线碰撞检测是格斗游戏中圆形/线段检测的 3D 延伸，计算量可控，精确度足够支持快节奏战斗。

### 6.5 蔚蓝 (Celeste) 开源参考 —— 输入缓冲与土狼时间

《蔚蓝》是平台跳跃游戏中手感调校的巅峰之作。其在 GitHub 上开源的部分代码展示了“输入缓冲（Input Buffer）”和“土狼时间（Coyote Time）”的实现。

**借鉴点：**
- **`ComboBuffer` 的缓冲机制**：与蔚蓝的跳跃缓冲类似，玩家的按键输入在短时间窗口内会被保留。如果角色在按键后 0.25 秒内进入可接受该输入的状态（如连招窗口打开、从硬直恢复），输入会自动触发。这极大地降低了“按早了没反应”的挫败感。
- **连招计时器**：蔚蓝在玩家离地的几帧内仍允许起跳；本技能的 `ComboBuffer` 则设置了 `comboMaxInterval`（默认 1.0 秒），如果玩家在两段连击之间间隔过长，连击数会自动归零。

### 6.6 lua-state-machine (kyleconroy)

本技能的 `WuxiaFSM` 底层状态切换逻辑参考了 `kyleconroy/lua-state-machine` 这一广泛使用的 Lua FSM 库。

**借鉴点：**
- **事件驱动的状态转换**：通过 `events = { {name="light_attack", from="idle", to="light_1"} }` 这样的声明式配置来定义状态机，而非大量 if-else。
- **异步状态切换支持**：原库支持 `async` 模式，允许在 `onleave` 或 `onenter` 回调中延迟状态切换。本技能保留了这一机制，使得在动画过渡 Blend 期间可以优雅地完成状态转移。

---

## 七、核心 API 文档

### 7.1 快速入口：main.lua

```lua
local Combat = require("scripts/main")

-- 快速创建一套完整的武侠战斗组件
local combatSys = Combat.CreateCombatSystem(playerNode)

-- 在你的 Update 循环中调用
function Update(timeStep)
    combatSys:Update(timeStep)
end

-- 绑定输入
function HandleInput()
    if input:GetKeyDown(KEY_Q) then
        combatSys.combo:PushLight()
    end
    if input:GetKeyDown(KEY_E) then
        combatSys.combo:PushHeavy()
    end
    if input:GetKeyDown(KEY_SPACE) then
        combatSys.combo:PushDodge()
    end
    if input:GetKeyDown(KEY_R) then
        combatSys.combo:PushBlock()
    end
    if input:GetKeyDown(KEY_F) then
        combatSys.combo:PushParry()
    end
end
```

---

### 7.2 CombatUtils.lua —— 公共工具库

```lua
local Utils = require("scripts/CombatUtils")

-- 标量运算
Utils.Lerp(a, b, t)                 -- 线性插值
Utils.Clamp(value, min, max)        -- 值限制
Utils.NormalizeAngle(angle)         -- 规范化角度到 [-180, 180]
Utils.AngleDifference(a, b)         -- 两角度最短差值
Utils.ExpDecay(current, target, decay, dt)  -- 指数衰减平滑

-- 三维向量运算
local v = Utils.Vec3(1, 2, 3)
local v2 = Utils.Vec3Add(v, {x=1,y=0,z=0})
local len = Utils.Vec3Length(v2)
local dir = Utils.Vec3Normalize(v2)
local yaw = Utils.CalcYawToTarget(origin, target)

-- 表工具
local copy = Utils.DeepCopy(originalTable)
local item = Utils.WeightedRandomChoice({{item="sword", weight=10}, {item="fist", weight=5}})
local has = Utils.TableContains(arr, value)
local ok = Utils.TableRemoveValue(arr, value)

-- 安全节点操作（兼容 Urho3D Node 或纯 Lua 表）
local pos = Utils.GetNodeWorldPosition(node)
Utils.ApplyImpulseSafe(node, {x=0,y=10,z=0})          -- 应用物理脉冲
Utils.PlayAnimationSafe(node, "anim_attack", false)   -- 播放动画
Utils.SetNodeYawSafe(node, 45.0)                      -- 设置朝向
```

---

### 7.3 ComboBuffer.lua —— 连招输入缓冲器

```lua
local ComboBuffer = require("scripts/ComboBuffer").ComboBuffer

-- 创建缓冲器（owner 为战斗组件/玩家节点，fsm 为 WuxiaStateMachine 实例）
local combo = ComboBuffer.New(owner, fsm)

-- 设置参数
combo:SetParams(bufferTime, chainTolerance, maxBufferCount)
combo:SetComboMaxInterval(interval)

-- 推送输入
combo:PushLight()
combo:PushHeavy()
combo:PushDodge()
combo:PushBlock()
combo:PushSpecial()
combo:PushParry()

-- 连招窗口通知（通常由动画回调调用）
combo:NotifyComboWindow(true)   -- 打开窗口
combo:NotifyComboWindow(false)  -- 关闭窗口

-- 中断与清理
combo:BreakCombo()   -- 被击飞时调用
combo:Clear()        -- 清空缓冲区

-- 每帧更新
combo:Update(dt)

-- 查询状态
local count = combo:GetComboCount()
local sequence = combo:GetSequence()
local pending = combo:HasPendingInput("light")

-- 回调
combo:SetOnComboAdvance(function(owner, comboCount, eventName, inputEntry)
    print("连击推进到第 " .. comboCount .. " 段，事件：" .. eventName)
end)
combo:SetOnComboBreak(function(owner)
    print("连招中断")
end)
```

---

### 7.4 WuxiaFSM.lua —— 武侠有限状态机

```lua
local WuxiaFSM = require("scripts/WuxiaFSM")

-- 使用预置的标准武侠配置
local config = WuxiaFSM.CreateStandardWuxiaConfig()

-- 扩展回调（在配置阶段注入）
config.callbacks.onenterlight_1 = function(self, event, from, to)
    print("进入轻攻击第一段")
    -- 播放动画、生成 hitbox
end

config.callbacks.onhittaken = function(self, damageEvent)
    print("受到伤害：" .. damageEvent.damage)
end

-- 创建状态机
local fsm = WuxiaFSM.New(playerNode, config)

-- 状态查询
local isIdle = fsm:Is("idle")
local canAttack = fsm:Can("light_attack")

-- 触发事件
fsm:light_attack()     -- 轻攻击
fsm:light_2()          -- 轻攻击第二段
fsm:light_3()          -- 轻攻击第三段
fsm:heavy_attack()     -- 重击
fsm:special_attack()   -- 特殊技
fsm:dodge()            -- 闪避
fsm:block()            -- 格挡
fsm:parry()            -- 弹反
fsm:hitstun_event()    -- 进入受击硬直
fsm:knockdown_event()  -- 进入击倒
fsm:getup()            -- 起身
fsm:force_idle()       -- 强制回到 idle

-- 连招窗口与霸体控制
fsm:OpenComboWindow(0.3, true)   -- 开放 0.3 秒连招窗口，允许取消
fsm:CloseComboWindow()
fsm:EnableSuperArmor()
fsm:DisableSuperArmor()
fsm:SetStateMaxTime(1.5)         -- 状态最大持续时间，超时自动回 idle

-- 受击判定
local wasHit = fsm:TakeHit({
    damage = 25,
    interruptLevel = 20,
    knockdown = false,
    blockable = true,
})

-- 打断能力查询
local canInterrupt = fsm:CanBeInterrupted(30)

-- 调试
fsm:ToDot("wuxia_fsm.dot")
local debugInfo = fsm:GetDebugInfo()
```

---

### 7.5 HitboxManager.lua —— 碰撞框管理器

```lua
local HM = require("scripts/HitboxManager")
local mgr = HM.HitboxManager.New()

-- 注册角色的受击框（Hurtbox）
local hurtboxId = mgr:RegisterHurtbox(playerNode, radius, HM.HURTBOX_LAYER_PLAYER, {x=0,y=1,z=0})
mgr:SetHurtboxActive(hurtboxId, false)  -- 临时禁用
mgr:UnregisterHurtbox(hurtboxId)

-- 生成攻击框（Hitbox）
-- 球形：拳掌、气劲
local hitbox1 = mgr:SpawnSphereHitbox(
    ownerNode,
    {x=0, y=1.2, z=3.0},
    3.5,                                    -- 半径
    { baseDamage=80, damageType="internal" },
    0.35,                                   -- 存活时间
    8                                       -- 最大命中数
)

-- 矩形：剑气横扫
local hitbox2 = mgr:SpawnBoxHitbox(
    ownerNode,
    {x=0, y=1.0, z=1.5},
    {x=1.0, y=1.2, z=1.8},                  -- halfSize
    0.0,                                    -- yaw 朝向
    { baseDamage=45, damageType="physical" },
    0.25,
    4
)

-- 扇形：旋风腿
local hitbox3 = mgr:SpawnFanHitbox(
    ownerNode,
    {x=0, y=1.0, z=0},
    2.5,                                    -- 半径
    120.0,                                  -- 张角
    0.0,
    { baseDamage=20 },
    0.2,
    5
)

-- 直线：突刺、枪法
local hitbox4 = mgr:SpawnLineHitbox(
    ownerNode,
    {x=0, y=1.0, z=1.0},
    {x=0, y=0, z=1},                        -- 方向
    5.0,                                    -- 长度
    0.5,                                    -- 粗细
    { baseDamage=30 },
    0.2,
    3
)

-- 设置多段命中（如持续燃烧）
mgr:SetHitboxMultiHit(hitbox1, 0.2)

-- 立即销毁
mgr:DespawnHitbox(hitbox1)

-- 每帧更新（在 onHit 回调中处理命中事件）
mgr:Update(dt, function(hitbox, hurtbox, damageEvent)
    print("命中目标！")
end)

-- 场景切换时清理
mgr:ClearHitboxes()
mgr:ClearHurtboxes()
```

---

### 7.6 CombatDamage.lua —— 伤害计算与命中结算

```lua
local CD = require("scripts/CombatDamage")

-- 快速创建属性表
local attrs = CD.CreateAttributes({
    attack = 50,
    defense = 20,
    maxHealth = 200,
    critRate = 0.15,
    critDamage = 1.8,
    dodgeRate = 0.05,
    resistance = 0.1,
    element = CD.ELEMENT_FIRE,
})

-- 独立使用伤害计算器
local calc = CD.DamageCalculator.New()
local result = calc:Calculate(attackerAttrs, defenderAttrs, 30, CD.DAMAGE_TYPE_PHYSICAL, CD.ELEMENT_FIRE)
-- result 包含：finalDamage, isCrit, isDodged, reaction

-- 战斗结算执行器（绑定 HitboxManager + FSM）
local dealer = CD.CombatDealer.New(hitboxManager, fsm)

-- 设置回调
dealer:SetOnHit(function(attacker, target, result, damageEvent)
    print("命中！伤害：" .. result.finalDamage .. " 暴击：" .. tostring(result.isCrit))
end)
dealer:SetOnKill(function(attacker, target, damageEvent)
    print("击杀！")
end)
dealer:SetOnDodge(function(attacker, target, damageEvent)
    print("目标闪避！")
end)

-- 自动命中检测（推荐在 Update 中调用）
dealer:Update(dt)

-- 手动执行一次命中（非自动模式）
dealer:ApplyHit(hitbox, hurtbox, damageEvent)
```

---

### 7.7 SkillDatabase.lua —— 技能数据库

```lua
local SD = require("scripts/SkillDatabase")
local db = SD.SkillDatabase.New()

-- 读取预设技能
local skill = db:GetSkill(SD.SKILL_ID_LIGHT_1)
-- skill 包含：id, name, animation, stateName, totalFrames, startupFrames,
-- activeFrames, recoveryFrames, comboWindowOpenFrame, comboWindowCloseFrame,
-- cancelable, hitboxList, damageEvent, cooldown, cost, priority

-- 检查冷却与资源
local canUse, reason = db:CanAfford(playerNode, SD.SKILL_ID_SPECIAL_DRAGON_PALM)
local onCd = db:IsOnCooldown(playerId, SD.SKILL_ID_SPECIAL_DRAGON_PALM)
local remain = db:GetCooldownRemain(playerId, SD.SKILL_ID_SPECIAL_DRAGON_PALM)

-- 使用技能
db:ConsumeCost(playerNode, SD.SKILL_ID_SPECIAL_DRAGON_PALM)
db:StartCooldown(playerId, SD.SKILL_ID_SPECIAL_DRAGON_PALM)

-- 每帧更新（递减冷却）
db:Update(dt)

-- 注册自定义技能
db:RegisterSkill({
    id = "custom_sword",
    name = "自定义剑法",
    animation = "anim_custom_sword",
    stateName = "custom_sword",
    totalFrames = 40,
    hitboxList = {
        { shape = "fan", offset = {x=0,y=1,z=1.5}, params = {radius=3.0, angleSpan=90}, lifetime = 0.2, maxHits = 5 }
    },
    damageEvent = {
        baseDamage = 35,
        damageType = "physical",
        interruptLevel = 25,
        reaction = "knockback",
        knockbackForce = 10,
    },
    cooldown = 3.0,
    cost = { stamina = 15 },
    priority = 25,
})
```

---

## 八、完整代码示例：从零搭建一个可操控的武侠角色

以下示例展示如何在一个 UrhoX/Lua 项目中使用本战斗系统构建一个完整的玩家角色。

```lua
-- PlayerCombat.lua
-- 一个完整的玩家战斗组件示例

local Combat      = require("scripts/main")
local Utils       = require("scripts/CombatUtils")
local ComboBuffer = require("scripts/ComboBuffer").ComboBuffer
local WuxiaFSM    = require("scripts/WuxiaFSM")
local HM          = require("scripts/HitboxManager")
local CD          = require("scripts/CombatDamage")
local SD          = require("scripts/SkillDatabase")

local PlayerCombat = {}
PlayerCombat.__index = PlayerCombat

--- 创建玩家战斗组件
function PlayerCombat.New(node)
    local self = setmetatable({}, PlayerCombat)
    self.node = node

    -- 1. 初始化战斗属性
    self.node.combatAttrs = CD.CreateAttributes({
        attack = 30,
        defense = 10,
        maxHealth = 150,
        critRate = 0.1,
        dodgeRate = 0.03,
    })
    self.node.health = self.node.combatAttrs.maxHealth
    self.node.stamina = 100
    self.node.internalForce = 50

    -- 2. 创建状态机
    local config = WuxiaFSM.CreateStandardWuxiaConfig()
    config.callbacks.onenterlight_1 = function(_, event, from, to)
        self:PlaySkillAnimation(SD.SKILL_ID_LIGHT_1)
    end
    config.callbacks.onenterlight_2 = function(_, event, from, to)
        self:PlaySkillAnimation(SD.SKILL_ID_LIGHT_2)
    end
    config.callbacks.onenterlight_3 = function(_, event, from, to)
        self:PlaySkillAnimation(SD.SKILL_ID_LIGHT_3)
    end
    config.callbacks.onenterheavy_1 = function(_, event, from, to)
        self:PlaySkillAnimation(SD.SKILL_ID_HEAVY_1)
    end
    config.callbacks.onenterdodge = function(_, event, from, to)
        self:PlaySkillAnimation(SD.SKILL_ID_DODGE)
    end
    config.callbacks.onenterblock = function(_, event, from, to)
        self:PlaySkillAnimation(SD.SKILL_ID_BLOCK)
    end
    config.callbacks.onhittaken = function(_, damageEvent)
        print(self.node:GetName() .. " 受击，伤害：" .. damageEvent.damage)
    end
    self.fsm = WuxiaFSM.New(node, config)
    self.node.wuxiaFSM = self.fsm

    -- 3. 创建输入缓冲器
    self.combo = ComboBuffer.New(self, self.fsm)
    self.combo:SetParams(0.25, 0.15, 3)
    self.combo:SetOnComboAdvance(function(owner, count, eventName)
        print("连击 x" .. count .. " (" .. eventName .. ")")
    end)

    -- 4. 创建碰撞管理器
    self.hitboxMgr = HM.HitboxManager.New()
    self.hurtboxId = self.hitboxMgr:RegisterHurtbox(node, 0.6, HM.HURTBOX_LAYER_PLAYER, {x=0,y=0.9,z=0})

    -- 5. 创建伤害结算器
    self.dealer = CD.CombatDealer.New(self.hitboxMgr, self.fsm)
    self.dealer:SetOnHit(function(attacker, target, result, evt)
        print("命中 " .. target:GetName() .. " 造成 " .. result.finalDamage .. " 点伤害")
    end)

    -- 6. 技能数据库
    self.skillDb = SD.SkillDatabase.New()

    return self
end

--- 播放技能动画并生成 Hitbox
function PlayerCombat:PlaySkillAnimation(skillId)
    local skill = self.skillDb:GetSkill(skillId)
    if not skill then return end

    -- 播放动画
    Utils.PlayAnimationSafe(self.node, skill.animation, false)

    -- 设置状态超时（自动回到 idle）
    local totalTime = skill.totalFrames / 60.0
    self.fsm:SetStateMaxTime(totalTime + 0.5)

    -- 连招窗口
    if skill.comboWindowOpenFrame > 0 then
        local openTime = skill.comboWindowOpenFrame / 60.0
        local duration = (skill.comboWindowCloseFrame - skill.comboWindowOpenFrame) / 60.0
        -- 这里简化处理：直接打开窗口；实际项目中建议在动画回调的精确帧触发
        self.fsm:OpenComboWindow(duration, skill.cancelable)
        self.combo:NotifyComboWindow(true)
    else
        self.combo:NotifyComboWindow(false)
    end

    -- 生成 Hitbox（在 activeFrames 开始时生成）
    -- 实际项目中应使用动画事件精确触发；此处用简化延迟模拟
    local startupTime = skill.startupFrames / 60.0
    local activeTime = skill.activeFrames / 60.0

    -- 使用一个简化的延迟生成逻辑（真实项目请使用动画事件系统）
    self.pendingHitbox = {
        spawnAt = startupTime,
        despawnAt = startupTime + activeTime,
        skill = skill,
    }
end

--- 处理原始输入（由外部按键系统调用）
function PlayerCombat:HandleInput(inputType)
    if inputType == "light" then
        self.combo:PushLight()
    elseif inputType == "heavy" then
        self.combo:PushHeavy()
    elseif inputType == "dodge" then
        self.combo:PushDodge()
    elseif inputType == "block" then
        self.combo:PushBlock()
    elseif inputType == "parry" then
        self.combo:PushParry()
    elseif inputType == "special" then
        self.combo:PushSpecial()
    end
end

--- 更新循环
function PlayerCombat:Update(dt)
    -- 更新子系统
    self.fsm:Update(dt)
    self.combo:Update(dt)
    self.skillDb:Update(dt)
    self.dealer:Update(dt)
    self.hitboxMgr:Update(dt)

    -- 处理待生成的 hitbox（简化版帧事件模拟）
    if self.pendingHitbox then
        self.pendingHitbox.spawnAt = self.pendingHitbox.spawnAt - dt
        self.pendingHitbox.despawnAt = self.pendingHitbox.despawnAt - dt

        if self.pendingHitbox.spawnAt <= 0 then
            self:SpawnSkillHitboxes(self.pendingHitbox.skill)
            self.pendingHitbox.spawnAt = math.huge
        end

        if self.pendingHitbox.despawnAt <= 0 then
            self.hitboxMgr:ClearHitboxes()
            self.pendingHitbox = nil
        end
    end
end

--- 为当前技能生成碰撞框
function PlayerCombat:SpawnSkillHitboxes(skill)
    local ownerPos = Utils.GetNodeWorldPosition(self.node)
    local yaw = 0.0
    if type(self.node.GetRotation) == "function" then
        yaw = self.node:GetRotation().yaw or 0.0
    end

    for _, hb in ipairs(skill.hitboxList or {}) do
        local center = Utils.Vec3Add(ownerPos, hb.offset)
        if hb.shape == HM.HITBOX_SHAPE_SPHERE then
            self.hitboxMgr:SpawnSphereHitbox(self.node, center, hb.params.radius, skill.damageEvent, hb.lifetime, hb.maxHits)
        elseif hb.shape == HM.HITBOX_SHAPE_BOX then
            self.hitboxMgr:SpawnBoxHitbox(self.node, center, hb.params.halfSize, yaw + (hb.params.yawOffset or 0), skill.damageEvent, hb.lifetime, hb.maxHits)
        elseif hb.shape == HM.HITBOX_SHAPE_FAN then
            self.hitboxMgr:SpawnFanHitbox(self.node, center, hb.params.radius, hb.params.angleSpan, yaw + (hb.params.yawOffset or 0), skill.damageEvent, hb.lifetime, hb.maxHits)
        elseif hb.shape == HM.HITBOX_SHAPE_LINE then
            local forward = Utils.Vec3Normalize({x=math.sin(math.rad(yaw)), y=0, z=math.cos(math.rad(yaw))})
            local startPos = Utils.Vec3Add(ownerPos, hb.offset)
            self.hitboxMgr:SpawnLineHitbox(self.node, startPos, forward, hb.params.length, hb.params.thickness, skill.damageEvent, hb.lifetime, hb.maxHits)
        end
    end
end

--- 被外部攻击命中（非 hitbox 流程，如陷阱/范围 AOE）
function PlayerCombat:TakeHit(damageEvent)
    return self.fsm:TakeHit(damageEvent)
end

--- 获取调试信息
function PlayerCombat:GetDebugInfo()
    return {
        fsm = self.fsm:GetDebugInfo(),
        comboCount = self.combo:GetComboCount(),
        health = self.node.health,
        stamina = self.node.stamina,
    }
end

return PlayerCombat
```

### 使用上述组件的入口示例

```lua
-- main.lua (项目级别)
local PlayerCombat = require("PlayerCombat")

-- 假设 scene 中已有一个名为 "Player" 的节点
local playerNode = scene:GetChild("Player", true)
local combat = PlayerCombat.New(playerNode)

-- 在主循环中更新
function Update(timeStep)
    combat:Update(timeStep)

    -- 按键映射（示例）
    if input:GetKeyPress(KEY_Q) then combat:HandleInput("light") end
    if input:GetKeyPress(KEY_W) then combat:HandleInput("heavy") end
    if input:GetKeyPress(KEY_E) then combat:HandleInput("dodge") end
    if input:GetKeyPress(KEY_R) then combat:HandleInput("block") end
    if input:GetKeyPress(KEY_T) then combat:HandleInput("parry") end
    if input:GetKeyPress(KEY_Y) then combat:HandleInput("special") end
end
```

---

## 九、设计理念与最佳实践

### 9.1 输入缓冲：让连招更“跟手”

在动作游戏中，玩家最大的挫败感来源之一是“我明明按了，但他没出招”。这通常发生在：
- 玩家在前一招的收招硬直中提前按下了下一段攻击。
- 玩家的输入时机比连招窗口早了 1~3 帧。

`ComboBuffer` 的解决方案是在玩家按下按键时，不直接要求状态机立即响应，而是将输入放入一个**时间优先队列**。在接下来的一段窗口期（默认 0.25 秒）内，只要状态机进入可接受该输入的状态，缓冲的输入就会自动触发。

### 9.2 状态优先级：武侠战斗的“见招拆招”

`WuxiaFSM` 引入了状态优先级的概念。低优先级状态无法主动切换到高优先级状态（除非满足特定条件如霸体、取消窗口）。这意味着：
- 普通轻攻击无法打断敌人的重击蓄力。
- 但如果在敌人轻攻击的收招硬直中成功格挡并弹反，你可以将他打入硬直。
- 霸体（Super Armor）状态优先级为 100，只有优先级 ≥ 100 的攻击（如抓取、击倒）才能打断。

### 9.3 Hitbox 形状选择指南

| 形状 | 适用招式 | 计算复杂度 |
|------|---------|-----------|
| Sphere | 拳掌、气劲、范围爆炸 | 低 |
| Box | 剑气横扫、刀光矩形斩 | 中 |
| Fan | 旋风腿、横扫千军、拔刀斩 | 中 |
| Line | 突刺、枪法、直线剑气 | 低 |

在 3D 武侠游戏中，不建议使用 Mesh 碰撞来做战斗判定。始终使用简化的几何体——这不仅性能更优，也能让设计师精确控制每招的判定范围。

### 9.4 伤害公式的扩展性

`DamageCalculator` 内置了防御减伤、暴击、元素克制等基础机制。公式设计参考了 RPG 与动作游戏的折中方案：

```
减伤率 = defense / (defense + defenseFactor)
最终伤害 = (baseDamage + attack) * (1 - 减伤率) * 元素倍率 * 暴击倍率 * (1 - resistance)
```

`defenseFactor` 默认为 100，这意味着当防御 = 100 时减伤 50%，防御 = 200 时减伤 66.7%。这种公式保证了后期数值增长时的收益递减，是 RPG 中常用的“软上限”设计。

### 9.5 动画事件与代码驱动的平衡

本技能的代码示例中采用了“代码驱动 Hitbox 生成”的简化方案（通过帧数换算时间延迟）。在真实商业化项目中，强烈建议为动画系统添加**动画事件（Animation Event）**支持：
- 在动画的第 N 帧触发 `OpenComboWindow`。
- 在动画的 active frame 开始时触发 `SpawnHitbox`。
- 在动画结束时触发 `ForceIdle` 或 `CloseComboWindow`。

Urho3D 的 `AnimationController` 支持自定义动画触发器（通过 `SetAnimation` 的关键帧事件），可以将这些回调直接绑定到 `WuxiaFSM` 和 `ComboBuffer` 上。

---

## 十、开源参考链接

1. **Fray (Godot 4 Action Game Plugin)**
   - 搜索关键词：`fray godot combat plugin`
   - 提供了输入缓冲、状态机、碰撞框管理的模块化实现，是 Godot 生态中最接近本技能设计思路的项目。

2. **DelayNoMore (Rollback Netcode Platformer)**
   - GitHub: `https://github.com/genxium/DelayNoMore`
   - 开源联机平台跳跃动作游戏，展示输入同步、回滚网络代码与碰撞检测的结合。

3. **kys-cpp (金庸群侠传 SDL2 开源重制版)**
   - GitHub: `https://github.com/sxhmxdlvr/kys-cpp`
   - 经典武侠 RPG 战斗系统的现代开源实现，提供了丰富的招式表设计参考。

4. **lua-state-machine**
   - GitHub: `https://github.com/kyleconroy/lua-state-machine`
   - Lua 有限状态机库，本技能 `WuxiaFSM` 的状态切换逻辑参考了其事件驱动与异步切换设计。

5. **云风博客：动作游戏中的击打判定**
   - URL: `https://blog.codingnow.com/2018/09/hitbox_hurtbox.html`
   - 详细分析了 2D 格斗与 3D 动作游戏中 Hitbox/Hurtbox 的设计差异与数学原理。

6. **Celeste 输入缓冲与土狼时间参考**
   - 搜索关键词：`celeste coyote time input buffer github`
   - 平台跳跃游戏中手感调校的经典教材，其输入缓冲逻辑直接启发了 `ComboBuffer` 的设计。

---

## 十一、版本与维护

- **版本**: 1.0.0
- **最低引擎版本**: UrhoX 1.0.0 / Urho3D 1.7+
- **语言**: Lua 5.1 / LuaJIT / Lua 5.3+
- **License**: 本 Skill 代码遵循 MIT 协议，可自由用于商业与非商业项目。

---

## 十二、快速速查表

| 需求 | 调用方式 |
|------|---------|
| 初始化完整战斗系统 | `Combat.CreateCombatSystem(node)` |
| 推送轻攻击 | `combo:PushLight()` |
| 推送重攻击 | `combo:PushHeavy()` |
| 推送闪避 | `combo:PushDodge()` |
| 推送格挡 | `combo:PushBlock()` |
| 推送弹反 | `combo:PushParry()` |
| 打开连招窗口 | `fsm:OpenComboWindow(duration, allowCancel)` |
| 开启霸体 | `fsm:EnableSuperArmor()` |
| 注册受击框 | `mgr:RegisterHurtbox(node, radius, layer, offset)` |
| 生成球形攻击框 | `mgr:SpawnSphereHitbox(...)` |
| 生成矩形攻击框 | `mgr:SpawnBoxHitbox(...)` |
| 生成扇形攻击框 | `mgr:SpawnFanHitbox(...)` |
| 生成直线攻击框 | `mgr:SpawnLineHitbox(...)` |
| 执行自动命中检测 | `dealer:Update(dt)` |
| 检查技能是否在 CD | `db:IsOnCooldown(ownerId, skillId)` |
| 检查资源是否足够 | `db:CanAfford(owner, skillId)` |

---

*愿你的剑所到之处，皆能判定命中。*
