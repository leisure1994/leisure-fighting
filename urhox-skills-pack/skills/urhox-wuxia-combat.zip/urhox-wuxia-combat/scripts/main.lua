-- urhox-wuxia-combat
-- UrhoX 武侠战斗系统统一入口
-- 整合状态机、输入缓冲、碰撞框、伤害结算与技能数据库

local CombatUtils = require("scripts/CombatUtils")
local WuxiaFSM = require("scripts/WuxiaFSM")
local ComboBuffer = require("scripts/ComboBuffer")
local HitboxManager = require("scripts/HitboxManager")
local CombatDamage = require("scripts/CombatDamage")
local SkillDatabase = require("scripts/SkillDatabase")

local M = {}

-- 暴露子模块
M.CombatUtils = CombatUtils
M.WuxiaFSM = WuxiaFSM
M.ComboBuffer = ComboBuffer
M.HitboxManager = HitboxManager
M.CombatDamage = CombatDamage
M.SkillDatabase = SkillDatabase

-- ============================================================================
-- 快速工厂方法
-- ============================================================================

--- 创建武侠状态机实例
-- @param owner any 战斗单元引用
-- @param config table|nil 自定义配置，若 nil 则使用标准武侠配置
-- @return WuxiaStateMachine
function M.CreateFSM(owner, config)
    config = config or WuxiaFSM.CreateStandardWuxiaConfig()
    return WuxiaFSM.WuxiaStateMachine.New(owner, config)
end

--- 创建连招输入缓冲器
-- @param owner any
-- @param fsm WuxiaStateMachine
-- @return ComboBuffer
function M.CreateComboBuffer(owner, fsm)
    return ComboBuffer.ComboBuffer.New(owner, fsm)
end

--- 创建碰撞框管理器
-- @return HitboxManager
function M.CreateHitboxManager()
    return HitboxManager.HitboxManager.New()
end

--- 创建战斗结算执行器
-- @param hitboxManager HitboxManager
-- @param fsm WuxiaStateMachine|nil
-- @return CombatDealer
function M.CreateCombatDealer(hitboxManager, fsm)
    return CombatDamage.CombatDealer.New(hitboxManager, fsm)
end

--- 创建技能数据库
-- @return SkillDatabase
function M.CreateSkillDatabase()
    return SkillDatabase.SkillDatabase.New()
end

--- 快速构建战斗属性表
-- @param opts table|nil
-- @return table
function M.CreateAttributes(opts)
    return CombatDamage.CreateAttributes(opts)
end

-- ============================================================================
-- 高级封装：武侠战斗单元（WuxiaCombatUnit）
-- ============================================================================

local WuxiaCombatUnit = {}
WuxiaCombatUnit.__index = WuxiaCombatUnit

--- 创建一个可直接挂载到玩家/敌人节点上的武侠战斗单元
-- @param ownerNode Node 拥有者节点
-- @param hitboxManager HitboxManager 全局或局部的碰撞框管理器
-- @return WuxiaCombatUnit
function WuxiaCombatUnit.New(ownerNode, hitboxManager)
    local self = setmetatable({}, WuxiaCombatUnit)
    self.owner = ownerNode
    self.fsm = M.CreateFSM(ownerNode)
    self.combo = M.CreateComboBuffer(ownerNode, self.fsm)
    self.hitboxManager = hitboxManager or M.CreateHitboxManager()
    self.dealer = M.CreateCombatDealer(self.hitboxManager, self.fsm)
    self.skillDb = M.CreateSkillDatabase()
    self.currentSkill = nil
    self.skillTimer = 0.0
    self.hurtboxId = nil
    self.activeHitboxes = {}
    self.destroyOnDeath = true
    return self
end

--- 为战斗单元注册 Hurtbox
-- @param radius number
-- @param layer number
-- @param offset table|nil
function WuxiaCombatUnit:RegisterHurtbox(radius, layer, offset)
    self.hurtboxId = self.hitboxManager:RegisterHurtbox(self.owner, radius, layer, offset)
end

--- 设置技能数据库（通常多个单元共享同一个全局数据库）
-- @param db SkillDatabase
function WuxiaCombatUnit:SetSkillDatabase(db)
    self.skillDb = db
end

--- 设置受击与击杀回调
-- @param onHit function(attacker, target, result, damageEvent)
-- @param onKill function(attacker, target, damageEvent)
function WuxiaCombatUnit:SetCallbacks(onHit, onKill)
    self.dealer:SetOnHit(onHit)
    self.dealer:SetOnKill(onKill)
end

--- 绑定按键输入（应在 HandleKeyDown / Input 事件处理器中调用）
-- @param inputType string
function WuxiaCombatUnit:OnInput(inputType)
    if inputType == ComboBuffer.INPUT_LIGHT then
        self.combo:PushLight()
    elseif inputType == ComboBuffer.INPUT_HEAVY then
        self.combo:PushHeavy()
    elseif inputType == ComboBuffer.INPUT_DODGE then
        self.combo:PushDodge()
    elseif inputType == ComboBuffer.INPUT_BLOCK then
        self.combo:PushBlock()
    elseif inputType == ComboBuffer.INPUT_SPECIAL then
        self.combo:PushSpecial()
    elseif inputType == ComboBuffer.INPUT_PARRY then
        self.combo:PushParry()
    end
end

--- 直接触发技能（绕过输入缓冲，用于 AI 或强制技能）
-- @param skillId string
-- @param yaw number|nil 指定释放朝向
-- @return boolean
function WuxiaCombatUnit:CastSkill(skillId, yaw)
    if not self.skillDb then
        return false
    end
    local skill = self.skillDb:GetSkill(skillId)
    if not skill then
        return false
    end

    -- 冷却与资源检查
    local ownerId = self.owner and (self.owner.id or tostring(self.owner))
    if self.skillDb:IsOnCooldown(ownerId, skillId) then
        return false
    end
    local canAfford, reason = self.skillDb:CanAfford(self.owner, skillId)
    if not canAfford then
        return false, reason
    end

    -- 状态机判定
    local eventName = skill.stateName
    if not self.fsm[eventName] then
        eventName = "force_idle"
    end

    -- 如果技能需要特定状态才能进入，检查能否转换
    if skill.stateName ~= "idle" and not self.fsm:Can(skill.stateName) then
        -- 尝试通过通用按键名再试试
        local map = {
            ["light_1"] = "light_attack",
            ["light_2"] = "light_2",
            ["light_3"] = "light_3",
            ["heavy_1"] = "heavy_attack",
            ["special"] = "special_attack",
            ["dodge"] = "dodge",
            ["block"] = "block",
            ["parry"] = "parry",
        }
        local mapped = map[skill.stateName]
        if mapped and self.fsm[mapped] then
            eventName = mapped
        end
    end

    if not self.fsm:Can(eventName) then
        return false, "state_not_allowed"
    end

    -- 扣除资源、进入状态
    self.skillDb:ConsumeCost(self.owner, skillId)
    self.skillDb:StartCooldown(ownerId, skillId)
    self.currentSkill = skill
    self.skillTimer = 0.0
    self.activeHitboxes = {}

    -- 更新朝向
    if yaw and self.owner then
        CombatUtils.SetNodeYawSafe(self.owner, yaw)
    end

    -- 播放动画
    if skill.animation then
        CombatUtils.PlayAnimationSafe(self.owner, skill.animation, false)
    end

    -- 霸体/无敌处理
    if skill.superArmorStartup then
        self.fsm:EnableSuperArmor()
    end
    if skill.invincible then
        self.fsm.invincible = true
    end

    -- 执行状态转换
    if self.fsm[eventName] then
        self.fsm[eventName](self.fsm)
    end

    return true
end

--- 更新战斗单元（应在 Update 循环中调用）
-- @param dt number
function WuxiaCombatUnit:Update(dt)
    if not self.owner then
        return
    end

    -- 更新子系统
    self.fsm:Update(dt)
    self.combo:Update(dt)
    self.dealer:Update(dt)
    if self.skillDb then
        self.skillDb:Update(dt)
    end

    -- 当前技能的帧级处理
    if self.currentSkill then
        self.skillTimer = self.skillTimer + dt
        local skill = self.currentSkill
        local fps = 60.0
        local currentFrame = math.floor(self.skillTimer * fps)

        -- 在 startup 结束后的 active 期间生成 hitbox
        if currentFrame >= skill.startupFrames and currentFrame < (skill.startupFrames + skill.activeFrames) then
            if #self.activeHitboxes == 0 then
                local ownerPos = CombatUtils.GetNodeWorldPosition(self.owner)
                local ownerYaw = 0.0
                if self.owner.rotation and type(self.owner.rotation.EulerAngles) == "function" then
                    ownerYaw = self.owner.rotation:EulerAngles().y or 0.0
                end
                for _, hbDef in ipairs(skill.hitboxList or {}) do
                    local yawRad = math.rad(ownerYaw + (hbDef.params.yawOffset or 0.0))
                    local center = {
                        x = ownerPos.x + hbDef.offset.x * math.cos(yawRad) + hbDef.offset.z * math.sin(yawRad),
                        y = ownerPos.y + hbDef.offset.y,
                        z = ownerPos.z - hbDef.offset.x * math.sin(yawRad) + hbDef.offset.z * math.cos(yawRad),
                    }
                    local hbId = nil
                    if hbDef.shape == HitboxManager.HITBOX_SHAPE_SPHERE then
                        hbId = self.hitboxManager:SpawnSphereHitbox(
                            self.owner, center, hbDef.params.radius,
                            skill.damageEvent, hbDef.lifetime, hbDef.maxHits
                        )
                    elseif hbDef.shape == HitboxManager.HITBOX_SHAPE_BOX then
                        hbId = self.hitboxManager:SpawnBoxHitbox(
                            self.owner, center, hbDef.params.halfSize, ownerYaw + (hbDef.params.yawOffset or 0.0),
                            skill.damageEvent, hbDef.lifetime, hbDef.maxHits
                        )
                    elseif hbDef.shape == HitboxManager.HITBOX_SHAPE_FAN then
                        hbId = self.hitboxManager:SpawnFanHitbox(
                            self.owner, center, hbDef.params.radius, hbDef.params.angleSpan,
                            ownerYaw + (hbDef.params.yawOffset or 0.0),
                            skill.damageEvent, hbDef.lifetime, hbDef.maxHits
                        )
                    elseif hbDef.shape == HitboxManager.HITBOX_SHAPE_LINE then
                        local dir = { x = math.sin(yawRad), y = 0.0, z = math.cos(yawRad) }
                        hbId = self.hitboxManager:SpawnLineHitbox(
                            self.owner, center, dir, hbDef.params.length, hbDef.params.thickness,
                            skill.damageEvent, hbDef.lifetime, hbDef.maxHits
                        )
                    end
                    if hbId then
                        table.insert(self.activeHitboxes, hbId)
                    end
                end
            end
        end

        -- 连招窗口开关
        if skill.comboWindowOpenFrame > 0 and currentFrame >= skill.comboWindowOpenFrame and currentFrame < skill.comboWindowCloseFrame then
            self.fsm:OpenComboWindow((skill.comboWindowCloseFrame - currentFrame) / fps, skill.cancelable)
            self.combo:NotifyComboWindow(true)
        else
            self.combo:NotifyComboWindow(false)
        end

        -- 当技能结束时清除当前技能引用
        if currentFrame >= skill.totalFrames then
            self.currentSkill = nil
            self.activeHitboxes = {}
            if skill.stateName ~= "idle" and skill.stateName ~= "block" then
                if self.fsm["force_idle"] then
                    self.fsm:force_idle()
                end
            end
        end
    end

    -- 死亡处理
    if self.destroyOnDeath and self.owner.health ~= nil and self.owner.maxHealth ~= nil then
        if self.owner.health <= 0.0 then
            -- 可在此触发死亡回调或清理 hurtbox
        end
    end
end

--- 获取调试信息
-- @return table
function WuxiaCombatUnit:GetDebugInfo()
    return {
        state = self.fsm:GetDebugInfo(),
        combo = self.combo:GetComboCount(),
        skill = self.currentSkill and self.currentSkill.id or nil,
        skillTimer = self.skillTimer,
    }
end

M.WuxiaCombatUnit = WuxiaCombatUnit

return M
