# Ink 叙事运行时

基于 [astrochili/narrator](https://github.com/astrochili/narrator) 的纯 Lua Ink 解析器与运行时，完整支持 Ink 语法（knot、stitch、choice、variable、condition、gather、divert、tags、lists 等）。

适用于 UrhoX 游戏引擎，无需 luarocks 或外部依赖，所有子模块均已内嵌到 `main.lua` 中，直接 `require` 即可使用。

---

## 特性

- 完整 Ink 语法解析与运行
- 从字符串直接加载故事（推荐用于 UrhoX 资源系统）
- 支持分支选择、变量读写、存档/读档
- 支持标签过滤与事件观察
- 支持 Knot/Stitch 跳转与循环

---

## 快速开始

```lua
local Ink = require("scripts/main")

-- 示例 Ink 脚本
local inkSource = [[
VAR player_name = "侠客"

你好，{player_name}！
*   [去东边] -> east
*   [去西边] -> west

=== east ===
你来到了东方的竹林。
*   [拔剑] 剑光一闪。
*   [收剑] 气定神闲。
-   -> END

=== west ===
西方的落日很美。
-> END
]]

-- 加载故事
local story, err = Ink.LoadStoryFromString(inkSource)
if not story then
    print("加载失败:", err)
    return
end

-- 推进故事
local paragraphs = Ink.Continue(story)
for _, p in ipairs(paragraphs) do
    print(p.text)
end

-- 显示选项
local choices = Ink.GetChoices(story)
for i, c in ipairs(choices) do
    print(i .. ". " .. c.text)
end

-- 玩家选择第 1 项
Ink.Choose(story, 1)

-- 修改变量
Ink.Var(story, "player_name", "剑圣")
```

---

## API 参考

### `ParseStoryFromString(inkSource)`
从 Ink 源码字符串解析为 `book`（书籍数据）。

### `LoadStoryFromString(inkSource)`
一站式加载：解析 + 初始化故事 + 自动 `begin()`。

### `InitStory(book)`
用 `book` 创建一个新的 `story` 实例。可用于从同一本书创建多个独立存档。

### `Continue(story)`
推进故事，返回当前段落列表。每个段落包含：
- `text`：纯文本内容
- `tags`：标签数组（可选）

### `GetChoices(story)`
返回当前可选择项数组。每个选项包含 `text`。

### `Choose(story, index)`
做出选择（`index` 从 1 开始）。

### `Var(story, name, value?)`
读取或设置变量。不传 `value` 时读取，传入时设置。

### `Observe(story, name, callback)`
观察变量变化。`callback(name, value)` 在变量被修改时触发。

### `JumpToKnot(story, knot)`
直接跳转到指定 Knot（如 `"east"`）。

### `SaveState(story) / LoadState(story, stateJSON)`
保存/恢复故事运行状态，可用于游戏存档系统。

---

## Ink 语法速查

```ink
VAR gold = 10

- 你好，冒险者。
*   [给我任务] -> quest
*   [离开] -> END

=== quest ===
{ gold > 5:
    你的身价不菲。
- else:
    你看起来很穷。
}
-> END
```

更多语法请参考 [Writing With Ink](https://github.com/inkle/ink/blob/master/Documentation/WritingWithInk.md) 官方文档。

---

## 授权

本 Skill 内嵌了 narrator 库的源码，遵循其 MIT License。
