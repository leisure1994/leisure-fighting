# UrhoX 示例速查包

将 Urho3D 官方 41 个 Lua 示例中最常用的技术点，提炼成可直接复用的小型 Lua 模块。适合新手快速查阅、老手复制粘贴。

---

## 模块清单

| 模块 | 对应原版示例 | 功能简述 |
|------|-------------|----------|
| `SampleBasic` | 01_HelloWorld | 引擎初始化、场景创建、摄像机基础 |
| `Sample2D` | 24_Urho2DSprite | 2D 精灵创建、缩放、移动、动画帧 |
| `SampleAnimation` | 05_AnimatingScene | 3D 对象旋转/位移动画脚本 |
| `SampleSkeletalAnimation` | 07_SkeletalAnimation | 骨骼动画播放、混合、状态切换 |
| `SamplePhysics` | 08_Physics, 11_PhysicsStressTest | 刚体创建、碰撞事件订阅、施加冲量 |
| `SamplePhysics2D` | 32_Urho2DConstraints | 2D 刚体、约束、Box2D 碰撞回调 |
| `SampleVehicle` | 19_VehicleDemo | 简版载具控制器（轮子、悬挂、油门） |
| `SampleUI` | 23_InGameUI | 按钮、滑动条、窗口、事件绑定 |
| `SampleUtils` | 多个示例 | 辅助函数：创建摄像机、创建灯光、创建地面 |

---

## 快速开始

```lua
local Samples = require("scripts/main")

-- 按需加载某个模块
local Utils = Samples.LoadModule("SampleUtils")
local Vehicle = Samples.LoadModule("SampleVehicle")

-- 使用辅助函数创建场景基础
local scene = Utils.CreateBaseScene()
local cameraNode = Utils.CreateCamera(scene, Vector3(0, 5, -10), Vector3(0, 0, 0))
local lightNode = Utils.CreateDirectionalLight(scene, Vector3(-1, -2, -1))

-- 创建一辆载具
local carNode = Vehicle.CreateVehicle(scene, Vector3(0, 2, 0))
```

---

## 模块 API 速查

### SampleBasic
- `CreateSampleScene()` — 创建一个带摄像机和定向光的空场景
- `CreateBox(scene, position, color)` — 在场景中创建一个彩色立方体

### Sample2D
- `CreateSprite(scene, texturePath, position, size)` — 创建 2D 精灵
- `AnimateScale(spriteNode, duration, targetScale)` — 缩放动画
- `AnimatePosition(spriteNode, duration, targetPos)` — 位移动画

### SampleAnimation
- `Spin(node, axis, speed)` — 使节点持续旋转
- `PingPongMove(node, axis, distance, speed)` — 往返移动

### SampleSkeletalAnimation
- `PlayAnimation(modelNode, animName, loop)` — 播放骨骼动画
- `SetAnimationBlend(modelNode, animName, weight)` — 动画混合权重

### SamplePhysics
- `CreateRigidBodyBox(scene, position, size, mass)` — 创建物理立方体
- `ApplyImpulse(bodyNode, impulse)` — 施加冲量
- `SubscribeToCollision(bodyNode, callback)` — 碰撞事件订阅

### SamplePhysics2D
- `CreateRigidBody2DBox(scene, position, size, bodyType)` — 创建 2D 物理体
- `CreateDistanceConstraint(scene, bodyA, bodyB, anchorA, anchorB)` — 距离约束

### SampleVehicle
- `CreateVehicle(scene, position)` — 创建基础载具节点
- `SetSteering(vehicleNode, value)` — 设置方向盘值（-1 ~ 1）
- `SetAccelerator(vehicleNode, value)` — 设置油门值
- `SetBrake(vehicleNode, value)` — 设置刹车值

### SampleUI
- `CreateButton(title, x, y, width, height, callback)` — 创建按钮
- `CreateSlider(x, y, width, height, min, max, callback)` — 创建滑动条
- `ShowMessageBox(title, message)` — 弹出消息框

### SampleUtils
- `CreateBaseScene()` — 创建基础场景（摄像机+灯光+地面）
- `CreateCamera(scene, eye, lookAt, fov)` — 创建透视摄像机
- `CreateDirectionalLight(scene, direction)` — 创建定向光
- `CreateGroundPlane(scene, size)` — 创建网格地面
- `CreateSkybox(scene, materialPath)` — 创建天空盒

---

## 提示

本 Skill 的所有模块均为**逻辑封装**，不是完整可运行的示例程序。你需要在自己的 `main.lua` 中组合使用。
